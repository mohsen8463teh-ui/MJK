import numpy as np, math, os, subprocess
SR=44100; DUR=64
out='/mnt/data/workfix/android/app/src/main/res/raw'; os.makedirs(out,exist_ok=True)
# Persian-ish modal pitch sets (Hz), each track gets distinct scale and rhythm
tracks=[
('shab_aramesh', 52, [293.66,311.13,349.23,392.00,440.00,466.16,523.25], [0,2,4,3,2,1,0,3], 'setar'),
('ney_bahar', 58, [261.63,293.66,329.63,349.23,392.00,415.30,466.16], [0,1,3,4,3,2,1,4], 'ney'),
('setar_roya', 50, [220.00,246.94,277.18,293.66,329.63,369.99,415.30], [0,2,1,4,3,2,5,4,2,1], 'oud'),
('santour_mahtab', 62, [246.94,277.18,311.13,329.63,369.99,415.30,466.16], [0,1,2,4,5,4,2,3,1,0], 'santur'),
('baran_narenj', 56, [246.94,261.63,293.66,329.63,369.99,392.00,440.00], [0,3,2,4,2,1,5,4], 'piano'),
('daryaye_sokoot', 44, [196.00,220.00,246.94,293.66,329.63,369.99,392.00], [0,1,3,2,4,3,1,0], 'pad'),
('kavir_shab', 48, [174.61,196.00,220.00,246.94,293.66,329.63,369.99], [0,2,4,3,5,4,2,1], 'ney'),
('tehran_bedtime', 60, [220.00,246.94,261.63,293.66,329.63,369.99,415.30], [0,1,4,3,2,5,4,1], 'epiano'),
]
rng=np.random.default_rng(20260908)

def add_note(y,start,dur,freq,amp,kind,pan=0.0):
    a=max(0,int(start*SR)); b=min(len(y),int((start+dur)*SR));
    if b<=a:return
    t=np.arange(b-a)/SR
    if kind=='setar':
        sig=(np.sin(2*np.pi*freq*t)+0.28*np.sin(4*np.pi*freq*t)+0.10*np.sin(6*np.pi*freq*t))*np.exp(-4.2*t)
    elif kind=='ney':
        sig=(0.72*np.sin(2*np.pi*freq*t)+0.22*np.sin(2*np.pi*2*freq*t)+0.06*np.sin(2*np.pi*3*freq*t))*(0.75+0.25*np.sin(2*np.pi*3*t))*np.exp(-1.7*t)
        sig += 0.025*rng.standard_normal(len(t))*np.exp(-2*t)
    elif kind=='oud':
        sig=(np.sin(2*np.pi*freq*t)+0.45*np.sin(2*np.pi*2*freq*t)+0.18*np.sin(2*np.pi*3*freq*t))*np.exp(-2.8*t)
    elif kind=='santur':
        sig=(np.sin(2*np.pi*freq*t)+0.5*np.sin(2*np.pi*2*freq*t)+0.25*np.sin(2*np.pi*3*freq*t)+0.12*np.sin(2*np.pi*5*freq*t))*np.exp(-6*t)
    elif kind=='piano':
        env=(1-np.exp(-35*t))*np.exp(-1.9*t)
        sig=(np.sin(2*np.pi*freq*t)+0.32*np.sin(2*np.pi*2*freq*t)+0.12*np.sin(2*np.pi*3*freq*t))*env
    elif kind=='epiano':
        env=(1-np.exp(-18*t))*np.exp(-1.35*t)
        sig=(np.sin(2*np.pi*freq*t)+0.20*np.sin(2*np.pi*2*freq*t)+0.08*np.sin(2*np.pi*4*freq*t))*env
    else:
        sig=(np.sin(2*np.pi*freq*t)+0.18*np.sin(2*np.pi*1.5*freq*t))*np.exp(-0.55*t)
    # soft stereo pan
    left=(1-pan)*0.5+0.5; right=(1+pan)*0.5+0.5
    y[a:b,0]+=amp*sig*left; y[a:b,1]+=amp*sig*right

for ti,(name,bpm,scale,pat,kind) in enumerate(tracks):
    n=SR*DUR; y=np.zeros((n,2),dtype=np.float32); beat=60/bpm
    # unique drone/pad foundation
    root=scale[0]
    t=np.arange(n)/SR
    if kind=='pad' or ti==5:
        y[:,0]+=0.045*np.sin(2*np.pi*root*t)+0.018*np.sin(2*np.pi*root*1.5*t)
        y[:,1]+=0.045*np.sin(2*np.pi*root*t)+0.018*np.sin(2*np.pi*root*1.5*t)
    else:
        y[:,0]+=0.018*np.sin(2*np.pi*root*t)+0.008*np.sin(2*np.pi*root*2*t)
        y[:,1]+=0.018*np.sin(2*np.pi*root*t)+0.008*np.sin(2*np.pi*root*2*t)
    # 2-note chords on long intervals, different for each track
    chord_idx=[0,3,4,2]
    for k in range(int(DUR/(beat*4))):
        base=scale[chord_idx[(k+ti)%len(chord_idx)]%len(scale)]
        for off,mul in [(0,1),(1,1.5),(2,2)]:
            f=scale[(chord_idx[(k+ti)%len(chord_idx)]+off)%len(scale)]*mul
            add_note(y,k*beat*4,beat*3.5,f,0.025 if kind!='pad' else 0.035, 'pad' if kind=='pad' else 'epiano', -0.2+0.4*((k+off)%2))
    # melody phrases
    step=beat*(0.5 if ti in (0,2,3,7) else 1.0)
    total_steps=int(DUR/step)
    for s in range(total_steps):
        if s%13==7 or (ti==5 and s%9 in (5,6)): continue
        idx=pat[s%len(pat)]%len(scale)
        octave=1 if (s%16 in (5,12) and ti not in (5,6)) else 0
        f=scale[idx]*(2**octave)
        length=step*(0.8 if kind in ('ney','pad') else 0.65)
        amp={'setar':0.17,'ney':0.13,'oud':0.16,'santur':0.15,'piano':0.12,'pad':0.10,'epiano':0.13}[kind]
        add_note(y,s*step,length,f,amp,kind,(-0.55 if s%8<4 else 0.45))
        # occasional answer note, makes each track more composed
        if s%8==3 and ti in (1,3,4,7):
            f2=scale[(idx+2)%len(scale)]
            add_note(y,s*step+step*0.5,step*0.4,f2,amp*0.65,kind,0.35)
    # subtle percussion/texture unique per track
    if ti in (3,4,7):
        for k in range(int(DUR/(beat*2))):
            start=k*beat*2
            a=int(start*SR); b=min(n,a+int(0.12*SR))
            tt=np.arange(max(0,b-a))/SR
            if len(tt):
                noise=rng.standard_normal(len(tt))*np.exp(-28*tt)*0.025
                y[a:b,0]+=noise; y[a:b,1]+=noise*0.8
    # stereo delay/reverb; unique delay per track
    delay=int((0.19+0.03*ti)*SR)
    if delay<n:
        y[delay:,0]+=0.12*y[:-delay,1]
        y[delay:,1]+=0.12*y[:-delay,0]
    # gentle fade
    fade=np.ones(n,dtype=np.float32); fi=int(2*SR); fo=int(3*SR)
    fade[:fi]=np.linspace(0,1,fi); fade[-fo:]=np.linspace(1,0,fo)
    y*=fade[:,None]
    peak=np.max(np.abs(y)); y*=0.78/max(peak,1e-6)
    wav=f'/mnt/data/workfix/{name}.wav'; ogg=f'{out}/{name}.ogg'
    # write float normalized PCM
    pcm=np.int16(np.clip(y,-1,1)*32767)
    import wave
    with wave.open(wav,'wb') as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    subprocess.run(['ffmpeg','-y','-loglevel','error','-i',wav,'-c:a','libvorbis','-q:a','5',ogg],check=True)
    os.remove(wav)
    print(name,os.path.getsize(ogg))
