const fs=require('fs');
const https=require('https');
const path=require('path');
const BASE=path.join(process.cwd(),'radar-data');
const HIST=path.join(BASE,'history');
fs.mkdirSync(BASE,{recursive:true});
fs.mkdirSync(HIST,{recursive:true});
const HEADERS={'User-Agent':'MJK-History-Updater/2.0 (+https://github.com/mohsen8463teh-ui/MJK)','Accept':'application/json,text/plain,*/*','Accept-Language':'fa-IR,fa;q=0.9,en;q=0.8','Referer':'https://www.tsetmc.com/'};
function get(url){return new Promise((resolve,reject)=>{const req=https.get(url,{headers:HEADERS,timeout:20000},res=>{let b='';res.setEncoding('utf8');res.on('data',x=>b+=x);res.on('end',()=>{if(res.statusCode<200||res.statusCode>=300)return reject(new Error(`HTTP ${res.statusCode}`));try{resolve(JSON.parse(b))}catch(e){reject(new Error('invalid JSON'))}})});req.on('error',reject);req.on('timeout',()=>req.destroy(new Error('timeout')))});}
const num=v=>{const n=Number(String(v??'').replace(/,/g,''));return Number.isFinite(n)?n:null};
function norm(x){return {date:num(x.dEven??x.date),open:num(x.pFirst??x.priceFirst??x.open),last:num(x.pDrCotVal??x.last),close:num(x.pClosing??x.close),prev:num(x.priceYesterday??x.prev),low:num(x.pMin??x.priceMin??x.low),high:num(x.pMax??x.priceMax??x.high),vol:num(x.qTotTran5J??x.vol??x.volume),value:num(x.qTotCap??x.value),trades:num(x.zTotTran??x.trades)};}
async function history(id){const j=await get(`https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDailyList/${encodeURIComponent(id)}/200`);const a=Array.isArray(j)?j:(j.closingPriceDaily||j.data||[]);const rows=a.map(norm).filter(r=>r.last!=null&&r.prev!=null&&r.prev>0&&r.low!=null&&r.high!=null).sort((a,b)=>(a.date||0)-(b.date||0));return rows.length>=150?rows:null;}
function loadStocks(){const p=path.join(BASE,'stocks.json');if(!fs.existsSync(p))throw new Error('radar-data/stocks.json missing');const j=JSON.parse(fs.readFileSync(p,'utf8'));const rows=j.items||j.rows||[];if(!Array.isArray(rows)||rows.length<100)throw new Error('stock snapshot too small');return rows.filter(x=>x.insCode&&x.symbol&&x.last!=null);}
(async()=>{
 const stocks=loadStocks();
 console.log('history candidates:',stocks.length,'(all stock symbols)');
 const queue=[...stocks]; const out=[]; let done=0, failed=0;
 const workers=Array.from({length:12},async()=>{while(queue.length){const x=queue.shift();try{const h=await history(x.insCode);if(h){const item={insCode:String(x.insCode),symbol:x.symbol,history:h};fs.writeFileSync(path.join(HIST,`${String(x.insCode)}.json`),JSON.stringify(item));out.push({insCode:String(x.insCode),symbol:x.symbol,rows:h.length});}else {failed++;console.warn('insufficient history',x.symbol,x.insCode)}}catch(e){failed++;console.warn('history failed',x.symbol,x.insCode,e.message)}done++;if(done%100===0)console.log('progress',done,'/',stocks.length,'ok',out.length,'failed',failed);}});
 await Promise.all(workers);
 if(out.length<Math.min(100,stocks.length))throw new Error(`history validation failed: only ${out.length} symbols with >=150 rows`);
 out.sort((a,b)=>a.insCode.localeCompare(b.insCode));
 const payload={source:'TSETMC daily history via GitHub Actions',timestamp:Date.now(),live:false,upstreamOk:true,minRows:150,symbolCount:out.length,items:out.map(x=>({insCode:x.insCode,symbol:x.symbol,rows:x.rows}))};
 const tmp=path.join(BASE,'history.json.tmp');fs.writeFileSync(tmp,JSON.stringify(payload));fs.renameSync(tmp,path.join(BASE,'history.json'));
 console.log(`history files => ${out.length} symbols, minimum 150 rows each; failed=${failed}`);
})().catch(e=>{console.error(e.stack||e);process.exit(1)});
