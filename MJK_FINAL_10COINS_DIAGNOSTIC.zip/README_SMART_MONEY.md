# MJK Smart Money V4

## Live-data design
- BlackRock/IBIT: official iShares holdings page. The app reads the published BTC quantity and compares it with the last value observed by the app. This is a published holdings snapshot, not a private real-time BlackRock trade feed.
- Whale/Smart Money: CoinMarketCap DEX keyless endpoints for live swap history and labeled holder analytics where coverage exists.
- Unsupported/insufficient coverage is shown explicitly; no placeholder numbers are generated.
- Smart Money data is informational only and does not modify MJK's core trading strategy, signal rules, or backtest.
