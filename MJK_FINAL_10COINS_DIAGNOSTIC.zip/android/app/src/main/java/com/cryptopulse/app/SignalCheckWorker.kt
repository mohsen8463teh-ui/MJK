package com.cryptopulse.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

class SignalCheckWorker(ctx: Context, params: WorkerParameters): CoroutineWorker(ctx, params) {
    private val prefs=ctx.getSharedPreferences("mjk",Context.MODE_PRIVATE)
    private val fallback=listOf("BTCUSDT","ETHUSDT","XRPUSDT","BNBUSDT","SOLUSDT","DOGEUSDT","ADAUSDT","TRXUSDT","LINKUSDT","AVAXUSDT")
    private val base="https://api.kucoin.com/api/v1"
    private val stable=setOf("USDT","USDC","USDE","DAI","FDUSD","USDS","TUSD","USDD")

    override suspend fun doWork(): Result=withContext(Dispatchers.IO){
        try{val symbols=topSymbols();for(symbol in symbols){try{checkSymbol(symbol)}catch(_:Exception){}};Result.success()}
        catch(_:Exception){Result.retry()}
    }

    private fun topSymbols():List<String>{
        return try{
            val coins=JSONArray(open("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=50&page=1&sparkline=false"))
            val markets=JSONObject(open("$base/symbols"));val available=mutableSetOf<String>();val arr=markets.optJSONArray("data")?:JSONArray()
            for(i in 0 until arr.length()){val x=arr.getJSONObject(i);if(x.optString("quoteCurrency")=="USDT"&&x.optBoolean("enableTrading",true))available.add(x.optString("symbol").uppercase())}
            val out=mutableListOf<String>()
            for(i in 0 until coins.length()){
                val sym=coins.getJSONObject(i).optString("symbol").uppercase();if(sym.isBlank()||stable.contains(sym))continue
                if(available.contains("$sym-USDT"))out.add(sym+"USDT")
                if(out.size==10)break
            }
            if(out.size==10)out else fallback
        }catch(_:Exception){fallback}
    }

    private fun checkSymbol(symbol:String){
        val rows=getKlines(symbol,220).filter{it.getLong(6)<System.currentTimeMillis()};if(rows.size<210)return
        val closes=rows.map{it.getDouble(4)};val e20=ema(closes,20);val e200=ema(closes,200);val a14=atr(rows,14);val i=rows.lastIndex;val c=rows[i]
        val last=prefs.getLong("last_signal_close_$symbol",0L);val gap=last==0L||c.getLong(6)-last>=10L*15L*60L*1000L
        val signal=closes[i]>e200[i]&&e20[i]>e200[i]&&c.getDouble(3)<=e20[i]&&closes[i]>c.getDouble(1)&&closes[i]>e20[i]&&gap
        val activeJson=prefs.getString("active_trade_$symbol",null);val price=getPrice(symbol)
        if(activeJson!=null){val o=JSONObject(activeJson);val sl=o.getDouble("stop_loss");val tp=o.getDouble("take_profit_1");if(price<=sl||price>=tp){val hit=price>=tp;prefs.edit().remove("active_trade_$symbol").apply();notify("MJK: $symbol","معامله بسته شد",if(hit)"TP رسید | قیمت ${fmt(price)}" else "SL رسید | قیمت ${fmt(price)}")}}
        if(activeJson==null&&signal){val entry=closes[i];val sl=entry-1.5*a14[i];val tp=entry+3*a14[i];val id="$symbol-${c.getLong(6)}";val lastId=prefs.getString("last_signal_id_$symbol","");if(id!=lastId){val o=JSONObject().put("id",id).put("symbol",symbol).put("entry_price",entry).put("stop_loss",sl).put("take_profit_1",tp).put("close_time_ms",c.getLong(6));prefs.edit().putString("last_signal_id_$symbol",id).putLong("last_signal_close_$symbol",c.getLong(6)).putString("active_trade_$symbol",o.toString()).apply();notify("MJK: $symbol","سیگنال BUY جدید","Entry ${fmt(entry)} | SL ${fmt(sl)} | TP ${fmt(tp)}")}}
    }

    private fun getPrice(symbol:String):Double{val market=symbol.removeSuffix("USDT")+"-USDT";val j=JSONObject(open("$base/market/stats?symbol=$market"));return j.getJSONObject("data").getDouble("last")}
    private fun getKlines(symbol: String, n: Int): List<JSONArray> {
        val market = symbol.removeSuffix("USDT") + "-USDT"
        val j = JSONObject(open("$base/market/candles?symbol=$market&type=15min&limit=$n"))
        val a = j.getJSONArray("data")
        val out = mutableListOf<JSONArray>()
        for (i in 0 until a.length()) {
            val r = a.getJSONArray(i)
            val t = r.getLong(0)
            out.add(
                JSONArray()
                    .put(t)
                    .put(r.getDouble(1))
                    .put(r.getDouble(3))
                    .put(r.getDouble(4))
                    .put(r.getDouble(2))
                    .put(r.getDouble(5))
                    .put(t + 15L * 60L * 1000L - 1)
            )
        }
        return out.sortedBy { it.getLong(0) }
    }
    private fun open(u:String):String{val c=URL(u).openConnection() as HttpURLConnection;c.connectTimeout=12000;c.readTimeout=12000;c.requestMethod="GET";c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","MJK-Android/1.0");return try{if(c.responseCode !in 200..299)throw Exception("HTTP ${c.responseCode}");c.inputStream.bufferedReader().use{it.readText()}}finally{c.disconnect()}}
    private fun fmt(v:Double)=String.format(java.util.Locale.US,"%.4f",v)
    private fun ema(v:List<Double>,p:Int):DoubleArray{val o=DoubleArray(v.size);var sum=0.0;for(i in 0 until p)sum+=v[i];var prev=sum/p;o[p-1]=prev;val k=2.0/(p+1);for(i in p until v.size){prev=(v[i]-prev)*k+prev;o[i]=prev};return o}
    private fun atr(c:List<JSONArray>,p:Int):DoubleArray{val tr=DoubleArray(c.size);for(i in c.indices){val h=c[i].getDouble(2);val l=c[i].getDouble(3);val pc=if(i==0)h else c[i-1].getDouble(4);tr[i]=if(i==0)h-l else maxOf(h-l,abs(h-pc),abs(l-pc))};val o=DoubleArray(c.size);var s=0.0;for(i in 0 until p)s+=tr[i];var prev=s/p;o[p-1]=prev;for(i in p until c.size){prev=(prev*(p-1)+tr[i])/p;o[i]=prev};return o}
    private fun notify(title:String,head:String,text:String){val nm=applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;val id="mjk_signal";if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(id,"MJK Signals",NotificationManager.IMPORTANCE_HIGH));val n=NotificationCompat.Builder(applicationContext,id).setSmallIcon(com.cryptopulse.app.R.drawable.mjk_notification).setContentTitle(title).setContentText("$head | $text").setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build();nm.notify((title.hashCode()+System.currentTimeMillis()).toInt(),n)}
}
