package com.cryptopulse.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

class SignalCheckWorker(ctx: Context, params: WorkerParameters): CoroutineWorker(ctx, params) {
    private val prefs=ctx.getSharedPreferences("mjk",Context.MODE_PRIVATE)
    override suspend fun doWork(): Result=withContext(Dispatchers.IO){
        try{checkRadarRelay();Result.success()}catch(_:Exception){Result.retry()}
    }

    private fun checkRadarRelay(){
        if(!iranStockMarketOpen()) return
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(applicationContext,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return
        val base=prefs.getString("radar_relay_url","https://raw.githubusercontent.com/mohsen8463teh-ui/MJK/main/radar-data")?.trim()?.trimEnd('/') ?: ""
        if(base.isBlank())return
        val j=JSONObject(open("$base/mjk/v1/radar/stocks"))
        val rows=j.optJSONArray("items") ?: j.optJSONArray("rows") ?: return
        var best:JSONObject?=null
        for(i in 0 until rows.length()){
            val x=rows.optJSONObject(i) ?: continue
            val direction=x.optString("direction","")
            val samples=x.optInt("probabilitySamples",0)
            val lower=x.optDouble("probabilityLowerBound",0.0)
            val oos=x.optBoolean("oosValid",false)
            val quality=x.optDouble("dataQuality",0.0)
            val setup=x.optDouble("setupScore",0.0)
            if(direction=="PRE-SURGE"&&samples>=50&&lower>=80.0&&oos&&quality>=70.0&&setup>=70.0){
                if(best==null||x.optDouble("probability",0.0)>best!!.optDouble("probability",0.0))best=x
            }
        }
        val b=best?:return
        val symbol=b.optString("symbol",b.optString("name","فرصت جدید"))
        val id=b.optString("id",symbol)+":"+b.optString("closeTime","")
        val key="radar_alert_stocks_$id"
        val old=prefs.getLong(key,0L)
        if(System.currentTimeMillis()-old<6*60*60*1000L)return
        prefs.edit().putLong(key,System.currentTimeMillis()).apply()
        notifyStock(symbol,b.optDouble("probabilityLowerBound",0.0),b.optInt("probabilitySamples",0))
    }

    private fun iranStockMarketOpen(): Boolean {
        val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Tehran"))
        val day = cal.get(java.util.Calendar.DAY_OF_WEEK)
        val minute = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
        val weekdayOpen = day == java.util.Calendar.SATURDAY || day == java.util.Calendar.SUNDAY || day == java.util.Calendar.MONDAY || day == java.util.Calendar.TUESDAY || day == java.util.Calendar.WEDNESDAY
        return weekdayOpen && minute >= 540 && minute < 750
    }

    private fun notifyStock(symbol:String,lower:Double,samples:Int){
        val nm=applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel="mjk_signal_loud_v2"
        if(Build.VERSION.SDK_INT>=26){
            val sound=Uri.parse("android.resource://${applicationContext.packageName}/${R.raw.mjk_signal_alert}")
            val attrs=AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val ch=NotificationChannel(channel,"MJK · هشدار سیگنال بورس",NotificationManager.IMPORTANCE_HIGH)
            ch.description="هشدار صدادار سیگنال معتبر رادار بورس"
            ch.setSound(sound,attrs);ch.enableVibration(true);ch.setVibrationPattern(longArrayOf(0,250,120,400));nm.createNotificationChannel(ch)
        }
        val n=NotificationCompat.Builder(applicationContext,channel)
            .setSmallIcon(R.drawable.mjk_notification)
            .setContentTitle("MJK · سیگنال معتبر بورس")
            .setContentText("$symbol · PRE-SURGE · اعتبارسنجی تأیید شد")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$symbol · حد پایین تاریخی ${lower.toInt()}% · $samples نمونه"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true).build()
        nm.notify(("stock:"+symbol+System.currentTimeMillis()).hashCode(),n)
    }
    private fun open(u:String):String{val c=URL(u).openConnection() as HttpURLConnection;c.connectTimeout=12000;c.readTimeout=12000;c.requestMethod="GET";c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","MJK-Android/1.0");return try{if(c.responseCode !in 200..299)throw Exception("HTTP ${c.responseCode}");c.inputStream.bufferedReader().use{it.readText()}}finally{c.disconnect()}}
}
