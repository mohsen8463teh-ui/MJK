/* MJK Commodity Opportunity Radar v3: relay-first, cached last-valid data, evidence gates. */
window.commodities=(()=>{
 let active=false,timer=null,busy=false;
 const CDN='https://cdn.tsetmc.com/api',OLD='http://old.tsetmc.com/tsev2/data';
 const json=u=>{try{const t=window.MJKNative?.fetchJson?.(u);if(!t||String(t).startsWith('MJK_NATIVE_ERROR:'))return null;return JSON.parse(t)}catch(_){return null}};
 const text=u=>{try{const t=window.MJKNative?.fetchText?.(u);if(!t||String(t).startsWith('MJK_NATIVE_ERROR:'))return null;return String(t)}catch(_){return null}};
 const n=v=>{if(v&&typeof v==='object')v=v.value??v.Value??v.val??v.amount??v.Amount;const x=Number(String(v??'').replace(/,/g,''));return Number.isFinite(x)?x:null};
 function legacy(){const raw=text(`${OLD}/MarketWatchInit.aspx?h=0&r=0`);if(!raw)return null;const p=raw.split('@');if(p.length<5)return null;const rows=p[2].split(';').filter(Boolean).map(r=>r.split(',')),out=[];for(const r of rows){if(r.length<22||n(r[17])!==7)continue;const last=n(r[7]),prev=n(r[13]);if(last==null)continue;out.push({insCode:r[0],symbol:r[2]||r[3],name:r[3]||r[2]||'—',last,close:n(r[6]),prev,change:prev?((last-prev)/prev*100):null,trades:n(r[8]),vol:n(r[9]),value:n(r[10]),low:n(r[11]),high:n(r[12]),eps:n(r[14]),state:r[18]||'',flow:7});}return{rows:out,source:'TSETMC legacy MarketWatch · کالا',timestamp:Date.now(),marketStatus:'unknown',live:true};}
 function modern(){
   const u=`${CDN}/ClosingPrice/GetMarketWatch?market=0&paperTypes[0]=1&paperTypes[1]=2&paperTypes[2]=3&paperTypes[3]=4&paperTypes[4]=5&paperTypes[5]=6&paperTypes[6]=7&paperTypes[7]=8&paperTypes[8]=9&withBestLimits=false&hEven=0&RefID=0`;
   const j=json(u); if(!j)return null;
   const raw=Array.isArray(j.marketwatch)?j.marketwatch:(Array.isArray(j.marketWatch)?j.marketWatch:[]);
   const rows=raw.map(x=>({
     insCode:String(x.insCode??x.InsCode??''),
     symbol:String(x.lVal18AFC??x.lVal18??x.instrumentName??x.name??''),
     name:String(x.lVal30??x.instrumentName??x.name??'—'),
     last:n(x.pDrCotVal??x.lastPrice??x.pl),
     prev:n(x.priceYesterday??x.yesterdayPrice??x.py),
     close:n(x.pClosing??x.closingPrice??x.pc),
     change:n(x.changePercent??x.pct),
     vol:n(x.qTotTran5J??x.tradeVolume??x.volume),
     value:n(x.qTotCap??x.tradeValue??x.value),
     trades:n(x.zTotTran??x.tradeCount),
     openInterest:n(x.openInterest),
     flow:n(x.flow??x.flowCode),
     state:String(x.stateName??x.state??'')
   })).filter(x=>x.symbol&&x.last!=null&&Number(x.flow)===7);
   if(!rows.length)return null;
   return{rows,source:'TSETMC CDN GetMarketWatch · flow=7',timestamp:Date.now(),marketStatus:'snapshot',live:true};
 }
 function notify(item){window.app?.toast?.(`🚨 فرصت کالایی: ${item.name||item.symbol} · ${item.score}/100`,'ok')}
 function render(result,live){const st=document.getElementById('cmStatus'),box=document.getElementById('cmRows'),main=document.getElementById('cmMain');if(!result?.rows?.length){const c=MJKOpportunity.cached('commodity');if(c?.rows?.length){result=c;live=false}else{st.textContent='🔴 منبع داده در دسترس نیست';box.innerHTML='<div class="empty">هیچ داده واقعی کالا/آتی دریافت نشد؛ نتیجه حدسی نمایش داده نمی‌شود.</div>';main.innerHTML='<div class="empty">برای داده زنده و عمق/حجم واقعی، Data Relay داخل ایران یا منبع حرفه‌ای دارای API باید متصل شود.</div>';return;}}
 const meta=result.meta||{},age=MJKOpportunity.freshness(meta.timestamp);st.textContent=`${live&&!age.stale?'🟢 زنده':'🕒 آخرین داده معتبر'} · ${result.rows.length} ابزار · ${meta.marketStatus||'وضعیت نامشخص'} · سن ${age.ageSec==null?'—':age.ageSec+'ثانیه'}`;
 const z=result.top;main.innerHTML=`<div class="ir-main"><div><small>${live&&!age.stale?'فرصت کالایی برتر زنده':'فرصت برتر از آخرین داده معتبر'} · ${z.direction}</small><b>${z.name||z.symbol||'—'}</b><span>اجماع ${z.votes}/5 موتور · کیفیت ${z.dataQuality}%</span></div><strong>${z.score}/100</strong></div><div class="ir-grid"><span>روند: ${z.engines.trend}</span><span>مومنتوم: ${z.engines.momentum}</span><span>جریان: ${z.engines.flow}</span><span>ارزش نسبی: ${z.engines.relative}</span><span>کلان/جهانی: ${z.engines.macro}</span><span>ریسک: ${z.engines.risk}</span></div>`;
 box.innerHTML=result.rows.slice(0,20).map((r,i)=>`<div class="cm-row"><div><b>${i+1}. ${r.name||r.symbol}</b><small>${r.direction} · اجماع ${r.votes}/5 · کیفیت ${r.dataQuality}%</small></div><strong>${r.last}</strong><span class="${(r.ch||0)>=0?'up':'down'}">${r.ch==null?'—':r.ch.toFixed(2)+'%'}</span></div>`).join('');
 }
 function run(){if(!active||busy)return;busy=true;setTimeout(()=>{try{let p=MJKOpportunity.fetchRelay('commodity'),live=!!p;if(!p){const mk=modern()||legacy();if(mk){p={meta:{source:mk.source,timestamp:mk.timestamp,marketStatus:mk.marketStatus,live:mk.live},rows:mk.rows};live=true;}}const r=MJKOpportunity.analyze('commodity',p,notify);render(r,live);}finally{busy=false}},20)}
 function activate(){active=true;if(!timer){run();timer=setInterval(run,60*1000)}}function deactivate(){active=false;if(timer){clearInterval(timer);timer=null}}function init(){document.getElementById('cmRefresh')?.addEventListener('click',run)}return{activate,deactivate,init,run};
})();
