/* MJK market-data + strategy engine. Live, background and backtest share the same rules. */
window.MJK = (() => {
  const KUCOIN = 'https://api.kucoin.com/api/v1';
  const COINGECKO = 'https://api.coingecko.com/api/v3';
  const FALLBACK_TOP = ['BTCUSDT','ETHUSDT','XRPUSDT','BNBUSDT','SOLUSDT','DOGEUSDT','ADAUSDT','TRXUSDT','LINKUSDT','AVAXUSDT'];
  const STABLE = new Set(['USDT','USDC','USDE','DAI','FDUSD','USDS','TUSD','USDD']);
  const TF = '15m';
  const TF_MS = 15 * 60 * 1000;
  const FEE_RATE = 0.0025;
  const START_BALANCE = 1000;
  const RISK_AMOUNT = 10;
  const KEY = 'mjk_state_v3';
  const TOP_CACHE_MS = 30 * 60 * 1000;
  const settings = () => ({notifications: localStorage.getItem('mjk_notify') !== '0', riskAmount: RISK_AMOUNT});

  let connectionFailures = 0;
  let lastMarketSuccessAt = 0;
  const OFFLINE_AFTER_MS = 60000;
  function setConnection(ok){
    if(ok) { connectionFailures = 0; lastMarketSuccessAt = Date.now(); }
    else connectionFailures++;
    const online = ok || (lastMarketSuccessAt > 0 && Date.now()-lastMarketSuccessAt < OFFLINE_AFTER_MS);
    const dot=document.getElementById('conn'), text=document.getElementById('connText');
    if(dot) dot.className='dot '+(online?'good':'bad');
    if(text) text.textContent=online?'آنلاین':'آفلاین';
    return online;
  }
  const connectionSuccess=()=>setConnection(true);
  const connectionFailure=()=>setConnection(false);

  async function apiJson(url){
    try{
      let result;
      if(window.MJKNative && typeof window.MJKNative.fetchJson === 'function'){
        const text=window.MJKNative.fetchJson(url);
        if(typeof text==='string' && text.startsWith('MJK_NATIVE_ERROR:')) throw new Error(text);
        result=JSON.parse(text);
      }else{
        const r=await fetch(url,{cache:'no-store'});
        if(!r.ok) throw new Error(`HTTP ${r.status}`);
        result=await r.json();
      }
      if(/api\.kucoin\.com/i.test(url)) connectionSuccess();
      return result;
    }catch(e){
      if(/api\.kucoin\.com/i.test(url)) setConnection(false);
      throw e;
    }
  }

  function loadState(){
    try{
      const s=JSON.parse(localStorage.getItem(KEY))||{};
      return {activeTrades:s.activeTrades||{},history:s.history||[],backtests:s.backtests||{}};
    }catch(e){return {activeTrades:{},history:[],backtests:[]};}
  }
  function saveState(s){localStorage.setItem(KEY,JSON.stringify(s));}
  function num(v){return Number(v);}

  const INTERVAL_MS={ '1min':60000,'5min':300000,'15m':900000,'15min':900000,'30min':1800000,'1hour':3600000,'4hour':14400000,'1day':86400000 };
  function normalizeKucoinKline(row,interval='15m'){
    const rawTime=num(row[0]);
    const openTime=rawTime<100000000000?rawTime*1000:rawTime;
    const ms=INTERVAL_MS[interval]||TF_MS;
    return [openTime,num(row[1]),num(row[3]),num(row[4]),num(row[2]),num(row[5]),openTime+ms-1];
  }

  async function fetchKlines({symbol='BTCUSDT',interval=TF,startTime,endTime,limit=1000}={}){
    const market=symbol.replace(/USDT$/,'-USDT');
    const apiType=interval==='15m'?'15min':interval;
    const p=new URLSearchParams({symbol:market,type:apiType});
    if(startTime!=null) p.set('startAt',String(Math.floor(startTime/1000)));
    if(endTime!=null) p.set('endAt',String(Math.floor(endTime/1000)));
    if(limit) p.set('limit',String(Math.min(1500,limit)));
    const j=await apiJson(`${KUCOIN}/market/candles?${p.toString()}`);
    if(!j || j.code!=='200000' || !Array.isArray(j.data)) throw new Error(`KuCoin kline error: ${j?.code||'unknown'}`);
    return j.data.map(row=>normalizeKucoinKline(row,interval)).sort((a,b)=>a[0]-b[0]);
  }

  async function fetchRange(startMs,endMs,onProgress){
    let all=[]; let cursor=startMs; let guard=0;
    while(cursor<endMs && guard++<100){
      const batch=await fetchKlines({startTime:cursor,endTime:endMs,limit:1500});
      if(!batch.length) break;
      all=all.concat(batch);
      const last=batch[batch.length-1][0];
      if(last<cursor) break;
      cursor=last+TF_MS;
      if(onProgress) onProgress(Math.min(100,Math.round((cursor-startMs)/(endMs-startMs)*100)));
      if(batch.length<1500) break;
      await new Promise(r=>setTimeout(r,150));
    }
    const seen=new Set();
    return all.filter(c=>{const k=String(c[0]);if(seen.has(k))return false;seen.add(k);return true;}).sort((a,b)=>a[0]-b[0]);
  }

  async function kucoinMarkets(){
    const j=await apiJson(`${KUCOIN}/symbols`);
    if(!j || j.code!=='200000' || !Array.isArray(j.data)) throw new Error('KuCoin symbols error');
    return j.data.filter(x=>x && x.enableTrading!==false);
  }

  async function topSymbols(){
    try{
      const cached=JSON.parse(localStorage.getItem('mjk_top10')||'null');
      if(cached?.symbols?.length===10 && Date.now()-Number(cached.at||0)<TOP_CACHE_MS) return cached.symbols;
    }catch(e){}
    try{
      const [coins,markets]=await Promise.all([
        apiJson(`${COINGECKO}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=50&page=1&sparkline=false`),
        kucoinMarkets()
      ]);
      const available=new Set(markets.filter(x=>x.quoteCurrency==='USDT').map(x=>String(x.symbol).toUpperCase()));
      const out=[];
      for(const x of coins){
        const sym=String(x.symbol||'').toUpperCase();
        if(!sym || STABLE.has(sym)) continue;
        const pair=`${sym}-USDT`;
        if(available.has(pair) && !out.includes(sym+'USDT')) out.push(sym+'USDT');
        if(out.length===10) break;
      }
      if(out.length===10){localStorage.setItem('mjk_top10',JSON.stringify({at:Date.now(),symbols:out}));return out;}
    }catch(e){}
    try{const cached=JSON.parse(localStorage.getItem('mjk_top10')||'null');if(cached?.symbols?.length>=10)return cached.symbols.slice(0,10);}catch(e){}
    return FALLBACK_TOP;
  }

  async function allPrices(){
    const j=await apiJson(`${KUCOIN}/market/allTickers`);
    if(!j || j.code!=='200000' || !j.data?.ticker) throw new Error('KuCoin ticker error');
    return j.data.ticker;
  }

  async function ticker(symbol='BTCUSDT'){
    const market=symbol.replace(/USDT$/,'-USDT');
    const j=await apiJson(`${KUCOIN}/market/stats?symbol=${encodeURIComponent(market)}`);
    if(!j || j.code!=='200000' || !j.data || j.data.last==null) throw new Error(`Ticker error: ${j?.code||'unknown'}`);
    return num(j.data.last);
  }

  function ema(values,period){
    const out=new Array(values.length).fill(null); if(values.length<period)return out;
    let sum=0;for(let i=0;i<period;i++)sum+=values[i];let prev=sum/period;out[period-1]=prev;const k=2/(period+1);
    for(let i=period;i<values.length;i++){prev=(values[i]-prev)*k+prev;out[i]=prev;}return out;
  }
  function atr(candles,period=14){
    const tr=new Array(candles.length).fill(null),out=new Array(candles.length).fill(null);
    for(let i=0;i<candles.length;i++){const h=num(candles[i][2]),l=num(candles[i][3]),pc=i?num(candles[i-1][4]):h;tr[i]=i?Math.max(h-l,Math.abs(h-pc),Math.abs(l-pc)):h-l;}
    if(candles.length<period)return out;let sum=0;for(let i=0;i<period;i++)sum+=tr[i];let prev=sum/period;out[period-1]=prev;
    for(let i=period;i<candles.length;i++){prev=((prev*(period-1))+tr[i])/period;out[i]=prev;}return out;
  }

  function analyze(candles){
    if(!candles||candles.length<210)return null;
    const closes=candles.map(c=>num(c[4])),opens=candles.map(c=>num(c[1])),lows=candles.map(c=>num(c[3]));
    const e20=ema(closes,20),e200=ema(closes,200),a14=atr(candles,14),i=candles.length-1;
    if(e20[i]==null||e200[i]==null||a14[i]==null)return null;
    const conditions={trend:closes[i]>e200[i],cross:e20[i]>e200[i],touch:lows[i]<=e20[i],green:closes[i]>opens[i],closeAbove:closes[i]>e20[i],gap:true};
    const signal=Object.values(conditions).every(Boolean),entry=closes[i],atr14=a14[i];
    return {signal,candle:candles[i],index:i,closeTimeMs:num(candles[i][6]),entry,stopLoss:entry-1.5*atr14,takeProfit:entry+3*atr14,atr:atr14,ema20:e20[i],ema200:e200[i],conditions,candles,closes,e20,e200,a14};
  }

  function toSignal(a,symbol='BTCUSDT'){
    return {id:`${symbol}-${a.closeTimeMs}`,symbol,direction:'BUY',timeframe:'15m',entry_price:a.entry,stop_loss:a.stopLoss,take_profit_1:a.takeProfit,atr:a.atr,ema20:a.ema20,ema200:a.ema200,rr:2,close_time_ms:a.closeTimeMs,created_at:new Date(a.closeTimeMs).toISOString(),reasons:['قیمت بالای EMA200 است','EMA20 بالاتر از EMA200 است','Low کندل EMA20 را لمس کرده','کندل سبز است','بسته‌شدن بالای EMA20 است','حداقل ۱۰ کندل از سیگنال قبلی گذشته است']};
  }

  function isClosed(c){return num(c[6])<Date.now();}
  function diagnose(a,symbol='BTCUSDT'){
    const s=loadState();
    const lastForSymbol=s.history.find(x=>x.direction==='BUY'&&x.symbol===symbol);
    const gapOk=!lastForSymbol||!a||a.closeTimeMs-lastForSymbol.close_time_ms>=10*TF_MS;
    const c=a?.conditions||{};
    const checks=[
      ['trend',c.trend,'قیمت بالای EMA200'],
      ['cross',c.cross,'EMA20 بالاتر از EMA200'],
      ['touch',c.touch,'Low به EMA20 رسیده'],
      ['green',c.green,'کندل سبز'],
      ['closeAbove',c.closeAbove,'بسته‌شدن بالای EMA20'],
      ['gap',gapOk,'فاصله حداقل ۱۰ کندل از سیگنال قبلی']
    ];
    const failed=checks.filter(x=>!x[1]).map(x=>x[2]);
    return {symbol,checks,failed,ready:failed.length===0,lastSignalClose:lastForSymbol?.close_time_ms||0};
  }
  async function latestClosed(symbol='BTCUSDT'){const rows=(await fetchKlines({symbol,limit:220})).filter(isClosed);return {rows,analysis:analyze(rows),diagnostic:rows.length>=210?diagnose(analyze(rows),symbol):{symbol,checks:[],failed:['حداقل ۲۱۰ کندل بسته‌شده دریافت نشد'],ready:false}};}

  function issueIfEligible(a,symbol='BTCUSDT'){
    const s=loadState();if(!a||!a.signal||s.activeTrades[symbol])return null;
    const sig=toSignal(a,symbol);if(s.history.some(x=>x.id===sig.id))return null;
    const lastForSymbol=s.history.find(x=>x.direction==='BUY'&&x.symbol===symbol);
    if(lastForSymbol&&a.closeTimeMs-lastForSymbol.close_time_ms<10*TF_MS)return null;
    s.activeTrades[symbol]={...sig,status:'OPEN',opened_at:new Date().toISOString(),entry_fee:sig.entry_price*FEE_RATE};
    s.history.unshift(s.activeTrades[symbol]);saveState(s);return s.activeTrades[symbol];
  }

  function checkActive(price,symbol='BTCUSDT'){
    const s=loadState(),t=s.activeTrades[symbol];if(!t)return null;let outcome=null;
    if(price<=t.stop_loss)outcome='SL';else if(price>=t.take_profit_1)outcome='TP';else return t;
    const grossR=outcome==='TP'?3:-1,qty=RISK_AMOUNT/(t.entry_price-t.stop_loss),grossPnl=qty*(outcome==='TP'?t.take_profit_1-t.entry_price:t.stop_loss-t.entry_price),fees=(t.entry_price*qty+price*qty)*FEE_RATE,netPnl=grossPnl-fees;
    t.status='CLOSED';t.outcome=outcome;t.close_price=price;t.closed_at=new Date().toISOString();t.r=grossR;t.net_pnl=netPnl;t.fees=fees;
    const idx=s.history.findIndex(x=>x.id===t.id);if(idx>=0)s.history[idx]=t;delete s.activeTrades[symbol];saveState(s);return t;
  }

  const getHistory=()=>loadState().history;
  const getActive=(symbol='BTCUSDT')=>loadState().activeTrades[symbol]||null;
  const getActiveTrades=()=>loadState().activeTrades||{};
  const clearData=()=>localStorage.removeItem(KEY);

  function metrics(trades){
    let equity=START_BALANCE,peak=equity,maxDD=0,grossProfit=0,grossLoss=0,wins=0;const curve=[{time:Date.now(),balance:equity}];
    trades.forEach(t=>{equity+=num(t.net_pnl||0);if(t.net_pnl>0){wins++;grossProfit+=t.net_pnl}else grossLoss+=Math.abs(t.net_pnl||0);peak=Math.max(peak,equity);maxDD=Math.max(maxDD,(peak-equity)/peak*100);curve.push({time:new Date(t.closed_at||t.created_at).getTime(),balance:equity});});
    return {total_trades:trades.length,win_rate:trades.length?wins/trades.length*100:0,profit_factor:grossLoss?grossProfit/grossLoss:(grossProfit?Infinity:0),max_drawdown:maxDD,net_profit_pct:(equity/START_BALANCE-1)*100,equity,curve};
  }

  async function backtest(months,onProgress){
    const end=Date.now(),start=new Date();start.setMonth(start.getMonth()-months);const startMs=start.getTime(),warmup=startMs-220*TF_MS;
    const rows=await fetchRange(warmup,end,onProgress),closed=rows.filter(isClosed),e20=ema(closed.map(c=>num(c[4])),20),e200=ema(closed.map(c=>num(c[4])),200),a14=atr(closed,14);
    let active=null,lastSignal=-Infinity,trades=[];
    for(let i=200;i<closed.length;i++){
      const c=closed[i],close=num(c[4]),open=num(c[1]),low=num(c[3]),high=num(c[2]);
      if(active){let outcome=null,px=null;if(low<=active.sl){outcome='SL';px=active.sl}else if(high>=active.tp){outcome='TP';px=active.tp}if(outcome){const qty=RISK_AMOUNT/(active.entry-active.sl),gross=qty*(px-active.entry),fees=(active.entry*qty+px*qty)*FEE_RATE,net=gross-fees;trades.push({id:active.id,entry:active.entry,close_price:px,sl:active.sl,tp:active.tp,outcome,r:outcome==='TP'?3:-1,net_pnl:net,fees,created_at:new Date(active.time).toISOString(),closed_at:new Date(num(c[6])).toISOString()});active=null;}}
      if(!active&&i-lastSignal>=10&&e20[i]!=null&&e200[i]!=null&&a14[i]!=null&&close>e200[i]&&e20[i]>e200[i]&&low<=e20[i]&&close>open&&close>e20[i]){const entry=close,sl=entry-1.5*a14[i],tp=entry+3*a14[i];active={id:`BT-${num(c[6])}`,entry,sl,tp,time:num(c[6])};lastSignal=i;}
      if(onProgress&&i%250===0)onProgress(Math.min(100,Math.round((i-200)/(closed.length-200)*100)));
    }
    const m=metrics(trades),result={...m,symbol:'BTCUSDT',data_source:'KuCoin spot BTC-USDT',timeframe:'15m',period_start:new Date(startMs).toISOString(),period_end:new Date(end).toISOString(),months,fee_per_side:FEE_RATE,risk_per_trade:RISK_AMOUNT,open_trade_ignored:!!active};
    const s=loadState();s.backtests=Array.isArray(s.backtests)?s.backtests:[];s.backtests.unshift(result);s.backtests=s.backtests.slice(0,10);saveState(s);return result;
  }
  const backtestHistory=()=>loadState().backtests||[];

  return {fetchKlines,fetchRange,latestClosed,ticker,allPrices,topSymbols,analyze,diagnose,toSignal,issueIfEligible,checkActive,getHistory,getActive,getActiveTrades,clearData,backtest,backtestHistory,metrics,settings,FEE_RATE,START_BALANCE,RISK_AMOUNT,connectionSuccess,connectionFailure,TF};
})();
