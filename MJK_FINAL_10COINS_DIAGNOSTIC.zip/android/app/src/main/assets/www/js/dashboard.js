class Dashboard{
  constructor(){this.priceTimer=null;}
  async load(){
    // Dashboard must never stay stuck because top-10 discovery failed.
    // BTC price is independent from the top-10 list shown on Signals.
    const status=document.getElementById('dash-status');
    try{
      const p=await MJK.ticker('BTCUSDT');
      if(Number.isFinite(p)){
        document.getElementById('dashSymbol').textContent='BTCUSDT';
        document.getElementById('price').textContent='$'+p.toLocaleString('en-US',{maximumFractionDigits:2});
        if(status)status.textContent='اتصال زنده به بازار برقرار است';
      }
      MJK.connectionSuccess();
    }catch(e){
      if(status)status.textContent='در انتظار داده بازار…';
    }
    this.renderStats();
    this.renderHistory();
  }
  async refreshPrice(){
    try{
      const p=await MJK.ticker('BTCUSDT');
      if(Number.isFinite(p)){
        document.getElementById('dashSymbol').textContent='BTCUSDT';
        document.getElementById('price').textContent='$'+p.toLocaleString('en-US',{maximumFractionDigits:2});
        document.getElementById('dash-status').textContent='اتصال زنده به بازار برقرار است';
      }
    }catch(e){}
  }
  renderStats(){
    const h=MJK.getHistory(),closed=h.filter(x=>x.status==='CLOSED'),active=MJK.getActiveTrades();
    const dSignals=document.getElementById('dSignals'),dActive=document.getElementById('dActive'),dWin=document.getElementById('dWin'),dPnl=document.getElementById('dPnl');
    if(dSignals)dSignals.textContent=h.filter(x=>new Date(x.created_at).toDateString()===new Date().toDateString()).length;
    if(dActive)dActive.textContent=Object.keys(active).length;
    if(dWin)dWin.textContent=closed.length?(closed.filter(x=>x.outcome==='TP').length/closed.length*100).toFixed(1)+'%':'--';
    if(dPnl)dPnl.textContent='$'+closed.reduce((a,x)=>a+Number(x.net_pnl||0),0).toFixed(2);
    const a=active['BTCUSDT']||Object.values(active)[0];
    const ds=document.getElementById('dSignalState'),de=document.getElementById('dEntry'),dsl=document.getElementById('dSL'),dtp=document.getElementById('dTP');
    if(ds)ds.textContent=a?'سیگنال BUY فعال':'در انتظار سیگنال';
    if(de)de.textContent=a?'$'+Number(a.entry_price).toFixed(2):'—';
    if(dsl)dsl.textContent=a?'$'+Number(a.stop_loss).toFixed(2):'—';
    if(dtp)dtp.textContent=a?'$'+Number(a.take_profit_1).toFixed(2):'—';
  }
  startPriceUpdates(){
    if(this.priceTimer)return;
    this.priceTimer=setInterval(()=>{if(!document.hidden&&window.app?.tab==='dashboard')this.refreshPrice();},2000);
    this.refreshPrice();
  }
  renderHistory(){const all=MJK.getHistory(),h=all.slice(0,8),el=document.getElementById('dHistory');if(el)el.innerHTML=h.length?h.map(x=>`<div class="row"><span>${x.symbol||'—'} · ${new Date(x.created_at).toLocaleString('fa-IR')}</span><span class="${x.status==='CLOSED'?(x.outcome==='TP'?'win':'loss'):'open'}">${x.status==='CLOSED'?(x.outcome==='TP'?'TP':'SL'):'باز'}</span></div>`).join(''):'<div class="empty">هنوز معامله‌ای ثبت نشده است.</div>';const active=MJK.getActiveTrades(),ae=document.getElementById('activeTrade'),he=document.getElementById('history');const arr=Object.values(active);if(ae)ae.innerHTML=arr.length?arr.map(a=>`<div class="signal-main"><b>${a.symbol} · BUY · باز</b><div class="metrics"><div class="metric"><small>Entry</small><b>$${Number(a.entry_price).toFixed(2)}</b></div><div class="metric"><small>SL</small><b>$${Number(a.stop_loss).toFixed(2)}</b></div><div class="metric"><small>TP</small><b>$${Number(a.take_profit_1).toFixed(2)}</b></div></div><p class="muted">زمان: ${new Date(a.created_at).toLocaleString('fa-IR')}</p></div>`).join(''):'<div class="empty">معامله بازی وجود ندارد.</div>';if(he)he.innerHTML=all.length?all.map(x=>`<div class="row"><span>${x.symbol||'—'} · ${new Date(x.created_at).toLocaleString('fa-IR')}</span><span class="${x.status==='CLOSED'?(x.outcome==='TP'?'win':'loss'):'open'}">${x.status==='CLOSED'?(x.outcome==='TP'?'TP':'SL'):'OPEN'} ${x.status==='CLOSED'?' · $'+Number(x.net_pnl).toFixed(2):''}</span></div>`).join(''):'<div class="empty">تاریخچه خالی است.</div>';const ts=document.getElementById('tradeState');if(ts)ts.textContent=arr.length?`${arr.length} فعال`:'بدون معامله';}
}
window.dashboard=new Dashboard();
