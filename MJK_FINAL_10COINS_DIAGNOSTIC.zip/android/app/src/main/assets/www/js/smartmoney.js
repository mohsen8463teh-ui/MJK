/* MJK Smart Money: live, source-attributed data only. No fake values. */
window.smartmoney = (() => {
  const CMC='https://pro-api.coinmarketcap.com/public-api';
  const IBIT='https://www.ishares.com/us/products/333011/ishares-bitcoin-trust';
  const state={symbol:'BTCUSDT',timer:null,loading:false,lastIbitQty:null};
  const $=id=>document.getElementById(id);
  const topMap={BTCUSDT:{platform:'ethereum',address:'0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',label:'WBTC'},ETHUSDT:{platform:'ethereum',address:'0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',label:'WETH'},BNBUSDT:{platform:'bsc',address:'0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',label:'WBNB'},SOLUSDT:{platform:'solana',address:'So11111111111111111111111111111111111111112',label:'WSOL'}};
  const num=v=>{const n=Number(String(v??'').replace(/,/g,''));return Number.isFinite(n)?n:null;};
  const money=v=>{const n=num(v);if(n==null)return '—';return '$'+n.toLocaleString('en-US',{maximumFractionDigits:0});};
  const native=(url)=>{if(window.MJKNative?.fetchJson)return JSON.parse(MJKNative.fetchJson(url));return null;};
  const post=(url,b)=>{if(window.MJKNative?.fetchJsonPost)return JSON.parse(MJKNative.fetchJsonPost(url,JSON.stringify(b)));return null;};
  const text=(url)=>window.MJKNative?.fetchText?MJKNative.fetchText(url):'';
  function set(id,html){const e=$(id);if(e)e.innerHTML=html;}
  function status(ok,msg){$('smStatus').textContent=msg; $('smStatus').className='subtle';}
  function parseIbit(html){
    if(!html||html.startsWith('MJK_NATIVE_ERROR:'))throw new Error(html||'iShares unavailable');
    let qty=null, mv=null, date=null;
    const patterns=[/"quantity"\s*:\s*"?([0-9,]+(?:\.[0-9]+)?)"?/i,/quantity[^0-9]{0,80}([0-9,]+(?:\.[0-9]+)?)/i,/BITCOIN[\s\S]{0,1800}?([0-9,]+(?:\.[0-9]+)?)\s*<\/td>/i];
    for(const r of patterns){const m=html.match(r);if(m){qty=num(m[1]);if(qty!=null)break;}}
    const mvM=html.match(/"marketValue"\s*:\s*"?\$?([0-9,]+(?:\.[0-9]+)?)"?/i);if(mvM)mv=num(mvM[1]);
    const d=html.match(/as of ([A-Z][a-z]{2}\s+\d{1,2},\s+202\d)/i);if(d)date=d[1];
    if(qty==null)throw new Error('مقدار BTC در صفحه رسمی iShares قابل استخراج نبود');
    return {qty,mv,date};
  }
  async function loadIbit(){
    try{
      const r=parseIbit(text(IBIT));
      const prev=state.lastIbitQty; state.lastIbitQty=r.qty;
      const delta=prev==null?null:r.qty-prev;
      const direction=delta==null?'baseline':delta>0?'افزایش موجودی':delta<0?'کاهش موجودی':'بدون تغییر';
      $('ibitBadge').textContent=direction==='baseline'?'مبنای اولیه':direction; $('ibitBadge').className='badge '+(delta>0?'win':delta<0?'loss':'');
      set('ibitBody',`<div class="smart-metric"><span>BTC موجود در IBIT</span><b>${r.qty.toLocaleString('en-US',{maximumFractionDigits:5})} BTC</b></div><div class="smart-metric"><span>تغییر از آخرین بررسی برنامه</span><b>${delta==null?'اولین دریافت':(delta>0?'+':'')+delta.toLocaleString('en-US',{maximumFractionDigits:5})+' BTC'}</b></div><div class="smart-meta">منبع رسمی: iShares / BlackRock${r.date?' · '+r.date:''}</div>`);
    }catch(e){$('ibitBadge').textContent='داده در دسترس نیست';set('ibitBody',`<div class="empty">${e.message||e}</div>`);}
  }
  function pickResult(d,symbol){const arr=d?.data?.tks||d?.data||[];return Array.isArray(arr)?(arr.find(x=>String(x.s||x.sym||'').toUpperCase()===symbol)||arr.find(x=>String(x.s||x.sym||'').toUpperCase().replace(/^W/,'')===symbol))||arr[0]:null;}
  async function resolveToken(symbol){
    if(topMap[symbol])return topMap[symbol];
    const base=symbol.replace('USDT','');
    try{const d=native(CMC+'/v1/dex/search?q='+encodeURIComponent(base)+'&limit=10');const x=pickResult(d,base);if(x?.addr&&x?.plt)return {platform:x.plt,address:x.addr,label:x.s||base};}catch(_){ }
    return null;
  }
  async function loadWhales(){
    const cfg=await resolveToken(state.symbol); if(!cfg){$('whaleBadge').textContent='پوشش آنچین کافی نیست';set('whaleBody','<div class="empty">برای این ارز منبع آنچین معتبر در سرویس فعلی پیدا نشد؛ عددی جعل نمی‌شود.</div>');set('smartBuys','<div class="empty">برای این ارز خرید آنچین قابل‌تأیید پیدا نشد.</div>');return;}
    try{
      const q=`${CMC}/v1/dex/tokens/transactions?platform=${encodeURIComponent(cfg.platform)}&address=${encodeURIComponent(cfg.address)}&type=0&limit=20&sortBy=time&sortType=desc&minVolume=100000`;
      const d=native(q); const rows=d?.data?.swaps||d?.swaps||d?.data?.transactions||d?.data||[]; const arr=Array.isArray(rows)?rows:[];
      const buys=arr.map(x=>({time:x.ts||x.time||x.t||0,usd:num(x.v||x.volume||x.volumeUsd||x.usdVolume||x.q),price:num(x.t0pu||x.t1pu||x.price||x.p),maker:x.ma||x.maker||x.makerAddress||x.wallet||'',tx:x.tx||x.txHash||x.hash||''})).filter(x=>x.usd!=null).slice(0,10);
      $('whaleBadge').textContent=buys.length?'داده زنده':'بدون خرید قابل‌تأیید'; $('whaleBadge').className='badge '+(buys.length?'win':'');
      const total=buys.reduce((s,x)=>s+x.usd,0);
      set('whaleBody',`<div class="smart-metric"><span>خریدهای آنچین بزرگ</span><b>${buys.length}</b></div><div class="smart-metric"><span>حجم خریدهای نمایش‌داده‌شده</span><b>${money(total)}</b></div><div class="smart-meta">${cfg.label} · ${cfg.platform} · حداقل $100,000 برای هر رویداد</div>`);
      set('smartBuys',buys.length?buys.map(x=>`<div class="smart-row"><div><b>${cfg.label}</b><small>${x.maker?x.maker.slice(0,10)+'…':''}</small></div><strong>${money(x.usd)}</strong><span>${x.time?new Date(x.time>2e12?x.time:x.time*1000).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'}):'—'}</span></div>`).join(''):'<div class="empty">در بازه فعلی خرید بزرگ قابل‌تأیید پیدا نشد.</div>');
      try{
        const h=post(CMC+'/v1/dex/holders/list',{tokenAddress:cfg.address,platform:cfg.platform,tag:'tag_smart_money'}); const hs=h?.data?.holders||h?.holders||[]; const active=Array.isArray(hs)?hs.slice(0,5):[];
        if(active.length){const net=active.reduce((s,x)=>s+(num(x.netBuyAmount)||0),0);set('whaleBody',`<div class="smart-metric"><span>کیف پول‌های Smart Money</span><b>${active.length}+</b></div><div class="smart-metric"><span>Net Buy (Top results)</span><b>${net>=0?'+':''}${net.toLocaleString('en-US',{maximumFractionDigits:4})}</b></div><div class="smart-meta">برچسب‌گذاری و آمار از CoinMarketCap DEX · ${cfg.platform}</div>`);}
      }catch(_){ }
    }catch(e){$('whaleBadge').textContent='خطا';set('whaleBody',`<div class="empty">داده آنچین دریافت نشد: ${e.message||e}</div>`);set('smartBuys','<div class="empty">داده خرید قابل‌تأیید دریافت نشد.</div>');}
  }
  async function load(){if(state.loading)return;state.loading=true;status(false,'در حال دریافت داده زنده…');await Promise.allSettled([loadIbit(),loadWhales()]);status(true,'آخرین بررسی: '+new Date().toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit',second:'2-digit'}));state.loading=false;}
  async function activate(){const sym=$('smSymbol');if(sym.options.length===0){const top=await MJK.topSymbols();sym.innerHTML=top.map(s=>`<option value="${s}">${s}</option>`).join('');}state.symbol=sym.value||'BTCUSDT';if(!state.timer){sym.onchange=()=>{state.symbol=sym.value;load();};$('smRefresh').onclick=load;await load();state.timer=setInterval(()=>{if(window.app?.tab==='smartmoney')load();},60000);}}
  return {activate,load};
})();
