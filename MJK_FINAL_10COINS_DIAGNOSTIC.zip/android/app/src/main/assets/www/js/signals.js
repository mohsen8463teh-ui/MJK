class Signals{
  constructor(){this.symbols=[];this.busy=false;this.lastChecked=0;this.bind();this.timer=setInterval(()=>this.check(false),15000);}
  bind(){document.getElementById('checkSignal')?.addEventListener('click',()=>this.check(true));}
  async check(manual=false){
    if(this.busy)return;
    this.busy=true;this.lastChecked=Date.now();
    const started=this.lastChecked;
    try{
      this.symbols=await MJK.topSymbols();
      const results=await Promise.all(this.symbols.map(async symbol=>{
        try{
          const latest=await MJK.latestClosed(symbol);
          const analysis=latest.analysis;
          const diagnostic=latest.diagnostic||MJK.diagnose(analysis,symbol);
          const issued=MJK.issueIfEligible(analysis,symbol);
          const price=await MJK.ticker(symbol);
          const closed=MJK.checkActive(price,symbol);
          if(closed){window.app?.toast(`${symbol}: ${closed.outcome==='TP'?'حد سود':'حد ضرر'} | R=${Number(closed.r).toFixed(2)}`,closed.outcome==='TP'?'ok':'err');window.MJKNative?.tradeClosed?.(JSON.stringify(closed));}
          const active=MJK.getActive(symbol);
          if(issued){window.app?.toast(`سیگنال BUY جدید: ${symbol}`,'ok');window.MJKNative?.signalIssued?.(JSON.stringify(issued));return {...issued,diagnostic};}
          if(active)return {...active,diagnostic};
          if(analysis)return {...analysis,symbol,diagnostic};
          return {symbol,diagnostic,error:false};
        }catch(e){return {symbol,error:true,errorMessage:String(e?.message||e||'خطای نامشخص')};}
      }));
      this.render(results);
      const successes=results.filter(x=>x&&!x.error).length;
      if(successes)MJK.connectionSuccess();
      const elapsed=((Date.now()-started)/1000).toFixed(1);
      document.getElementById('liveStatus').textContent=`${successes}/${this.symbols.length} ارز بررسی شد · ${elapsed} ثانیه · ${new Date().toLocaleTimeString('fa-IR')}`;
    }catch(e){
      document.getElementById('liveStatus').textContent='دریافت فهرست ارزها ناموفق بود · تلاش مجدد خودکار';
      if(manual)window.app?.toast('دریافت داده بازار ناموفق بود','err');
      this.render(this.symbols.map(symbol=>({symbol,error:true,errorMessage:String(e?.message||e||'خطای نامشخص')})));
    }finally{this.busy=false;}
  }
  render(items){
    const box=document.getElementById('signalBox');if(!box)return;
    if(!items.length){box.innerHTML='<div class="empty">فهرست ۱۰ ارز دریافت نشد.</div>';return;}
    const labels={trend:'قیمت بالای EMA200',cross:'EMA20 بالاتر از EMA200',touch:'Low به EMA20 رسیده',green:'کندل سبز',closeAbove:'بسته‌شدن بالای EMA20',gap:'فاصله ۱۰ کندل'};
    box.innerHTML=items.map(x=>{
      const d=x.diagnostic;
      const active=x.entry_price!=null&&x.stop_loss!=null;
      const entry=active?x.entry_price:x.entry,sl=active?x.stop_loss:x.stop_loss??x.stopLoss,tp=active?x.take_profit_1:x.takeProfit;
      if(x.error)return `<div class="signal-card signal-error"><div class="signal-top"><b>${x.symbol||'—'}</b><span class="status-badge bad">خطا</span></div><p class="muted">${this.esc(x.errorMessage||'دریافت داده ناموفق بود')}</p></div>`;
      const failed=(d?.failed||[]);
      const status=active?'BUY فعال':(d?.ready?'سیگنال آماده':'بدون سیگنال');
      const cls=active?'live':(d?.ready?'ready':'');
      const checks=(d?.checks||[]).map(([key,ok])=>`<span class="cond ${ok?'ok':'fail'}">${ok?'✓':'✕'} ${labels[key]||key}</span>`).join('');
      return `<div class="signal-card"><div class="signal-top"><b>${x.symbol||'—'}</b><span class="status-badge ${cls}">${status}</span></div>${entry!=null?`<div class="metrics"><div class="metric"><small>Entry</small><b>$${Number(entry).toFixed(4)}</b></div><div class="metric"><small>SL</small><b>$${Number(sl).toFixed(4)}</b></div><div class="metric"><small>TP</small><b>$${Number(tp).toFixed(4)}</b></div></div>`:''}<div class="conditions">${checks}</div>${failed.length&&!active?`<div class="reason">علت عدم سیگنال: ${this.esc(failed.join(' · '))}</div>`:''}<div class="check-time">آخرین بررسی: ${new Date().toLocaleTimeString('fa-IR')}</div></div>`;
    }).join('');
  }
  esc(v){return String(v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
}
window.signals=new Signals();
