/* MJK Iran Stock Radar V15: live TSETMC legacy MarketWatch fallback + modern APIs. No fabricated data. */
window.iranStocks=(()=>{
 let active=false,timer=null,busy=false;
 const WEB='https://webgw.tse.ir', CDN='https://cdn.tsetmc.com/api', OLD='http://old.tsetmc.com/tsev2/data';
 const json=u=>{try{const t=window.MJKNative?.fetchJson?.(u);if(!t||String(t).startsWith('MJK_NATIVE_ERROR:'))return null;return JSON.parse(t);}catch(e){return null;}};
 const text=u=>{try{const t=window.MJKNative?.fetchText?.(u);if(!t||String(t).startsWith('MJK_NATIVE_ERROR:'))return null;return String(t);}catch(e){return null;}};
 const n=v=>{if(v&&typeof v==='object')v=v.value??v.Value??v.val??v.amount??v.Amount;const x=Number(String(v??'').replace(/,/g,''));return Number.isFinite(x)?x:null;};
 const clean=s=>String(s??'').replace(/^\s+|\s+$/g,'');
 const pick=(o,ks)=>{for(const k of ks)if(o?.[k]!=null&&o[k]!=='')return o[k];return null;};
 function arrays(o){const out=[],seen=new Set();const walk=x=>{if(!x||typeof x!=='object'||seen.has(x))return;seen.add(x);if(Array.isArray(x)){if(x.length&&typeof x[0]==='object')out.push(x);for(const y of x.slice(0,8))walk(y);}else Object.keys(x).forEach(k=>walk(x[k]));};walk(o);return out;}
 function legacyMarket(){
   const raw=text(`${OLD}/MarketWatchInit.aspx?h=0&r=0`); if(!raw)return null;
   const p=raw.split('@'); if(p.length<5)return null;
   const state=clean(p[1]);
   const rows=clean(p[2]).split(';').filter(Boolean).map(r=>r.split(','));
   const best=clean(p[3]).split(';').filter(Boolean).map(r=>r.split(','));
   const bestMap=new Map();
   for(const r of best){if(r.length>=8&&!bestMap.has(r[0]))bestMap.set(r[0],r);}
   const items=[];
   for(const r of rows){
     if(r.length<20)continue;
     const flow=n(r[17]);
     if(![1,2,4].includes(flow))continue;
     const x={insCode:r[0],isin:r[1],symbol:r[2],company:r[3],first:n(r[5]),close:n(r[6]),last:n(r[7]),trades:n(r[8]),vol:n(r[9]),value:n(r[10]),low:n(r[11]),high:n(r[12]),open:n(r[13]),eps:n(r[14]),baseVol:n(r[15]),flow,sector:r[18]||'',max:n(r[19]),min:n(r[20]),shares:n(r[21]),state:state};
     const b=bestMap.get(r[0]); if(b){x.bestSellCount=n(b[2]);x.bestBuyCount=n(b[3]);x.bestBuy=n(b[4]);x.bestSell=n(b[5]);x.bestBuyVol=n(b[6]);x.bestSellVol=n(b[7]);}
     if(x.last==null)x.last=x.close;
     if(x.last!=null&&r[13]!=null&&x.close!=null)x.chg=x.close&&r[6]?((x.close-n(r[13]))/Math.max(1,n(r[13]))*100):null;
     const py=n(r[13]); if(x.last!=null&&py)x.chg=(x.last-py)/py*100;
     items.push(x);
   }
   return {rows:items,source:'TSETMC legacy MarketWatch',state};
 }
 function modernMarket(){
   const urls=[`${WEB}/InstrumentProvider/api/v1/MarketWatch/MarketWatchCash/fa`,`${WEB}/InstrumentProvider/api/v1/Instrument/InstrumentSliderQuery/fa`,`${CDN}/ClosingPrice/GetMarketWatch?market=0&paperTypes[0]=1&paperTypes[1]=2&paperTypes[2]=3&paperTypes[3]=4&paperTypes[4]=5&paperTypes[5]=6&paperTypes[6]=7&paperTypes[7]=8&paperTypes[8]=9&withBestLimits=false&hEven=0&RefID=0`];
   for(const u of urls){const j=json(u);if(!j)continue;for(const a of arrays(j)){if(a.some(x=>pick(x,['insCode','instrumentId','lVal18','lVal18AFC','instrumentName','instrument_Name','pDrCotVal','lastPrice'])))return {rows:a.map(x=>({insCode:String(pick(x,['insCode','inscode','InsCode'])??''),isin:String(pick(x,['instrumentId','InstrumentId'])??''),symbol:String(pick(x,['instrumentName','instrument_Name','lVal18AFC','lVal18','symbol'])??''),company:String(pick(x,['companyNamePersian','lVal30','companyName'])??''),last:n(pick(x,['lastPrice','lastprice','pDrCotVal','pl'])),close:n(pick(x,['closingPrice','pClosing','pc'])),prev:n(pick(x,['yesterdayPrice','priceYesterday','py'])),chg:n(pick(x,['pricechangepercent','lastpricechangepercent','changePercent','pct'])),vol:n(pick(x,['tradeVolume','qTotTran5J','volume'])),value:n(pick(x,['tradeValue','qTotCap','value'])),trades:n(pick(x,['tradeCount','zTotTran'])),eps:n(pick(x,['eps','EPS'])),pe:n(pick(x,['pe','pE'])),industry:String(pick(x,['industryName','industry'])??''),state:String(pick(x,['stateName','state'])??'')})),source:u};}}
   return null;
 }
 function market(){return legacyMarket()||modernMarket()||{rows:[],source:'none'};}
 function clientFlow(){
   const raw=text(`${OLD}/ClientTypeAll.aspx`);if(!raw)return new Map();const m=new Map();
   for(const r of raw.split(';').filter(Boolean)){const a=r.split(',');if(a.length<9)continue;const ins=clean(a[0]);m.set(ins,{naturalBuy:n(a[3]),legalBuy:n(a[4]),naturalSell:n(a[7]),legalSell:n(a[8])});}return m;
 }
 function history(x){
   if(!x.insCode)return[];const raw=text(`${OLD}/InstTradeHistory.aspx?i=${encodeURIComponent(x.insCode)}&Top=80&A=0`);if(!raw)return[];
   return raw.split(';').filter(Boolean).map(r=>{const a=r.split(',');if(a.length<10)return null;return{date:a[0],high:n(a[1]),low:n(a[2]),close:n(a[3]),last:n(a[4]),value:n(a[7]),vol:n(a[8])};}).filter(r=>r&&r.close!=null).reverse();
 }
 function ema(v,p){if(v.length<p)return null;let e=v.slice(0,p).reduce((a,b)=>a+b,0)/p,k=2/(p+1);for(let i=p;i<v.length;i++)e=(v[i]-e)*k+e;return e;}
 function rsi(v,p=14){if(v.length<=p)return null;let g=0,l=0;for(let i=1;i<=p;i++){const d=v[i]-v[i-1];g+=Math.max(d,0);l+=Math.max(-d,0);}g/=p;l/=p;for(let i=p+1;i<v.length;i++){const d=v[i]-v[i-1];g=(g*(p-1)+Math.max(d,0))/p;l=(l*(p-1)+Math.max(-d,0))/p;}return l===0?100:100-100/(1+g/l);}
 function technical(h){const c=h.map(x=>x.close).filter(Number.isFinite);if(c.length<30)return{score:0,ok:false};const e20=ema(c,20),e50=ema(c,50),r=rsi(c),last=c.at(-1);let s=0;if(e20&&last>e20)s+=25;if(e50&&last>e50)s+=20;if(e20&&e50&&e20>e50)s+=20;if(r!=null&&r>=52&&r<=72)s+=15;const a=c.slice(-20),sl=(a.at(-1)-a[0])/Math.max(1,a[0])*100;if(sl>2)s+=15;else if(sl>0)s+=8;return{score:Math.min(100,s),ok:true};}
 function render(rows,source,reason=''){const top=document.getElementById('irTop'),main=document.getElementById('irMain'),st=document.getElementById('irStatus');if(!rows.length){if(top)top.innerHTML='<div class="empty">هیچ داده واقعی از TSETMC دریافت نشد؛ هیچ سهمی حدسی نمایش داده نمی‌شود.</div>';if(main)main.innerHTML=`<div class="empty">${reason||'منبع بازار پاسخ نداد.'}</div>`;if(st)st.textContent='بدون داده معتبر · '+source;return;}if(top)top.innerHTML=rows.map((r,i)=>`<div class="ir-row"><div><b>${i+1}. ${r.symbol||'—'}</b><small>${r.company||'—'}</small></div><strong>${r.score}</strong><span>${r.chg==null?'—':r.chg.toFixed(2)+'%'} · اجماع ${r.consensus}/5</span></div>`).join('');const z=rows[0];if(main)main.innerHTML=`<div class="ir-main"><div><small>برترین گزینه داده‌محور · ${z.source}</small><b>${z.symbol}</b><span>${z.company||''}</span></div><strong>${z.score}/100</strong></div><div class="ir-grid"><span>تکنیکال: ${z.tech}</span><span>تابلو/جریان: ${z.flow}</span><span>بنیادی قابل‌استخراج: ${z.fund}</span><span>صنعت: ${z.macro}</span><span>ریسک/وضعیت: ${z.risk}</span><span>حقیقی/حقوقی: ${z.client}</span></div>`;if(st)st.textContent=`${rows.length} سهم · ${source} · ${new Date().toLocaleTimeString('fa-IR')}`;}
 function run(){if(!active||busy)return;busy=true;setTimeout(()=>{try{const mk=market();if(!mk.rows.length){render([],mk.source,'اتصال به TSETMC برقرار نشد. اگر بازار باز است، محدودیت شبکه/IP یا دسترسی اپراتور به منبع باید بررسی شود.');return;}const cf=clientFlow();const raw=mk.rows.filter(x=>x.symbol&&x.last!=null).map(x=>{const c=cf.get(x.insCode)||{};const net=((c.naturalBuy||0)-(c.naturalSell||0));const totalFlow=(c.naturalBuy||0)+(c.legalBuy||0)+(c.naturalSell||0)+(c.legalSell||0);const flow=(x.chg||0)>1?8:((x.chg||0)>0?4:0);const client=totalFlow?Math.max(0,Math.min(12,Math.round(net/Math.max(1,totalFlow)*20+6))):0;const fund=(x.eps!=null&&x.eps>0?8:0)+(x.eps!=null&&x.eps>0&&x.last/x.eps<25?7:0);const macro=x.sector?5:0;const risk=(x.state.includes('مجاز')||!x.state)?3:0;return{...x,client,flow:flow+client, fund,macro,risk};}).filter(x=>(x.value||x.vol||0)>0).sort((a,b)=>(b.value||0)-(a.value||0)).slice(0,12);const out=raw.map(x=>{const t=technical(history(x));const score=Math.min(100,t.score+x.flow+x.fund+x.macro+x.risk);const agree=[t.score>=55,x.flow>=8,x.fund>=8,x.macro>=5,x.risk>=3].filter(Boolean).length;return{...x,tech:t.score,score,consensus:agree,source:mk.source};});render(out.sort((a,b)=>b.score-a.score).slice(0,10),mk.source);}finally{busy=false;}},20);}
 function activate(){active=true;if(!timer){run();timer=setInterval(run,5*60*1000);}}function deactivate(){active=false;if(timer){clearInterval(timer);timer=null;}}function init(){document.getElementById('irRefresh')?.addEventListener('click',run);}return{activate,deactivate,init,run};
})();
