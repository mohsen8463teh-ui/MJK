/* MJK Iran Stock Radar: transparent multi-engine consensus, live TSETMC data. */
window.iranStocks = (() => {
  let active=false, timer=null, busy=false, lastRun=0;
  const WEB='https://webgw.tse.ir';
  const CDN='https://cdn.tsetmc.com/api';
  const nativeGet=(url)=>{
    try{
      if(window.MJKNative?.fetchJson){const t=window.MJKNative.fetchJson(url); if(String(t).startsWith('MJK_NATIVE_ERROR:')) throw new Error(t); return JSON.parse(t);}
      return null;
    }catch(e){return null;}
  };
  const n=v=>{if(v==null)return null; if(typeof v==='object'&&'value' in v)v=v.value; const x=Number(String(v).replace(/,/g,'')); return Number.isFinite(x)?x:null;};
  const pct=v=>n(v);
  function unwrap(x){return x?.Items||x?.items||x?.marketwatch||x?.data||x;}
  function market(){
    let j=nativeGet(`${WEB}/InstrumentProvider/api/v1/MarketWatch/MarketWatchCash/fa`);
    let a=unwrap(j); if(Array.isArray(a)&&a.length)return a;
    j=nativeGet(`${CDN}/ClosingPrice/GetMarketWatch?market=0&paperTypes[0]=1&paperTypes[1]=2&paperTypes[2]=3&paperTypes[3]=4&paperTypes[4]=5&paperTypes[5]=6&paperTypes[6]=7&paperTypes[7]=8&paperTypes[8]=9&withBestLimits=false&hEven=0&RefID=0`);
    a=unwrap(j); return Array.isArray(a)?a:[];
  }
  function norm(x){
    return {isin:x.instrumentId||x.instrumentid||x.cIsin||'', symbol:x.instrumentName||x.instrument_Name||x.lVal18AFC||x.symbol||'', company:x.companyNamePersian||x.company_Name_Persian||x.lVal30||'',
      last:n(x.lastPrice||x.lastprice||x.pDrCotVal||x.pl), close:n(x.closingPrice||x.closingprice||x.pClosing||x.pc), prev:n(x.yesterdayPrice||x.priceYesterday||x.py),
      chg:pct(x.lastPrice?.percent||x.lastpricechangepercent||x.pricechangepercent||x.pct||x.pChange), vol:n(x.tradeVolume||x.qTotTran5J||x.qTotTran), value:n(x.tradeValue||x.qTotCap||x.qTotCap), trades:n(x.tradeCount||x.zTotTran),
      eps:n(x.eps||x.estimatedEPS), pe:n(x.pe||x.pE||x.sectorPE), industry:x.industryname||x.industryName||x.industry||'', state:x.stateName||x.statename||''};
  }
  function history(isin,symbol){
    let j=null;
    if(isin) j=nativeGet(`${WEB}/InstrumentProvider/api/v1/History/Archive/fa?InstrumentId=${encodeURIComponent(isin)}`);
    let a=unwrap(j);
    if(!Array.isArray(a)&&symbol){j=nativeGet(`${CDN}/Instrument/GetInstrumentSearch/${encodeURIComponent(symbol)}`); const s=unwrap(j); const id=Array.isArray(s)?(s[0]?.insCode||s[0]?.instrumentId):null; if(id){j=nativeGet(`${CDN}/ClosingPrice/GetClosingPriceDailyList/${id}/300`);a=unwrap(j);}}
    if(!Array.isArray(a))return [];
    return a.map(r=>({date:r.devenrlc||r.dEven||r.date||r.t||0, close:n(r.closingprice||r.closingPrice||r.pc||r.c), high:n(r.highvalue||r.highPrice||r.ph), low:n(r.lowvalue||r.lowPrice||r.pl), vol:n(r.tradevolume||r.volume||r.v), value:n(r.tradevalue||r.value||r.qTotCap)})).filter(r=>r.close!=null).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
  }
  function ema(vals,p){if(vals.length<p)return null;let s=0;for(let i=0;i<p;i++)s+=vals[i];let e=s/p,k=2/(p+1);for(let i=p;i<vals.length;i++)e=(vals[i]-e)*k+e;return e;}
  function rsi(vals,p=14){if(vals.length<=p)return null;let g=0,l=0;for(let i=1;i<=p;i++){let d=vals[i]-vals[i-1];if(d>=0)g+=d;else l-=d;}g/=p;l/=p;for(let i=p+1;i<vals.length;i++){let d=vals[i]-vals[i-1];g=(g*(p-1)+Math.max(d,0))/p;l=(l*(p-1)+Math.max(-d,0))/p;}if(l===0)return 100;return 100-100/(1+g/l);}
  function technical(h){const c=h.map(x=>x.close); if(c.length<60)return {score:0,ok:false,reason:'تاریخچه ناکافی'};const e20=ema(c,20),e50=ema(c,50),e200=ema(c,200),r=rsi(c),last=c[c.length-1];let score=0; if(e20&&last>e20)score+=18;if(e50&&last>e50)score+=15;if(e200&&last>e200)score+=18;if(e20&&e50&&e20>e50)score+=12;if(e50&&e200&&e50>e200)score+=12;if(r!=null&&r>=52&&r<=72)score+=10; const n20=c.slice(-20);const slope=(n20[n20.length-1]-n20[0])/Math.max(1,n20[0])*100;if(slope>2)score+=10; else if(slope>0)score+=5;return {score:Math.min(100,score),ok:true,rsi:r,e20,e50,e200,slope};}
  function rank(items){return items.sort((a,b)=>b.score-a.score).slice(0,10);}
  function render(rows,stamp){const box=document.getElementById('irTop'); if(!box)return; if(!rows.length){box.innerHTML='<div class="empty">داده معتبر کافی برای رتبه‌بندی بازار دریافت نشد.</div>';return;}box.innerHTML=rows.map((r,i)=>`<div class="ir-row"><div><b>${i+1}. ${r.symbol||'—'}</b><small>${r.company||r.industry||'—'}</small></div><strong>${r.score}</strong><span>${r.consensus}</span></div>`).join('');document.getElementById('irStatus').textContent=`آخرین تحلیل: ${stamp}`;document.getElementById('irMain').innerHTML=`<div class="ir-main"><div><small>انتخاب اول</small><b>${rows[0].symbol}</b><span>${rows[0].company||''}</span></div><strong>${rows[0].score}/100</strong></div><div class="ir-grid"><span>تکنیکال: ${rows[0].tech}</span><span>تابلو/پول: ${rows[0].flow}</span><span>بنیادی: ${rows[0].fund}</span><span>صنعت/اقتصاد: ${rows[0].macro}</span><span>خبر/ریسک: ${rows[0].risk}</span><span>اجماع: ${rows[0].consensus}</span></div><p class="muted">این رتبه‌بندی «احتمال حرکت کوتاه‌مدت» است، نه تضمین رشد دو روزه. اگر داده معتبر کافی نباشد، سهم معرفی نمی‌شود.</p>`;}
  function run(){if(!active||busy)return;busy=true;setTimeout(()=>{try{const raw=market().map(norm).filter(x=>x.symbol&&x.last!=null);const liquid=raw.filter(x=>(x.value||0)>0).sort((a,b)=>(b.value||0)-(a.value||0)).slice(0,35);const out=[];for(const x of liquid.slice(0,18)){const h=history(x.isin,x.symbol);const t=technical(h);let flow=0,fund=0,macro=0,risk=0;if((x.chg||0)>1)flow+=10;if((x.vol||0)>0&&x.value)flow+=Math.min(10,Math.round((x.value/Math.max(1,liquid[0].value))*10));if(x.eps!=null&&x.eps>0)fund+=10;if(x.pe!=null&&x.pe>0&&x.pe<15)fund+=8;if(x.pe!=null&&x.pe>0&&x.pe<25)fund+=4; if(x.industry)macro+=5;if((x.chg||0)>0)macro+=3; if((x.state||'').includes('مجاز'))risk+=2; const score=Math.min(100,t.score+flow+fund+macro+risk); const agree=[t.score>=60,flow>=10,fund>=10,macro>=5,risk>=2].filter(Boolean).length;out.push({...x,score,tech:t.score,flow,fund,macro,risk,consensus:`${agree}/5`});}render(rank(out),new Date().toLocaleTimeString('fa-IR'));}catch(e){const s=document.getElementById('irStatus');if(s)s.textContent='خطا در دریافت داده بازار';}finally{busy=false;}},30);}
  function activate(){active=true;if(!timer){run();timer=setInterval(run,15*60*1000);}}
  function deactivate(){active=false;if(timer){clearInterval(timer);timer=null;}}
  function init(){document.getElementById('irRefresh')?.addEventListener('click',run);}
  return {activate,deactivate,init,run};
})();
