/* MJK Iran Opportunity Radar v3: relay-first, depth + money-flow aware, last-valid cache. */
window.iranStocks=(()=>{
 let active=false,timer=null,busy=false;
 const CDN='https://cdn.tsetmc.com/api',OLD='http://old.tsetmc.com/tsev2/data';
 const json=u=>{try{const t=window.MJKNative?.fetchJson?.(u);if(!t||String(t).startsWith('MJK_NATIVE_ERROR:'))return null;return JSON.parse(t)}catch(_){return null}};
 const text=u=>{try{const t=window.MJKNative?.fetchText?.(u);if(!t||String(t).startsWith('MJK_NATIVE_ERROR:'))return null;return String(t)}catch(_){return null}};
 const n=v=>{if(v&&typeof v==='object')v=v.value??v.Value??v.val??v.amount??v.Amount;const x=Number(String(v??'').replace(/,/g,''));return Number.isFinite(x)?x:null};
 const clean=s=>String(s??'').trim();
 function legacy(){const raw=text(`${OLD}/MarketWatchInit.aspx?h=0&r=0`);if(!raw)return null;const p=raw.split('@');if(p.length<5)return null;const state=clean(p[1]),rows=p[2].split(';').filter(Boolean).map(r=>r.split(',')),best=p[3].split(';').filter(Boolean).map(r=>r.split(',')),bm=new Map();best.forEach(r=>{if(r.length>=8&&!bm.has(r[0]))bm.set(r[0],r)});const out=[];for(const r of rows){if(r.length<22)continue;const flow=n(r[17]);if(![1,2,4].includes(flow))continue;const last=n(r[7]),prev=n(r[13]);if(last==null)continue;const b=bm.get(r[0]);out.push({insCode:r[0],isin:r[1],symbol:r[2],company:r[3],first:n(r[5]),close:n(r[6]),last,prev,trades:n(r[8]),vol:n(r[9]),value:n(r[10]),low:n(r[11]),high:n(r[12]),open:n(r[13]),eps:n(r[14]),baseVol:n(r[15]),flow,sector:r[18]||'',max:n(r[19]),min:n(r[20]),state,buyQueue:b?n(b[6]):null,sellQueue:b?n(b[7]):null,orderImbalance:b&&n(b[6])!=null&&n(b[7])!=null?(n(b[6])-n(b[7]))/Math.max(1,n(b[6])+n(b[7])):null,change:prev?((last-prev)/prev*100):null});}return{rows:out,source:'TSETMC legacy MarketWatch',timestamp:Date.now(),marketStatus:state||'unknown',live:true};}
 function modern(){
   const u=`${CDN}/ClosingPrice/GetMarketWatch?market=0&paperTypes[0]=1&paperTypes[1]=2&paperTypes[2]=3&paperTypes[3]=4&paperTypes[4]=5&paperTypes[5]=6&paperTypes[6]=7&paperTypes[7]=8&paperTypes[8]=9&withBestLimits=false&hEven=0&RefID=0`;
   const j=json(u); if(!j)return null;
   const raw=Array.isArray(j.marketwatch)?j.marketwatch:(Array.isArray(j.marketWatch)?j.marketWatch:[]);
   const rows=raw.map(x=>({
     insCode:String(x.insCode??x.InsCode??x.insID??''),
     isin:String(x.instrumentId??x.InstrumentId??x.cIsin??x.insID??''),
     symbol:String(x.lVal18AFC??x.lVal18??x.lva??x.symbol??''),
     company:String(x.lVal30??x.lvc??x.lva??x.companyNamePersian??x.companyName??x.instrumentName??''),
     last:n(x.pDrCotVal??x.lvcPrice??x.lastPrice??x.lvc??x.pl),
     close:n(x.pClosing??x.closingPrice??x.pcl??x.pc),
     prev:n(x.priceYesterday??x.yesterdayPrice??x.py),
     change:n(x.changePercent??x.priceChangePercent??x.pct),
     vol:n(x.qTotTran5J??x.tradeVolume??x.volume),
     value:n(x.qTotCap??x.tradeValue??x.value),
     trades:n(x.zTotTran??x.tradeCount),
     eps:n(x.eps),pe:n(x.pe),
     flow:n(x.flow??x.Flow??x.flowCode),
     state:String(x.stateName??x.state??'')
   })).filter(x=>x.symbol&&x.last!=null&&[1,2,4].includes(x.flow??1));
   if(!rows.length)return null;
   return{rows,source:'TSETMC CDN GetMarketWatch',timestamp:Date.now(),marketStatus:'snapshot',live:true};
 }
 function clientFlow(){
   const j=json(`${CDN}/ClientType/GetClientTypeAll`); if(!j)return new Map();
   const raw=Array.isArray(j.clientTypeAllDto)?j.clientTypeAllDto:(Array.isArray(j.data)?j.data:[]);
   const m=new Map();
   raw.forEach(x=>{
     const id=clean(x.insCode??x.InsCode); if(!id)return;
     m.set(id,{naturalBuy:n(x.buy_I_Volume),legalBuy:n(x.buy_N_Volume),naturalSell:n(x.sell_I_Volume),legalSell:n(x.sell_N_Volume),naturalBuyCount:n(x.buy_I_Count),legalBuyCount:n(x.buy_N_Count),naturalSellCount:n(x.sell_I_Count),legalSellCount:n(x.sell_N_Count)});
   });
   return m;
 }
 function enrich(mk){const cf=clientFlow();return {...mk,rows:mk.rows.map(x=>{const c=cf.get(x.insCode)||{};return {...x,...c}})};}
 function notify(item){const msg=`${item.symbol||'سهم'} · ${item.score}/100 · ${item.votes} موتور هم‌جهت`;window.app?.toast?.('🚨 فرصت قوی بورس: '+msg,'ok');}
 function render(result,live){const st=document.getElementById('irStatus'),top=document.getElementById('irTop'),main=document.getElementById('irMain');if(!result?.rows?.length){const c=MJKOpportunity.cached('stock');if(c?.rows?.length){result=c;live=false}else{st.textContent='🔴 منبع داده در دسترس نیست';top.innerHTML='<div class="empty">هیچ داده واقعی قابل تأیید نیست؛ هیچ سهمی حدسی نمایش داده نمی‌شود.</div>';main.innerHTML='<div class="empty">برای داده زنده و عمق بازار، Data Relay داخل ایران یا منبع حرفه‌ای دارای API باید متصل شود.</div>';return;}}
 const meta=result.meta||{},age=MJKOpportunity.freshness(meta.timestamp),status=meta.marketStatus||'نامشخص';st.textContent=`${live&&!age.stale?'🟢 زنده':'🕒 آخرین داده معتبر'} · ${result.rows.length} سهم · ${status} · سن ${age.ageSec==null?'—':age.ageSec+'ثانیه'}`;
 const z=result.top;main.innerHTML=`<div class="ir-main"><div><small>${live&&!age.stale?'فرصت برتر زنده':'فرصت برتر از آخرین داده معتبر'} · ${z.direction}</small><b>${z.symbol||'—'}</b><span>${z.company||''} · کیفیت داده ${z.dataQuality}%</span></div><strong>${z.score}/100</strong></div><div class="ir-grid"><span>تکنیکال: ${z.engines.technical}</span><span>Order Flow: ${z.engines.flow}</span><span>عمق بازار: ${z.engines.depth}</span><span>نقدشوندگی: ${z.engines.liquidity}</span><span>بنیادی: ${z.engines.fundamental}</span><span>کاتالیست: ${z.engines.catalyst}</span><span>رژیم: ${z.engines.regime}</span></div>`;
 top.innerHTML=result.rows.slice(0,15).map((r,i)=>`<div class="ir-row"><div><b>${i+1}. ${r.symbol||'—'}</b><small>${r.company||''} · ${r.direction} · ${r.votes}/7 موتور · کیفیت ${r.dataQuality}%</small></div><strong>${r.score}</strong><span>${r.ch==null?'—':r.ch.toFixed(2)+'%'}</span></div>`).join('');
 }
 function run(){if(!active||busy)return;busy=true;setTimeout(()=>{try{let p=MJKOpportunity.fetchRelay('stock'),live=!!p;if(!p){const mk=modern()||legacy();if(mk){p={meta:{source:mk.source,timestamp:mk.timestamp,marketStatus:mk.marketStatus,live:mk.live},rows:enrich(mk)};live=true;}}const r=MJKOpportunity.analyze('stock',p,notify);render(r,live);}finally{busy=false}},20)}
 function activate(){active=true;if(!timer){run();timer=setInterval(run,60*1000)}}
 function deactivate(){active=false;if(timer){clearInterval(timer);timer=null}}
 function init(){document.getElementById('irRefresh')?.addEventListener('click',run)}
 return{activate,deactivate,init,run};
})();
