/* MJK Iran Stock Radar: robust live TSETMC reader + transparent multi-engine score. */
window.iranStocks=(()=>{
 let active=false,timer=null,busy=false;
 const WEB='https://webgw.tse.ir', CDN='https://cdn.tsetmc.com/api';
 const nativeGet=url=>{try{const t=window.MJKNative?.fetchJson?.(url);if(!t||String(t).startsWith('MJK_NATIVE_ERROR:'))return null;return JSON.parse(t);}catch(e){return null;}};
 const n=v=>{if(v&&typeof v==='object'){v=v.value??v.Value??v.val??v.amount??v.Amount;}const x=Number(String(v??'').replace(/,/g,''));return Number.isFinite(x)?x:null;};
 const pick=(o,ks)=>{for(const k of ks){if(o?.[k]!=null&&o[k]!=='')return o[k];}return null;};
 function arrays(o){const out=[];const seen=new Set();const walk=x=>{if(!x||typeof x!=='object'||seen.has(x))return;seen.add(x);if(Array.isArray(x)){if(x.length&&typeof x[0]==='object')out.push(x);for(const y of x.slice(0,5))walk(y);}else for(const k of Object.keys(x))walk(x[k]);};walk(o);return out;}
 function market(){
  const urls=[
   `${WEB}/InstrumentProvider/api/v1/MarketWatch/MarketWatchCash/fa`,
   `${WEB}/InstrumentProvider/api/v1/Instrument/InstrumentSliderQuery/fa`,
   `${WEB}/InstrumentProvider/api/v1/ChartSummary/BubbleChart/fa`,
   `${WEB}/InstrumentProvider/api/v1/MarketMap/MarketMapNew/fa?marketIds[0]=20&marketIds[1]=30&MarketTypes[0]=Cash&MarketTypes[1]=ETF&BasedOnVolume=false`,
   `${CDN}/ClosingPrice/GetMarketWatch?market=0&paperTypes[0]=1&paperTypes[1]=2&paperTypes[2]=3&paperTypes[3]=4&paperTypes[4]=5&paperTypes[5]=6&paperTypes[6]=7&paperTypes[7]=8&paperTypes[8]=9&withBestLimits=false&hEven=0&RefID=0`
  ];
  const errors=[];
  for(const u of urls){
    const j=nativeGet(u);
    if(!j){errors.push(u);continue;}
    for(const a of arrays(j)){
      if(a.some(x=>pick(x,['insCode','instrumentId','lVal18','lVal18AFC','instrumentName','instrument_Name','pDrCotVal','lastPrice'])))return {rows:a,source:u,errors};
    }
  }
  return {rows:[],source:'none',errors};
 }
 function norm(x){
  const last=n(pick(x,['lastPrice','lastprice','pDrCotVal','pl','price','LastPrice']));
  const close=n(pick(x,['closingPrice','closingprice','pClosing','pc','ClosePrice']));
  const prev=n(pick(x,['yesterdayPrice','priceYesterday','py','PreviousPrice']));
  let chg=n(pick(x,['pricechangepercent','lastpricechangepercent','pct','pChange','changePercent']));
  if(chg==null&&last!=null&&prev)chg=(last-prev)/prev*100;
  return {insCode:String(pick(x,['insCode','inscode','InsCode'])??''),isin:String(pick(x,['instrumentId','instrumentid','cIsin','InstrumentId'])??''),symbol:String(pick(x,['instrumentName','instrument_Name','lVal18AFC','lVal18','symbol','Symbol'])??''),company:String(pick(x,['companyNamePersian','company_Name_Persian','lVal30','companyName','CompanyName'])??''),last,close,prev,chg,vol:n(pick(x,['tradeVolume','qTotTran5J','qTotTran','volume'])),value:n(pick(x,['tradeValue','qTotCap','value'])),trades:n(pick(x,['tradeCount','zTotTran'])),eps:n(pick(x,['eps','EPS'])),pe:n(pick(x,['pe','pE','sectorPE'])),industry:String(pick(x,['industryname','industryName','industry','industryNamePersian'])??''),state:String(pick(x,['stateName','statename','state','status'])??'')};
 }
 function history(x){
  let j=null,a=[];
  if(x.insCode)j=nativeGet(`${CDN}/ClosingPrice/GetClosingPriceDailyList/${encodeURIComponent(x.insCode)}/300`);
  if(j) a=arrays(j)[0]||[];
  if(!a.length&&x.isin)j=nativeGet(`${WEB}/InstrumentProvider/api/v1/History/Archive/fa?InstrumentId=${encodeURIComponent(x.isin)}`),a=arrays(j)[0]||[];
  return a.map(r=>({date:pick(r,['devenrlc','dEven','date','t','Date'])??0,close:n(pick(r,['closingprice','closingPrice','pc','c','Close'])),high:n(pick(r,['highvalue','highPrice','ph','High'])),low:n(pick(r,['lowvalue','lowPrice','pl','Low'])),vol:n(pick(r,['tradevolume','volume','v','Volume']))})).filter(r=>r.close!=null).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
 }
 function ema(v,p){if(v.length<p)return null;let e=v.slice(0,p).reduce((a,b)=>a+b,0)/p,k=2/(p+1);for(let i=p;i<v.length;i++)e=(v[i]-e)*k+e;return e;}
 function rsi(v,p=14){if(v.length<=p)return null;let g=0,l=0;for(let i=1;i<=p;i++){const d=v[i]-v[i-1];g+=Math.max(d,0);l+=Math.max(-d,0);}g/=p;l/=p;for(let i=p+1;i<v.length;i++){const d=v[i]-v[i-1];g=(g*(p-1)+Math.max(d,0))/p;l=(l*(p-1)+Math.max(-d,0))/p;}return l===0?100:100-100/(1+g/l);}
 function technical(h){const c=h.map(x=>x.close);if(c.length<60)return{score:0,ok:false};const e20=ema(c,20),e50=ema(c,50),e200=ema(c,200),r=rsi(c),last=c.at(-1);let s=0;if(e20&&last>e20)s+=18;if(e50&&last>e50)s+=15;if(e200&&last>e200)s+=18;if(e20&&e50&&e20>e50)s+=12;if(e50&&e200&&e50>e200)s+=12;if(r!=null&&r>=52&&r<=72)s+=10;const a=c.slice(-20);const sl=(a.at(-1)-a[0])/Math.max(1,a[0])*100;if(sl>2)s+=10;else if(sl>0)s+=5;return{score:Math.min(100,s),ok:true};}
 function render(rows,source){const top=document.getElementById('irTop'),main=document.getElementById('irMain'),st=document.getElementById('irStatus');if(!rows.length){if(top)top.innerHTML='<div class="empty">اتصال به منبع بازار برقرار نشد یا ساختار داده قابل‌خواندن نبود؛ هیچ سهمی حدسی نمایش داده نمی‌شود.</div>';if(main)main.innerHTML='<div class="empty">داده زنده بورس ایران در این لحظه قابل‌استخراج نیست.</div>';if(st)st.textContent='بدون داده معتبر · منبع: '+source;return;}if(top)top.innerHTML=rows.map((r,i)=>`<div class="ir-row"><div><b>${i+1}. ${r.symbol||'—'}</b><small>${r.company||r.industry||'—'}</small></div><strong>${r.score}</strong><span>اجماع ${r.consensus}/5</span></div>`).join('');const z=rows[0];if(main)main.innerHTML=`<div class="ir-main"><div><small>برترین گزینه داده‌محور</small><b>${z.symbol}</b><span>${z.company||''}</span></div><strong>${z.score}/100</strong></div><div class="ir-grid"><span>تکنیکال: ${z.tech}</span><span>تابلو/جریان: ${z.flow}</span><span>بنیادی قابل‌استخراج: ${z.fund}</span><span>صنعت/اقتصاد: ${z.macro}</span><span>ریسک: ${z.risk}</span><span>اجماع: ${z.consensus}/5</span></div>`;if(st)st.textContent=`${rows.length} سهم · ${source} · ${new Date().toLocaleTimeString('fa-IR')}`;}
 function run(){if(!active||busy)return;busy=true;setTimeout(()=>{try{const mk=market();const raw=mk.rows.map(norm).filter(x=>x.symbol&&x.last!=null);const liquid=raw.filter(x=>(x.value||x.vol||0)>0).sort((a,b)=>(b.value||0)-(a.value||0)).slice(0,30),out=[];for(const x of liquid.slice(0,15)){const t=technical(history(x));let flow=(x.chg||0)>1?10:((x.chg||0)>0?5:0);if(x.vol)flow+=5;let fund=(x.eps!=null&&x.eps>0?10:0)+(x.pe!=null&&x.pe>0&&x.pe<15?8:(x.pe!=null&&x.pe<25?4:0));let macro=x.industry?5:0;let risk=(x.state.includes('مجاز')||!x.state)?2:0;const score=Math.min(100,t.score+flow+fund+macro+risk),agree=[t.score>=60,flow>=10,fund>=10,macro>=5,risk>=2].filter(Boolean).length;out.push({...x,score,tech:t.score,flow,fund,macro,risk,consensus:agree});}render(out.sort((a,b)=>b.score-a.score).slice(0,10),raw.length?('TSETMC · '+(mk.source.includes('webgw')?'gateway رسمی':'CDN')):'TSETMC');}finally{busy=false;}},20);}
 function activate(){active=true;if(!timer){run();timer=setInterval(run,15*60*1000);}}function deactivate(){active=false;if(timer){clearInterval(timer);timer=null;}}function init(){document.getElementById('irRefresh')?.addEventListener('click',run);}return{activate,deactivate,init,run};
})();
