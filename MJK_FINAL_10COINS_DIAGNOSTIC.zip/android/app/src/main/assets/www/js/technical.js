/* MJK Technical Analysis — visual analysis only; does not alter live strategy rules. */
window.technical = (() => {
  const state = {symbol:localStorage.getItem('mjk_ta_symbol')||'BTCUSDT', interval:localStorage.getItem('mjk_ta_interval')||'15m', candles:[], active:localStorage.getItem('mjk_ta_osc')||'RSI', timer:null, loading:false, lastLoad:0, lastRecommendationAt:0};
  const $ = id => document.getElementById(id);
  const fmt = v => Number.isFinite(v) ? (Math.abs(v)>=1000 ? v.toLocaleString('en-US',{maximumFractionDigits:2}) : v.toLocaleString('en-US',{maximumFractionDigits:6})) : '—';
  const intervalMs = { '1min':60000,'5min':300000,'15min':900000,'30min':1800000,'1hour':3600000,'4hour':14400000,'1day':86400000 };

  function closes(c){return c.map(x=>+x[4]);}
  function sma(v,p){const o=new Array(v.length).fill(null);let s=0;for(let i=0;i<v.length;i++){s+=v[i];if(i>=p)s-=v[i-p];if(i>=p-1)o[i]=s/p;}return o;}
  function ema(v,p){const o=new Array(v.length).fill(null);if(v.length<p)return o;let s=0;for(let i=0;i<p;i++)s+=v[i];let prev=s/p;o[p-1]=prev;const k=2/(p+1);for(let i=p;i<v.length;i++){prev=(v[i]-prev)*k+prev;o[i]=prev;}return o;}
  function atr(c,p=14){const tr=new Array(c.length).fill(null),o=new Array(c.length).fill(null);for(let i=0;i<c.length;i++){const h=+c[i][2],l=+c[i][3],pc=i?+c[i-1][4]:+c[i][4];tr[i]=i?Math.max(h-l,Math.abs(h-pc),Math.abs(l-pc)):h-l;}if(c.length<p)return o;let s=0;for(let i=0;i<p;i++)s+=tr[i];let a=s/p;o[p-1]=a;for(let i=p;i<c.length;i++){a=((a*(p-1))+tr[i])/p;o[i]=a;}return o;}
  function rsi(v,p=14){const o=new Array(v.length).fill(null);if(v.length<=p)return o;let g=0,l=0;for(let i=1;i<=p;i++){const d=v[i]-v[i-1];g+=Math.max(d,0);l+=Math.max(-d,0);}g/=p;l/=p;o[p]=l===0?100:100-(100/(1+g/l));for(let i=p+1;i<v.length;i++){const d=v[i]-v[i-1];g=(g*(p-1)+Math.max(d,0))/p;l=(l*(p-1)+Math.max(-d,0))/p;o[i]=l===0?100:100-(100/(1+g/l));}return o;}
  function macd(v){const a=ema(v,12),b=ema(v,26),m=v.map((_,i)=>a[i]!=null&&b[i]!=null?a[i]-b[i]:null);const clean=m.map(x=>x==null?0:x),s=ema(clean,9),h=m.map((x,i)=>x!=null&&s[i]!=null?x-s[i]:null);return {m,s,h};}
  function stoch(c,p=14,kp=3,dp=3){const raw=new Array(c.length).fill(null);for(let i=p-1;i<c.length;i++){let hi=-Infinity,lo=Infinity;for(let j=i-p+1;j<=i;j++){hi=Math.max(hi,+c[j][2]);lo=Math.min(lo,+c[j][3]);}raw[i]=hi===lo?50:((+c[i][4]-lo)/(hi-lo))*100;}const k=sma(raw.map(x=>x==null?0:x),kp).map((x,i)=>i>=p+kp-2?x:null);const d=sma(k.map(x=>x==null?0:x),dp).map((x,i)=>i>=p+kp+dp-3?x:null);return {k,d};}
  function cci(c,p=20){const tp=c.map(x=>((+x[2]+ +x[3]+ +x[4])/3));const ma=sma(tp,p),o=new Array(c.length).fill(null);for(let i=p-1;i<c.length;i++){let md=0;for(let j=i-p+1;j<=i;j++)md+=Math.abs(tp[j]-ma[i]);md/=p;o[i]=md===0?0:(tp[i]-ma[i])/(0.015*md);}return o;}
  function adx(c,p=14){const n=c.length,tr=new Array(n).fill(0),plus=new Array(n).fill(0),minus=new Array(n).fill(0);for(let i=1;i<n;i++){const h=+c[i][2],l=+c[i][3],ph=+c[i-1][2],pl=+c[i-1][3],pc=+c[i-1][4];tr[i]=Math.max(h-l,Math.abs(h-pc),Math.abs(l-pc));const up=h-ph,down=pl-l;plus[i]=up>down&&up>0?up:0;minus[i]=down>up&&down>0?down:0;}const out=new Array(n).fill(null);let atrv=0,sp=0,sm=0;for(let i=1;i<=p;i++){atrv+=tr[i];sp+=plus[i];sm+=minus[i];}for(let i=p;i<n;i++){if(i>p){atrv=atrv-atrv/p+tr[i];sp=sp-sp/p+plus[i];sm=sm-sm/p+minus[i];}const pdi=atrv?100*sp/atrv:0,mdi=atrv?100*sm/atrv:0;const dx=(pdi+mdi)?100*Math.abs(pdi-mdi)/(pdi+mdi):0;out[i]=dx;}const ad=sma(out.map(x=>x==null?0:x),p);return ad;}
  function bb(v,p=20,m=2){const mid=sma(v,p),up=new Array(v.length).fill(null),lo=new Array(v.length).fill(null);for(let i=p-1;i<v.length;i++){let s=0;for(let j=i-p+1;j<=i;j++)s+=(v[j]-mid[i])**2;const sd=Math.sqrt(s/p);up[i]=mid[i]+m*sd;lo[i]=mid[i]-m*sd;}return {mid,up,lo};}
  function vwap(c){let pv=0,v=0,o=[];for(const x of c){const tp=(+x[2]+ +x[3]+ +x[4])/3;const vol=+x[5]||0;pv+=tp*vol;v+=vol;o.push(v?pv/v:null);}return o;}

  function obv(c){const o=new Array(c.length).fill(null);let v=0;o[0]=0;for(let i=1;i<c.length;i++){if(+c[i][4]>+c[i-1][4])v+=+c[i][5]||0;else if(+c[i][4]<+c[i-1][4])v-=+c[i][5]||0;o[i]=v;}return o;}
  function mfi(c,p=14){const tp=c.map(x=>(+x[2]+ +x[3]+ +x[4])/3),o=new Array(c.length).fill(null);for(let i=p;i<c.length;i++){let pos=0,neg=0;for(let j=i-p+1;j<=i;j++){const flow=tp[j]*(+c[j][5]||0);if(tp[j]>tp[j-1])pos+=flow;else if(tp[j]<tp[j-1])neg+=flow;}o[i]=neg===0?100:100-(100/(1+pos/neg));}return o;}
  function williams(c,p=14){const o=new Array(c.length).fill(null);for(let i=p-1;i<c.length;i++){let hi=-Infinity,lo=Infinity;for(let j=i-p+1;j<=i;j++){hi=Math.max(hi,+c[j][2]);lo=Math.min(lo,+c[j][3]);}o[i]=hi===lo?-50:((hi-+c[i][4])/(hi-lo))*-100;}return o;}
  function roc(v,p=12){const o=new Array(v.length).fill(null);for(let i=p;i<v.length;i++)o[i]=v[i-p]===0?null:((v[i]-v[i-p])/v[i-p])*100;return o;}
  function stochRsi(v,p=14,kp=3,dp=3){const r=rsi(v,p),raw=new Array(v.length).fill(null);for(let i=p;i<v.length;i++){let lo=Infinity,hi=-Infinity;for(let j=i-p+1;j<=i;j++){if(Number.isFinite(r[j])){lo=Math.min(lo,r[j]);hi=Math.max(hi,r[j]);}}raw[i]=hi===lo?50:((r[i]-lo)/(hi-lo))*100;}return {k:sma(raw.map(x=>x==null?0:x),kp).map((x,i)=>i>=p+kp-2?x:null),d:sma(raw.map(x=>x==null?0:x),dp).map((x,i)=>i>=p+dp-2?x:null)};}
  function supertrend(c,p=10,mult=3){const a=atr(c,p),st=new Array(c.length).fill(null),dir=new Array(c.length).fill(null),up=new Array(c.length).fill(null),dn=new Array(c.length).fill(null);for(let i=0;i<c.length;i++){if(a[i]==null)continue;const mid=(+c[i][2]+ +c[i][3])/2;up[i]=mid+mult*a[i];dn[i]=mid-mult*a[i];if(i===p-1){st[i]=up[i];dir[i]=-1;continue;}const pu=up[i-1]??up[i],pd=dn[i-1]??dn[i];if(+c[i-1][4]<=pu)up[i]=Math.min(up[i],pu);if(+c[i-1][4]>=pd)dn[i]=Math.max(dn[i],pd);const prev=dir[i-1]??-1;if(prev<0){if(+c[i][4]>up[i]){dir[i]=1;st[i]=dn[i];}else{dir[i]=-1;st[i]=up[i];}}else{if(+c[i][4]<dn[i]){dir[i]=-1;st[i]=up[i];}else{dir[i]=1;st[i]=dn[i];}}}return {st,dir};}
  function canvas(id){const c=$(id);if(!c)return null;const dpr=Math.max(1,window.devicePixelRatio||1),w=Math.max(10,c.clientWidth||360),h=Math.max(10,c.clientHeight||240);c.width=Math.round(w*dpr);c.height=Math.round(h*dpr);const x=c.getContext('2d');x.setTransform(dpr,0,0,dpr,0,0);x.clearRect(0,0,w,h);return {c,x,w,h};}
  function range(arr){let a=Infinity,b=-Infinity;arr.forEach(v=>{if(Number.isFinite(v)){a=Math.min(a,v);b=Math.max(b,v);}});if(!Number.isFinite(a)||a===b){a=0;b=1;}const pad=(b-a)*.08||1;return [a-pad,b+pad];}
  function path(ctx,vals,lo,hi,top,bottom,left,right,color,width=1.5){ctx.beginPath();let started=false;const n=vals.length;vals.forEach((v,i)=>{if(!Number.isFinite(v))return;const x=left+(i/(n-1))*(right-left),y=bottom-((v-lo)/(hi-lo))*(bottom-top);if(!started){ctx.moveTo(x,y);started=true;}else ctx.lineTo(x,y);});if(started){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();}}
  function grid(ctx,w,h,left,right,top,bottom){ctx.strokeStyle='rgba(255,255,255,.07)';ctx.lineWidth=1;for(let i=0;i<5;i++){const y=top+i*(bottom-top)/4;ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(right,y);ctx.stroke();}for(let i=0;i<6;i++){const x=left+i*(right-left)/5;ctx.beginPath();ctx.moveTo(x,top);ctx.lineTo(x,bottom);ctx.stroke();}}
  function drawPrice(c,ind){
    const q=canvas('taChart'); if(!q)return;
    const {x:ctx,w,h}=q,left=8,right=w-58,top=8,bottom=h-30,n=c.length,visible=Math.min(120,n),start=n-visible,cs=c.slice(start);
    const highs=cs.map(z=>+z[2]), lows=cs.map(z=>+z[3]);
    const overlays=[ind.e20.slice(start),ind.e50.slice(start),ind.e200.slice(start),ind.vwap.slice(start),ind.bb.mid.slice(start),ind.bb.up.slice(start),ind.bb.lo.slice(start),ind.supertrend.slice(start)];
    let hi=Math.max(...highs),lo=Math.min(...lows);
    overlays.forEach(a=>a.forEach(v=>{if(Number.isFinite(v)){hi=Math.max(hi,v);lo=Math.min(lo,v);}}));
    const pad=(hi-lo)*.06||1; hi+=pad; lo-=pad;
    const xx=i=>left+(visible<=1?0:i/(visible-1))*(right-left);
    const yy=v=>bottom-((v-lo)/(hi-lo))*(bottom-top);
    grid(ctx,w,h,left,right,top,bottom);
    const candleW=Math.max(2,(right-left)/visible*.62);
    for(let i=0;i<visible;i++){
      const z=cs[i],x=xx(i),o=+z[1],cl=+z[4],hh=+z[2],ll=+z[3],up=cl>=o;
      ctx.strokeStyle=up?'#35d39a':'#ff5c72';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,yy(ll));ctx.lineTo(x,yy(hh));ctx.stroke();
      ctx.fillStyle=up?'#35d39a':'#ff5c72';const y1=yy(Math.max(o,cl)),y2=yy(Math.min(o,cl));
      ctx.fillRect(x-candleW/2,y1,candleW,Math.max(1,y2-y1));
    }
    const line=(vals,color,width=1.5)=>path(ctx,vals,lo,hi,top,bottom,left,right,color,width);
    line(ind.e20.slice(start),'#f5b83d',1.8);
    line(ind.e50.slice(start),'#5aa8ff',1.5);
    line(ind.e200.slice(start),'#c084fc',1.6);
    line(ind.vwap.slice(start),'#8d9bad',1.2);
    line(ind.bb.mid.slice(start),'#7dd3fc',1);
    line(ind.bb.up.slice(start),'rgba(125,211,252,.55)',1);
    line(ind.bb.lo.slice(start),'rgba(125,211,252,.55)',1);
    line(ind.supertrend.slice(start),'#ff9f43',2.2);

    // Confirmed swing highs/lows (3 candles on each side).
    const swings=ind.swings||[];
    swings.forEach(s=>{
      if(s.index<start||s.index>=n)return;
      const i=s.index-start,x=xx(i),y=yy(s.price);
      ctx.fillStyle=s.type==='high'?'#ff7b91':'#55e6b1';
      ctx.beginPath();ctx.arc(x,y,3.2,0,Math.PI*2);ctx.fill();
      ctx.font='9px Arial';ctx.textAlign='center';
      ctx.fillText(s.type==='high'?'SH':'SL',x,s.type==='high'?y-7:y+13);
    });

    // Pullback markers: closed-candle rejection back through EMA20/EMA50 in the prevailing trend.
    const pulls=ind.pullbacks||[];
    pulls.forEach(p=>{
      if(p.index<start||p.index>=n)return;
      const i=p.index-start,x=xx(i),y=yy(p.price);
      ctx.fillStyle=p.direction==='bullish'?'#35d39a':'#ff5c72';
      ctx.beginPath();
      if(p.direction==='bullish'){ctx.moveTo(x,y-10);ctx.lineTo(x-5,y-2);ctx.lineTo(x+5,y-2);}
      else{ctx.moveTo(x,y+10);ctx.lineTo(x-5,y+2);ctx.lineTo(x+5,y+2);}
      ctx.closePath();ctx.fill();
      ctx.font='8px Arial';ctx.textAlign='center';ctx.fillText('PB',x,p.direction==='bullish'?y-13:y+19);
    });

    ctx.fillStyle='#8d9bad';ctx.font='10px Arial';ctx.textAlign='left';
    [hi,(hi+lo)/2,lo].forEach(v=>ctx.fillText(fmt(v),right+4,yy(v)+3));
    const first=cs[0]?.[0],last=cs[cs.length-1]?.[0];
    if(first&&last){
      ctx.fillText(new Date(first).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'}),left,bottom+18);
      ctx.fillText(new Date(last).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'}),right-35,bottom+18);
    }
    ctx.textAlign='start';
  }
  function drawOsc(name,ind){const q=canvas('taOsc');if(!q)return;const {x,w,h}=q,left=8,right=w-44,top=8,bottom=h-22;grid(x,w,h,left,right,top,bottom);let series=[],min=Infinity,max=-Infinity;const push=(arr,label)=>{series.push({arr,label});arr.forEach(v=>{if(Number.isFinite(v)){min=Math.min(min,v);max=Math.max(max,v);}})};if(name==='RSI'){push(ind.rsi,'RSI');min=0;max=100;[30,70].forEach(v=>{const y=bottom-(v-min)/(max-min)*(bottom-top);x.strokeStyle='rgba(245,184,61,.35)';x.beginPath();x.moveTo(left,y);x.lineTo(right,y);x.stroke();});}else if(name==='MACD'){push(ind.macd.m,'MACD');push(ind.macd.s,'Signal');min=Math.min(min,0);max=Math.max(max,0);const zero=bottom-(0-min)/(max-min)*(bottom-top);x.strokeStyle='rgba(255,255,255,.16)';x.beginPath();x.moveTo(left,zero);x.lineTo(right,zero);x.stroke();}else if(name==='Stochastic'){push(ind.stoch.k,'%K');push(ind.stoch.d,'%D');min=0;max=100;[20,80].forEach(v=>{const y=bottom-(v-min)/(max-min)*(bottom-top);x.strokeStyle='rgba(245,184,61,.35)';x.beginPath();x.moveTo(left,y);x.lineTo(right,y);x.stroke();});}else if(name==='CCI'){push(ind.cci,'CCI');min=Math.min(min,-200);max=Math.max(max,200);const z=bottom-(0-min)/(max-min)*(bottom-top);x.strokeStyle='rgba(255,255,255,.16)';x.beginPath();x.moveTo(left,z);x.lineTo(right,z);x.stroke();}else if(name==='ADX'){push(ind.adx,'ADX');min=0;max=Math.max(50,max);const z=bottom-(25-min)/(max-min)*(bottom-top);x.strokeStyle='rgba(245,184,61,.35)';x.beginPath();x.moveTo(left,z);x.lineTo(right,z);x.stroke();}else if(name==='Stoch RSI'){push(ind.stochRsi.k,'%K');push(ind.stochRsi.d,'%D');min=0;max=100;}else if(name==='MFI'){push(ind.mfi,'MFI');min=0;max=100;}else if(name==='Williams %R'){push(ind.williams,'Williams %R');min=-100;max=0;}else if(name==='ROC'){push(ind.roc,'ROC');min=Math.min(min,-10);max=Math.max(max,10);}else if(name==='OBV'){push(ind.obv,'OBV');}else {push(ind.atr,'ATR');min=0;}
    const colors=['#f5b83d','#5aa8ff'];series.forEach((s,i)=>path(x,s.arr.slice(-100),min,max,top,bottom,left,right,colors[i]||'#c084fc',1.8));x.fillStyle='#8d9bad';x.font='10px Arial';x.fillText(`${name} · ${fmt(series[0]?.arr.at(-1))}`,left, h-6);
  }
  function confirmedSwings(c,leftBars=3,rightBars=3){
    const out=[];
    for(let i=leftBars;i<c.length-rightBars;i++){
      const h=+c[i][2],l=+c[i][3]; let hi=true,lo=true;
      for(let j=i-leftBars;j<=i+rightBars;j++){if(j===i)continue; if(+c[j][2]>=h)hi=false; if(+c[j][3]<=l)lo=false;}
      if(hi)out.push({index:i,type:'high',price:h});
      if(lo)out.push({index:i,type:'low',price:l});
    }
    return out;
  }
  function detectPullbacks(c,e20,e50){
    const out=[];
    for(let i=1;i<c.length;i++){
      const o=+c[i][1],h=+c[i][2],l=+c[i][3],cl=+c[i][4],pe20=e20[i],pe50=e50[i];
      if(!Number.isFinite(pe20)||!Number.isFinite(pe50))continue;
      const bull=cl>pe20 && pe20>pe50 && l<=pe20 && cl>o;
      const bear=cl<pe20 && pe20<pe50 && h>=pe20 && cl<o;
      if(bull)out.push({index:i,direction:'bullish',price:l});
      else if(bear)out.push({index:i,direction:'bearish',price:h});
    }
    return out;
  }
  function calc(c){const v=closes(c),e20=ema(v,20),e50=ema(v,50),e200=ema(v,200),a14=atr(c,14),b=bb(v),r=rsi(v),m=macd(v),s=stoch(c),cc=cci(c),ad=adx(c),vw=vwap(c);return {e20,e50,e200,a14,atr:a14,rsi:r,macd:m,stoch:s,cci:cc,adx:ad,vwap:vw,bb:b,obv:obv(c),mfi:mfi(c),williams:williams(c),roc:roc(v),stochRsi:stochRsi(v),supertrend:supertrend(c).st,swings:confirmedSwings(c,3,3),pullbacks:detectPullbacks(c,e20,e50)};}
  function latest(ind){const pick=k=>{const a=ind[k];return Array.isArray(a)?a.at(-1):null};const m=ind.macd;return {price:state.candles.at(-1)?.[4],ema20:pick('e20'),ema50:pick('e50'),ema200:pick('e200'),rsi:pick('rsi'),macd:m.m.at(-1),signal:m.s.at(-1),stoch:ind.stoch.k.at(-1),cci:pick('cci'),adx:pick('adx'),atr:pick('atr'),vwap:pick('vwap')};}
  function render(c){const ind=calc(c);drawPrice(c,ind);drawOsc(state.active,ind);const z=latest(ind);const swings=ind.swings||[],pulls=ind.pullbacks||[];const lastSwing=swings.at(-1);const lastPull=pulls.at(-1);$('taPrice').textContent=fmt(z.price);$('taSummary').innerHTML=`<span>EMA20 <b>${fmt(z.ema20)}</b></span><span>EMA50 <b>${fmt(z.ema50)}</b></span><span>EMA200 <b>${fmt(z.ema200)}</b></span><span>RSI <b>${fmt(z.rsi)}</b></span><span>MACD <b>${fmt(z.macd)}</b></span><span>ADX <b>${fmt(z.adx)}</b></span><span>پولبک آخر <b>${lastPull?(lastPull.direction==='bullish'?'صعودی':'نزولی'):'—'}</b></span><span>سقف/کف تأییدشده <b>${lastSwing?(lastSwing.type==='high'?'سقف':'کف'):'—'}</b></span>`;$('taStatus').textContent=`${c.length} کندل · ${swings.length} سقف/کف تأییدشده · ${pulls.length} پولبک · آخرین داده ${new Date(c.at(-1)[0]).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'})}`;}
  async function load(){if(state.loading)return;state.loading=true;try{$('taStatus').textContent='در حال دریافت تاریخچه واقعی بازار…';let c=await MJK.fetchKlines({symbol:state.symbol,interval:state.interval,limit:320});let closed=c.filter(x=>x[6]<Date.now());if(closed.length<210){const ms=intervalMs[state.interval]||300000;const end=Date.now()-ms;const start=end-(340*ms);c=await MJK.fetchKlines({symbol:state.symbol,interval:state.interval,startTime:start,endTime:end,limit:320});closed=c.filter(x=>x[6]<Date.now());}state.candles=closed;if(state.candles.length<200)throw new Error(`داده بسته‌شده کافی نیست (${state.candles.length}/200)`);render(state.candles);if(Date.now()-state.lastRecommendationAt>120000){state.lastRecommendationAt=Date.now();await updateRecommendation();}}catch(e){$('taStatus').textContent='خطا در دریافت داده: '+(e.message||e);set('taRecommendation','<div class="empty">تحلیل یک‌ماهه فعلاً قابل محاسبه نیست؛ داده تاریخی واقعی کافی دریافت نشد.</div>');}finally{state.loading=false;}}
  function set(id,html){const e=$(id);if(e)e.innerHTML=html;}
  function scoreTechnical(c){
    if(!c||c.length<210)return null;
    const ind=calc(c),i=c.length-1,p=+c[i][4],e20=ind.e20[i],e50=ind.e50[i],e200=ind.e200[i],r=ind.rsi[i],adxv=ind.adx[i],mac=ind.macd.m[i],sig=ind.macd.s[i],atrv=ind.a14[i];
    if(![p,e20,e50,e200,r,adxv,mac,sig,atrv].every(Number.isFinite))return null;
    let score=0;const reasons=[];
    if(p>e200){score+=20;reasons.push('بالای EMA200')}else reasons.push('زیر EMA200');
    if(e20>e50){score+=15;reasons.push('EMA20 بالای EMA50')}else reasons.push('EMA20 زیر EMA50');
    if(e50>e200){score+=15;reasons.push('روند میان‌مدت صعودی')}else reasons.push('روند میان‌مدت ضعیف');
    if(r>=50&&r<=68){score+=12;reasons.push('مومنتوم سالم')}else if(r>68){score+=6;reasons.push('مومنتوم قوی ولی داغ')}else score+=2;
    if(mac>sig){score+=12;reasons.push('MACD مثبت')}else score+=2;
    if(adxv>=20){score+=10;reasons.push('روند دارای قدرت')}else score+=4;
    const bb=ind.bb, mid=bb.mid[i],up=bb.up[i],lo=bb.lo[i];
    if(Number.isFinite(mid)&&p>mid)score+=8;else score+=2;
    const last20=c.slice(Math.max(0,c.length-20)).map(x=>+x[4]);const slope=(last20.at(-1)-last20[0])/(last20[0]||1)*100;if(slope>0)score+=8;
    let bias=score>=75?'صعودی':score>=58?'خنثی متمایل به صعود':'ضعیف/پرریسک';
    const pull=ind.pullbacks?.at(-1);if(pull?.direction==='bullish')score=Math.min(100,score+3);
    return {score:Math.round(score),bias,price:p,ema20:e20,ema50:e50,ema200:e200,rsi:r,adx:adxv,atr:atrv,reasons,slope};
  }
  async function updateRecommendation(){
    const el=$('taRecommendation');if(!el)return;el.innerHTML='<div class="empty">در حال مقایسه ۱۰ ارز برتر با داده روزانه بسته‌شده…</div>';
    const top=await MJK.topSymbols();const rows=[];
    for(const s of top){try{const c=(await MJK.fetchKlines({symbol:s,interval:'1day',limit:260})).filter(x=>x[6]<Date.now());const a=scoreTechnical(c);if(a)rows.push({symbol:s,...a});}catch(_){}}
    rows.sort((a,b)=>b.score-a.score);if(!rows.length){el.innerHTML='<div class="empty">برای هیچ‌یک از ۱۰ ارز داده روزانه کافی و معتبر دریافت نشد؛ پیشنهاد ساخته نمی‌شود.</div>';return;}
    const best=rows[0];const confidence=best.score>=80?'بالا':best.score>=68?'متوسط':'پایین';
    el.innerHTML=`<div class="rec-head"><b>پیشنهاد تحلیل تکنیکال · افق ۱ ماهه</b><span class="badge ${best.score>=68?'win':'loss'}">${confidence}</span></div><div class="rec-main"><strong>${best.symbol.replace('USDT','/USDT')}</strong><b>${best.score}/100</b><span>${best.bias}</span></div><div class="rec-grid"><span>قیمت ${fmt(best.price)}</span><span>EMA20 ${fmt(best.ema20)}</span><span>EMA50 ${fmt(best.ema50)}</span><span>EMA200 ${fmt(best.ema200)}</span><span>RSI ${fmt(best.rsi)}</span><span>ADX ${fmt(best.adx)}</span></div><p class="muted">مبنای انتخاب: روند چندلایه، مومنتوم، قدرت روند و وضعیت قیمت نسبت به میانگین‌ها. این «پیش‌بینی قطعی» نیست؛ سناریوی یک‌ماهه بر اساس داده بسته‌شده فعلی است. حفظ EMA20/EMA50 شرط ادامه سناریوی صعودی است.</p><div class="rec-rank">${rows.slice(0,5).map((x,i)=>`<span>${i+1}. ${x.symbol.replace('USDT','')} <b>${x.score}</b></span>`).join('')}</div>`;
  }
  function bind(){const sym=$('taSymbol'),tf=$('taInterval'),osc=$('taOscillator');sym.onchange=()=>{state.symbol=sym.value;localStorage.setItem('mjk_ta_symbol',state.symbol);load();};tf.onchange=()=>{state.interval=tf.value;localStorage.setItem('mjk_ta_interval',state.interval);load();};osc.onchange=()=>{state.active=osc.value;localStorage.setItem('mjk_ta_osc',state.active);if(state.candles.length)render(state.candles);};$('taRefresh').onclick=load;window.addEventListener('resize',()=>{if(state.candles.length)render(state.candles);});}
  async function activate(){const sym=$('taSymbol'),tf=$('taInterval'),osc=$('taOscillator');if(sym.options.length===0){const top=await MJK.topSymbols();if(sym.options.length===0)sym.innerHTML=top.map(s=>`<option value="${s}">${s.replace('USDT','/USDT')}</option>`).join('');}if([...sym.options].some(o=>o.value===state.symbol))sym.value=state.symbol;else if(sym.value)state.symbol=sym.value;if([...tf.options].some(o=>o.value===state.interval))tf.value=state.interval;if([...osc.options].some(o=>o.value===state.active))osc.value=state.active;if(!state.timer)state.timer=setInterval(()=>{if(!document.hidden&&window.app?.tab==='technical')load();},15000);if(!state.loading&&window.app?.tab==='technical'&&Date.now()-(state.lastLoad||0)>5000){state.lastLoad=Date.now();load();}}
  window.addEventListener('DOMContentLoaded',bind);return {activate,load};
})();
