/* MJK Opportunity Engine v13 Signal Pro — multi-engine predictive ensemble, market/news/order-flow aware, no fabricated probability. */
window.MJKOpportunity=(()=>{
 const CACHE='mjk_opportunity_cache_v10', ALERT='mjk_opportunity_alerts_v10', HISTORY_CACHE='mjk_history_v10_';
 const DEFAULT_RELAY='https://raw.githubusercontent.com/mohsen8463teh-ui/MJK/main/radar-data';
 const CDN='https://cdn.tsetmc.com/api';
 const TARGET=4.0, STOP=2.0, MIN_SAMPLES=50, K=50, MIN_MODEL_SAMPLES=120;
 const num=v=>{if(v&&typeof v==='object')v=v.value??v.Value??v.val??v.amount??v.Amount;const x=Number(String(v??'').replace(/,/g,''));return Number.isFinite(x)?x:null};
 const clamp=(x,a=0,b=100)=>Math.max(a,Math.min(b,x));
 const pct=(a,b)=>a==null||b==null||!b?null:(a-b)/Math.abs(b)*100;
 const ageMs=t=>{const x=Number(t);return Number.isFinite(x)?Math.max(0,Date.now()-(x<1e12?x*1000:x)):Infinity};
 function freshness(ts){const age=ageMs(ts);return {ageMs:age,ageSec:Number.isFinite(age)?Math.round(age/1000):null,live:age<=90000,fresh:age<=6*60*1000,stale:age>15*60*1000};}
 function save(key,data){try{localStorage.setItem(key,JSON.stringify(data));}catch(_){} }
 function load(key){try{return JSON.parse(localStorage.getItem(key)||'null')}catch(_){return null}}
 function getRelay(){return String(localStorage.getItem('mjk_relay_url')||DEFAULT_RELAY).trim().replace(/\/$/,'');}
 function nativeJson(url){try{const t=window.MJKNative?.fetchJson?.(url);if(!t||String(t).startsWith('MJK_NATIVE_ERROR:'))return null;return JSON.parse(t)}catch(_){return null}}
 function normalizePayload(j,market){if(!j)return null;const rows=j.items||j.rows||j.data?.items||j.data?.rows||j.data||[];if(!Array.isArray(rows)||!rows.length)return null;return {meta:{source:j.source||j.provider||market||'unknown',timestamp:j.timestamp||j.ts||j.updatedAt||Date.now(),capturedAt:j.capturedAt||null,marketStatus:j.marketStatus||j.status||'snapshot',live:j.live===true,dataAgeSec:num(j.dataAgeSec),upstreamOk:j.upstreamOk!==false,marketOverview:j.marketOverview||null,news:j.news||[],macro:j.macro||{}},rows};}
 function fetchRelay(kind){const base=getRelay(),path=kind==='stock'?'/mjk/v1/radar/stocks':'/mjk/v1/radar/commodities',isStatic=base.includes('raw.githubusercontent.com')||base.includes('githubusercontent.com');const url=isStatic?`${base}${kind==='stock'?'/stocks.json':'/commodities.json'}?t=${Math.floor(Date.now()/60000)}`:base+path;const payload=nativeJson(url);if(!payload)return null;if(isStatic)payload.live=false;return normalizePayload(payload,isStatic?'MJK TSETMC snapshot':'MJK Relay');}
 function quality(x){const base=['last','prev','vol','value','trades'];const have=base.filter(k=>num(x[k])!=null).length;const extras=['avgVol','naturalBuy','naturalSell','legalBuy','legalSell','orderImbalance','bidDepth','askDepth','eps','pe'].filter(k=>num(x[k])!=null).length;return Math.round(clamp(have*12+extras*5));}
 function marketContext(rows){const ch=rows.map(x=>num(x.change??pct(num(x.last),num(x.prev)))).filter(v=>v!=null);const pos=ch.length?ch.filter(v=>v>0).length/ch.length:null;const sorted=ch.slice().sort((a,b)=>a-b);const med=sorted.length?sorted[Math.floor(sorted.length/2)]:null;const values=rows.map(x=>num(x.value)).filter(v=>v!=null&&v>0).sort((a,b)=>a-b);const valueMed=values.length?values[Math.floor(values.length/2)]:null;return {breadth:pos,medianChange:med,valueMedian:valueMed};}
 function pctScore(ch){if(ch==null)return null;if(ch<0)return clamp(30+ch*5);if(ch<0.4)return 62+ch*25;if(ch<=2.5)return 72+(ch-0.4)*8;if(ch<=4)return 89-(ch-2.5)*14;return clamp(68-(ch-4)*12);}
 const NEWS_CACHE='mjk_market_news_v8';
 const NEWS_TTL=10*60*1000;
 const NEWS_FEEDS=[
  'https://news.google.com/rss/search?q=%D8%A8%D9%88%D8%B1%D8%B3+%D8%A7%DB%8C%D8%B1%D8%A7%D9%86+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF+%D8%A7%DB%8C%D8%B1%D8%A7%D9%86&hl=fa&gl=IR&ceid=IR:fa',
  'https://news.google.com/rss/search?q=%D8%B3%DB%8C%D8%A7%D8%B3%D8%AA+%D8%A7%DB%8C%D8%B1%D8%A7%D9%86+%D8%AA%D8%AD%D8%B1%DB%8C%D9%85+%D9%85%D8%B0%D8%A7%DA%A9%D8%B1%D9%87&hl=fa&gl=IR&ceid=IR:fa',
  'https://news.google.com/rss/search?q=%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF+%D8%A7%DB%8C%D8%B1%D8%A7%D9%86+%D8%AF%D9%84%D8%A7%D8%B1+%D9%86%D8%B1%D8%AE+%D8%A8%D9%87%D8%B1%D9%87+%D8%AA%D9%88%D8%B1%D9%85&hl=fa&gl=IR&ceid=IR:fa',
  'https://news.google.com/rss/search?q=%D8%A7%D8%AC%D8%AA%D9%85%D8%A7%D8%B9%DB%8C+%D8%A7%DB%8C%D8%B1%D8%A7%D9%86+%D8%A7%D8%B9%D8%AA%D8%B5%D8%A7%D8%A8+%D8%A7%D8%B9%D8%AA%D8%B1%D8%A7%D8%B6&hl=fa&gl=IR&ceid=IR:fa'
 ];
 const NEWS_POS=['توافق','مذاکره','کاهش تحریم','رفع تحریم','افزایش صادرات','افزایش تولید','مجوز','قرارداد','رشد فروش','افزایش سود','افزایش سرمایه','تجدید ارزیابی','کاهش نرخ بهره','حمایت','کاهش ریسک','رفع محدودیت'];
 const NEWS_NEG=['تحریم','جنگ','حمله','بحران','قطعی','محدودیت','افزایش نرخ بهره','افزایش مالیات','عوارض صادرات','کاهش تولید','زیان','ورشکستگی','ناآرامی','اعتراض','اعتصاب','تنش'];
 function newsScoreText(t){const s=String(t||'');let v=0;for(const k of NEWS_POS)if(s.includes(k))v+=12;for(const k of NEWS_NEG)if(s.includes(k))v-=12;return clamp(v,-100,100);}
 function newsCategory(t){const s=String(t||'');return {political:/تحریم|مذاکره|دولت|مجلس|جنگ|حمله|سیاست|روابط/.test(s),economic:/اقتصاد|تورم|دلار|ارز|نرخ بهره|بانک مرکزی|بودجه|نفت|صادرات|واردات/.test(s),social:/اعتراض|اعتصاب|ناآرامی|اجتماعی|قطعی|تجمع/.test(s)};}
 function parseNews(xml){const out=[];const s=String(xml||'');const re=/<item[\s\S]*?<\/item>/gi;const blocks=s.match(re)||[];for(const b of blocks){const title=(b.match(/<title[^>]*>([\s\S]*?)<\/title>/i)||[])[1];const date=(b.match(/<pubDate[^>]*>([\s\S]*?)<\/pubDate>/i)||[])[1];const source=(b.match(/<source[^>]*>([\s\S]*?)<\/source>/i)||[])[1];if(!title)continue;const clean=String(title).replace(/<!\[CDATA\[|\]\]>/g,'').replace(/<[^>]+>/g,'').trim();const ts=Date.parse(date||'')||Date.now();out.push({title:clean,source:String(source||'').replace(/<[^>]+>/g,'').trim(),ts,score:newsScoreText(clean),category:newsCategory(clean)});}return out;}
 function marketNews(){const c=load(NEWS_CACHE);if(c?.at&&Date.now()-c.at<NEWS_TTL)return c;const items=[];for(const u of NEWS_FEEDS){try{const t=window.MJKNative?.fetchText?.(u);if(t&&!String(t).startsWith('MJK_NATIVE_ERROR:'))items.push(...parseNews(t));}catch(_){} }const now=Date.now(),fresh=items.filter(x=>now-x.ts<72*60*60*1000);let w=0,sw=0,political=0,economic=0,social=0;for(const x of fresh){const age=Math.max(0,now-x.ts),rw=Math.exp(-age/(24*60*60*1000));w+=rw;sw+=x.score*rw;if(x.category.political)political+=rw;if(x.category.economic)economic+=rw;if(x.category.social)social+=rw;}const result={at:now,items:fresh.slice(0,80),score:w?Math.round(sw/w):0,political:Math.round(political),economic:Math.round(economic),social:Math.round(social),count:fresh.length};save(NEWS_CACHE,result);return result;}
 function newsForRow(row,news){const text=`${row.symbol||''} ${row.company||row.name||''}`.trim();let mention=0,count=0;for(const n of (news?.items||[])){if(text&&((n.title||'').includes(row.symbol)||((row.company||'').length>3&&(n.title||'').includes(row.company)))){mention+=n.score;count++;}}const broad=Number(news?.score||0);const combined=count?clamp((mention/count)*.7+broad*.3,-100,100):broad;return {score:Math.round(combined),mentionCount:count,political:Number(news?.political||0),economic:Number(news?.economic||0),social:Number(news?.social||0)};}
 function clientFlowMap(){try{let j=nativeJson(`${CDN}/ClientType/GetClientTypeAll`);const a=j?.clientTypeAllDto||j?.data||j;if(!Array.isArray(a))return new Map();const m=new Map();for(const x of a){const id=String(x.insCode??x.InsCode??'');if(id)m.set(id,{naturalBuy:num(x.buy_I_Volume),legalBuy:num(x.buy_N_Volume),naturalSell:num(x.sell_I_Volume),legalSell:num(x.sell_N_Volume),naturalBuyCount:num(x.buy_I_Count),legalBuyCount:num(x.buy_N_Count),naturalSellCount:num(x.sell_I_Count),legalSellCount:num(x.sell_N_Count)});}return m;}catch(_){return new Map();}}
 function depthFor(id){if(!id)return null;const key='mjk_depth_v8_'+id,c=load(key);if(c?.at&&Date.now()-c.at<60000)return c;try{const j=nativeJson(`${CDN}/BestLimits/${encodeURIComponent(id)}`),a=j?.bestLimits||j?.data||j;if(!Array.isArray(a))return null;let bid=0,ask=0;for(const x of a){bid+=num(x.qTitMeDem)||0;ask+=num(x.qTitMeOf)||0;}if(!(bid||ask))return null;const d={at:Date.now(),bidDepth:bid,askDepth:ask,orderImbalance:(bid-ask)/Math.max(1,bid+ask)};save(key,d);return d;}catch(_){return null;}}
 function enrichMarketBoard(rows){const cf=clientFlowMap();let a=rows.map(x=>({...x,...(cf.get(String(x.insCode))||{})}));const prelim=a.map(x=>{const ch=num(x.change??pct(num(x.last),num(x.prev)))||0,vr=num(x.vol)&&num(x.baseVol)>0?num(x.vol)/num(x.baseVol):1;return {...x,_pre:Math.max(0,50+ch*8)+Math.min(25,Math.log1p(Math.max(0,vr))*12)+(num(x.value)>0?10:0)};}).sort((x,y)=>y._pre-x._pre).slice(0,24);for(const x of prelim){const d=depthFor(x.insCode);if(d)Object.assign(x,d);}const dm=new Map(prelim.map(x=>[String(x.insCode),x]));return a.map(x=>({...x,...(dm.get(String(x.insCode))||{})}));}
 function scoreStock(x,ctx={}){
   const last=num(x.last),prev=num(x.prev),close=num(x.close),low=num(x.low),high=num(x.high),vol=num(x.vol),base=num(x.baseVol),value=num(x.value),trades=num(x.trades),ch=num(x.change??pct(last,prev));
   const fresh=freshness(ctx.timestamp), dataQuality=quality(x), components={}, evidence={};
   const technicalParts=[];
   const chs=pctScore(ch); if(chs!=null)technicalParts.push(chs);
   if(last!=null&&close!=null)technicalParts.push(last>=close?85:30);
   const pos=low!=null&&high!=null&&high>low&&last!=null?(last-low)/(high-low):null;
   if(pos!=null)technicalParts.push(clamp(pos*100));
   if(technicalParts.length){components.technical=Math.round(technicalParts.reduce((a,b)=>a+b,0)/technicalParts.length);evidence.technical=true;x.dayPosition=pos;}

   const flowParts=[];
   if(vol!=null&&base!=null&&base>0){const r=vol/base;x.activityRatio=r;flowParts.push(r>=4?98:r>=3?92:r>=2?84:r>=1.4?74:r>=1?58:28);}
   const buy=num(x.naturalBuy),sell=num(x.naturalSell),lb=num(x.legalBuy),ls=num(x.legalSell),tot=(buy||0)+(sell||0)+(lb||0)+(ls||0);
   if(tot>0){const im=((buy||0)+(lb||0)-(sell||0)-(ls||0))/tot;x.moneyFlowImbalance=im;flowParts.push(clamp(50+im*50));}
   if(x.orderImbalance!=null){const oi=clamp(num(x.orderImbalance),-1,1);x.orderPressure=oi;flowParts.push(clamp(50+oi*50));}
   if(flowParts.length){components.flow=Math.round(flowParts.reduce((a,b)=>a+b,0)/flowParts.length);evidence.flow=true;}

   if(x.bidDepth!=null&&x.askDepth!=null){const bd=Math.max(0,num(x.bidDepth)||0),ad=Math.max(0,num(x.askDepth)||0),den=Math.max(1,bd+ad);x.depthImbalance=(bd-ad)/den;components.depth=Math.round(clamp(50+x.depthImbalance*50));evidence.depth=true;}
   if(value!=null&&trades!=null&&trades>0){const perTrade=value/trades;const med=ctx.valueMedian;components.liquidity=med?Math.round(clamp(50+Math.log10(Math.max(.1,perTrade/med))*35)):70;evidence.liquidity=true;}
   if(ctx.breadth!=null){components.regime=Math.round(clamp(50+(ctx.breadth-.5)*140));evidence.regime=true;}
   const eps=num(x.eps),pe=num(x.pe);if(eps!=null||pe!=null){let f=50;if(eps!=null)f+=eps>0?20:-25;if(pe!=null&&pe>0)f+=pe<12?25:pe<20?15:pe<40?5:-15;components.fundamental=Math.round(clamp(f));evidence.fundamental=true;}

   const news=ctx.news||marketNews(), ni=newsForRow(x,news); x.newsScore=ni.score; x.newsMentionCount=ni.mentionCount; x.newsPolitical=ni.political; x.newsEconomic=ni.economic; x.newsSocial=ni.social;
   if(ni.score!==0){components.catalyst=clamp(50+ni.score*.5);evidence.catalyst=true;}
   // Direct-move factors intentionally dominate. Fundamental is a confirmation filter, not the main short-horizon driver.
   const weights={flow:28,depth:22,technical:18,catalyst:12,liquidity:8,regime:7,fundamental:5};
   let ws=0,ww=0;for(const k of Object.keys(weights)){if(components[k]!=null){ws+=components[k]*weights[k];ww+=weights[k];}}
   const setupScore=ww?Math.round(clamp(ws/ww)):0;
   const critical=evidence.technical&&evidence.flow&&evidence.depth&&evidence.liquidity;
   const fullEvidence=critical&&(evidence.fundamental||evidence.catalyst||evidence.regime);
   const freshnessOk=!fresh.stale;
   const engines={technical:components.technical??null,flow:components.flow??null,depth:components.depth??null,liquidity:components.liquidity??null,regime:components.regime??null,fundamental:components.fundamental??null,catalyst:components.catalyst??null};
   return {...x,setupScore,preSurgeScore:setupScore,engines,evidence,evidenceCount:Object.values(evidence).filter(Boolean).length,criticalEvidence:critical,fullEvidence,freshness:fresh,dataQuality,notificationEligible:critical&&freshnessOk&&dataQuality>=70};
 }
 function historyRows(insCode){if(!insCode)return null;const key=HISTORY_CACHE+insCode;const cached=load(key);if(cached?.at&&Date.now()-cached.at<6*60*60*1000&&Array.isArray(cached.rows)&&cached.rows.length>=70)return cached.rows;const j=nativeJson(`${CDN}/ClosingPrice/GetClosingPriceDailyList/${encodeURIComponent(insCode)}/260`);const a=j?.closingPriceDaily||j?.data||[];if(!Array.isArray(a)||a.length<70)return null;const rows=a.map(r=>({date:num(r.dEven??r.date),open:num(r.pFirst??r.priceFirst??r.open??r.first),last:num(r.pDrCotVal??r.last),close:num(r.pClosing??r.close),prev:num(r.priceYesterday??r.prev),low:num(r.pMin??r.priceMin??r.low),high:num(r.pMax??r.priceMax??r.high),vol:num(r.qTotTran5J??r.vol),value:num(r.qTotCap??r.value),trades:num(r.zTotTran??r.trades)})).filter(r=>r.last!=null&&r.prev!=null&&r.low!=null&&r.high!=null&&r.prev>0).sort((a,b)=>(a.date||0)-(b.date||0));if(rows.length>=70)save(key,{at:Date.now(),rows});return rows;}
 function feat(h,i){const r=h[i],prior=h.slice(Math.max(0,i-20),i).map(x=>x.vol).filter(v=>v!=null&&v>0),med=prior.length?prior.slice().sort((a,b)=>a-b)[Math.floor(prior.length/2)]:null;const ch=pct(r.last,r.prev),pos=r.high>r.low?(r.last-r.low)/(r.high-r.low):.5,vr=med&&r.vol!=null?Math.min(10,r.vol/med):1,priorCh=h.slice(Math.max(0,i-5),i).map(x=>pct(x.last,x.prev)).filter(v=>v!=null);const accel=ch-(priorCh.length?priorCh.reduce((a,b)=>a+b,0)/priorCh.length:0);return [ch??0,pos,vr,accel];}
 function dist(a,b){return Math.sqrt(((a[0]-b[0])/2.5)**2+((a[1]-b[1])/.35)**2+((Math.log1p(a[2])-Math.log1p(b[2]))/.7)**2+((a[3]-b[3])/2.5)**2);}
 function outcome(h,i){const entry=h[i].last;let hit=false,stop=false;for(let j=i+1;j<=Math.min(i+2,h.length-1);j++){const up=pct(h[j].high,entry),down=pct(h[j].low,entry);if(down!=null&&down<=-STOP){stop=true;break;}if(up!=null&&up>=TARGET){hit=true;break;}}return hit&&!stop;}
 function featureVector(h,i){
   const r=h[i], prior20=h.slice(Math.max(0,i-20),i), prior5=h.slice(Math.max(0,i-5),i);
   const vols=prior20.map(x=>num(x.vol)).filter(v=>v!=null&&v>0).sort((a,b)=>a-b), med=vols.length?vols[Math.floor(vols.length/2)]:null;
   const ch=pct(r.last,r.prev)??0, pos=r.high>r.low?(r.last-r.low)/(r.high-r.low):.5;
   const vr=med&&num(r.vol)!=null?Math.min(10,num(r.vol)/med):1;
   const avg5=prior5.map(x=>pct(x.last,x.prev)).filter(v=>v!=null); const accel=ch-(avg5.length?avg5.reduce((a,b)=>a+b,0)/avg5.length:0);
   const ret5=i>=5&&h[i-5].last>0?(r.last/h[i-5].last-1)*100:0;
   const ret20=i>=20&&h[i-20].last>0?(r.last/h[i-20].last-1)*100:0;
   const range=r.low>0?(r.high-r.low)/r.low*100:0;
   return [ch,pos,Math.log1p(vr),accel,ret5,ret20,range];
 }
 function standardize(train){const d=train[0].length,mu=Array(d).fill(0),sd=Array(d).fill(0);for(const z of train)for(let k=0;k<d;k++)mu[k]+=z[k];for(let k=0;k<d;k++)mu[k]/=train.length;for(const z of train)for(let k=0;k<d;k++)sd[k]+=(z[k]-mu[k])**2;for(let k=0;k<d;k++)sd[k]=Math.sqrt(sd[k]/Math.max(1,train.length-1))||1;return {mu,sd};}
 function scaleVec(v,st){return v.map((x,k)=>(x-st.mu[k])/st.sd[k]);}
 function sigmoid(z){z=Math.max(-20,Math.min(20,z));return 1/(1+Math.exp(-z));}
 function trainLogistic(samples){
   if(!samples||samples.length<MIN_MODEL_SAMPLES)return null;
   const d=samples[0].x.length, split=Math.floor(samples.length*.7), train=samples.slice(0,split), val=samples.slice(split);
   const st=standardize(train.map(s=>s.x)), X=train.map(s=>scaleVec(s.x,st)), y=train.map(s=>s.y);let w=Array(d).fill(0),b=0;const lambda=.08,lr=.06;
   for(let epoch=0;epoch<220;epoch++){const gw=Array(d).fill(0);let gb=0;for(let i=0;i<X.length;i++){const p=sigmoid(b+w.reduce((a,v,k)=>a+v*X[i][k],0)),e=p-y[i];gb+=e;for(let k=0;k<d;k++)gw[k]+=e*X[i][k];}for(let k=0;k<d;k++)w[k]-=lr*((gw[k]/X.length)+lambda*w[k]);b-=lr*gb/X.length;}
   const pred=v=>sigmoid(b+w.reduce((a,z,k)=>a+z*scaleVec(v,st)[k],0));
   const brier=val.length?val.reduce((a,s)=>{const q=pred(s.x);return a+(q-s.y)**2},0)/val.length:null;
   const acc=val.length?val.reduce((a,s)=>a+((pred(s.x)>=.5?1:0)===s.y?1:0),0)/val.length:null;
   return {predict:pred,brier,accuracy:acc,trainSamples:train.length,validationSamples:val.length};
 }
 function fitLogisticAll(samples){
   if(!samples||samples.length<MIN_MODEL_SAMPLES)return null;const d=samples[0].x.length,st=standardize(samples.map(s=>s.x)),X=samples.map(s=>scaleVec(s.x,st)),y=samples.map(s=>s.y);let w=Array(d).fill(0),b=0;const lambda=.08,lr=.06;
   for(let epoch=0;epoch<220;epoch++){const gw=Array(d).fill(0);let gb=0;for(let i=0;i<X.length;i++){const p=sigmoid(b+w.reduce((a,v,k)=>a+v*X[i][k],0)),e=p-y[i];gb+=e;for(let k=0;k<d;k++)gw[k]+=e*X[i][k];}for(let k=0;k<d;k++)w[k]-=lr*((gw[k]/X.length)+lambda*w[k]);b-=lr*gb/X.length;}
   return {predict:v=>sigmoid(b+w.reduce((a,z,k)=>a+z*scaleVec(v,st)[k],0)),trainSamples:samples.length};
 }
 function walkForwardAudit(samples){
   if(!samples||samples.length<MIN_MODEL_SAMPLES)return null;
   const n=samples.length,oosStart=Math.max(Math.floor(n*.8),MIN_MODEL_SAMPLES),oos=samples.slice(oosStart);if(oos.length<30)return null;
   let brierSum=0,accN=0,positives=0,negatives=0,correct=0;
   for(let k=0;k<oos.length;k++){
     const train=samples.slice(0,oosStart+k);if(train.length<MIN_MODEL_SAMPLES)continue;
     const model=fitLogisticAll(train);if(!model)continue;const p=model.predict(oos[k].x),y=oos[k].y;brierSum+=(p-y)**2;accN++;if((p>=.5?1:0)===y)correct++;if(y)positives++;else negatives++;
   }
   if(accN<30)return null;
   const brier=brierSum/accN,accuracy=correct/accN;
   return {brier,accuracy,samples:accN,positiveRate:positives/accN,negativeRate:negatives/accN,oosStart,method:'expanding-walk-forward-untouched-oos'};
 }
 function wilson(wins,n){if(!n)return null;const z=1.96,p=wins/n,den=1+z*z/n,center=(p+z*z/(2*n))/den,half=z*Math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den;return {probability:100*p,lowerBound:100*(center-half),samples:n,wins};}
 function currentFeatureVector(h,current){
   if(!h||!h.length||!current)return null;
   const last=num(current.last),prev=num(current.prev),low=num(current.low),high=num(current.high),vol=num(current.vol);
   if(last==null||prev==null||prev<=0)return null;
   const prior20=h.slice(-20),prior5=h.slice(-5),vols=prior20.map(x=>num(x.vol)).filter(v=>v!=null&&v>0).sort((a,b)=>a-b),med=vols.length?vols[Math.floor(vols.length/2)]:null;
   const ch=pct(last,prev)??0,pos=high!=null&&low!=null&&high>low?(last-low)/(high-low):.5;
   const vr=med&&vol!=null?Math.min(10,vol/med):1;
   const avg5=prior5.map(x=>pct(x.last,x.prev)).filter(v=>v!=null),accel=ch-(avg5.length?avg5.reduce((a,b)=>a+b,0)/avg5.length:0);
   const ref5=h.length>=5&&h[h.length-5].last>0?(last/h[h.length-5].last-1)*100:0;
   const ref20=h.length>=20&&h[h.length-20].last>0?(last/h[h.length-20].last-1)*100:0;
   const range=low!=null&&low>0&&high!=null?(high-low)/low*100:0;
   return [ch,pos,Math.log1p(vr),accel,ref5,ref20,range];
 }
 function knnProbability(h,current){
   if(!h||h.length<90)return null;const cur=currentFeatureVector(h,current);if(!cur)return null;const matches=[];
   for(let i=45;i<h.length-2;i++){const f=featureVector(h,i);if(f[0]>8||f[0]<-8)continue;let d=0;for(let k=0;k<f.length;k++){const scale=k===1?.4:k===2?1:k===6?2:1;d+=((cur[k]-f[k])/scale)**2;}matches.push({d,i});}
   matches.sort((a,b)=>a.d-b.d);const top=matches.slice(0,K);if(top.length<MIN_SAMPLES)return null;const wins=top.filter(m=>outcome(h,m.i)).length;return wilson(wins,top.length);
 }
 function knnProbabilityAt(h,i){
   if(!h||i<90||i>=h.length)return null;const prefix=h.slice(0,i+1),cur=h[i],matches=[];const cf=currentFeatureVector(prefix,cur);if(!cf)return null;
   for(let j=45;j<=i-3;j++){const f=featureVector(prefix,j);if(!f||f[0]>8||f[0]<-8)continue;let d=0;for(let k=0;k<f.length;k++){const scale=k===1?.4:k===2?1:k===6?2:1;d+=((cf[k]-f[k])/scale)**2;}matches.push({d,j});}
   matches.sort((a,b)=>a.d-b.d);const top=matches.slice(0,K);if(top.length<MIN_SAMPLES)return null;const wins=top.filter(m=>outcome(prefix,m.j)).length;return wilson(wins,top.length);
 }
 function proWalkForwardAudit(h){
   if(!h||h.length<MIN_MODEL_SAMPLES+25)return null;const samples=[];
   for(let i=45;i<h.length-2;i++){const x=featureVector(h,i);if(!x||x[0]>8||x[0]<-8)continue;samples.push({x,y:outcome(h,i)?1:0,i});}
   if(samples.length<MIN_MODEL_SAMPLES+30)return null;
   const minTrain=MIN_MODEL_SAMPLES,oosStart=Math.max(minTrain,Math.floor(samples.length*.55)),preds=[];
   for(let k=oosStart;k<samples.length;k++){const train=samples.slice(0,k);const model=fitLogisticAll(train);if(!model)continue;const rec=samples[k],prefix=h.slice(0,rec.i+1),knn=knnProbabilityAt(h,rec.i);if(!knn)continue;const mp=model.predict(rec.x),kp=knn.probability/100,p=.5*mp+.5*kp;preds.push({p,y:rec.y});}
   if(preds.length<60)return null;
   const brier=preds.reduce((a,r)=>a+(r.p-r.y)**2,0)/preds.length,accuracy=preds.reduce((a,r)=>a+((r.p>=.5?1:0)===r.y?1:0),0)/preds.length;
   const bins=[];for(let b=0;b<5;b++){const a=b*.2,z=(b+1)*.2,rs=preds.filter(r=>r.p>=a&&(b===4?r.p<=z:r.p<z));if(rs.length>=8){const meanP=rs.reduce((q,r)=>q+r.p,0)/rs.length,rate=rs.reduce((q,r)=>q+r.y,0)/rs.length;bins.push({from:a,to:z,n:rs.length,p:meanP,rate,gap:Math.abs(meanP-rate)});}}
   const calibrationGap=bins.length?Math.max(...bins.map(b=>b.gap)):1;
   const folds=[];const foldSize=Math.max(1,Math.floor(preds.length/4));for(let f=0;f<4;f++){const a=f*foldSize,b=f===3?preds.length:(f+1)*foldSize,r=preds.slice(a,b);if(r.length<10)continue;folds.push({n:r.length,brier:r.reduce((q,v)=>q+(v.p-v.y)**2,0)/r.length,accuracy:r.reduce((q,v)=>q+((v.p>=.5?1:0)===v.y?1:0),0)/r.length});}
   const foldPass=folds.length===4&&folds.every(f=>f.brier<.28&&f.accuracy>=.50);
   return {brier,accuracy,samples:preds.length,calibrationGap,calibrationBins:bins,folds,foldPass,oosStart,method:'pro-ensemble-expanding-walk-forward-untouched-oos'};
 }
 function empiricalProbability(h,current){
   if(!h||h.length<MIN_MODEL_SAMPLES)return null;const samples=[];for(let i=45;i<h.length-2;i++){const x=featureVector(h,i);if(!x||x[0]>8||x[0]<-8)continue;samples.push({x,y:outcome(h,i)?1:0});}
   if(samples.length<MIN_MODEL_SAMPLES)return null;const audit=proWalkForwardAudit(h);if(!audit)return null;const model=fitLogisticAll(samples),knn=knnProbability(h,current);if(!model||!knn)return null;const cur=currentFeatureVector(h,current);if(!cur)return null;
   const lp=model.predict(cur)*100,p=Math.round(lp*.5+knn.probability*.5);
   return {probability:p,modelProbability:Math.round(lp),knnProbability:Math.round(knn.probability),lowerBound:Math.round(knn.lowerBound),samples:knn.samples,wins:knn.wins,targetPct:TARGET,stopPct:STOP,method:audit.method,oosBrier:audit.brier,oosAccuracy:audit.accuracy,oosSamples:audit.samples,oosPositiveRate:samples.reduce((a,s)=>a+s.y,0)/samples.length,proCalibrationGap:audit.calibrationGap,proFolds:audit.folds,proFoldPass:audit.foldPass};
 }
 function validateCandidates(rows){const candidates=rows.filter(x=>x.insCode&&x.dataQuality>=48&&x.setupScore>=55).slice(0,30);for(const x of candidates){try{const h=historyRows(x.insCode),ep=empiricalProbability(h,x);if(ep){x.probability=ep.probability;x.probabilityLowerBound=ep.lowerBound;x.probabilitySamples=ep.samples;x.probabilityWins=ep.wins;x.modelProbability=ep.modelProbability;x.knnProbability=ep.knnProbability;x.probabilityMethod=ep.method;x.targetPct=ep.targetPct;x.stopPct=ep.stopPct;x.oosBrier=ep.oosBrier;x.oosAccuracy=ep.oosAccuracy;x.oosSamples=ep.oosSamples;x.oosPositiveRate=ep.oosPositiveRate;x.proCalibrationGap=ep.proCalibrationGap;x.proFolds=ep.proFolds;x.proFoldPass=ep.proFoldPass;}}catch(_){}}return rows;}
 function finalizeStock(x){
   const p=x.probability,lb=num(x.probabilityLowerBound),oosB=num(x.oosBrier),oosN=num(x.oosSamples),oosA=num(x.oosAccuracy),cal=num(x.proCalibrationGap);
   const t=num(x.engines?.technical),f=num(x.engines?.flow),d=num(x.engines?.depth),c=num(x.engines?.catalyst);
   const predictiveConsensus=p!=null?Math.round(clamp(p*.5+(t??50)*.2+(f??50)*.15+(d??50)*.1+(c??50)*.05)):null;
   const proValid=oosB!=null&&oosN>=60&&oosB<.22&&oosA!=null&&oosA>=.58&&cal!=null&&cal<=.10&&x.proFoldPass===true;
   const ready=p!=null&&lb!=null&&predictiveConsensus!=null&&predictiveConsensus>=80&&x.probabilitySamples>=MIN_SAMPLES&&lb>=80&&num(x.modelProbability)>=80&&num(x.knnProbability)>=70&&x.setupScore>=70&&x.dataQuality>=70&&x.criticalEvidence&&x.fullEvidence&&x.freshness.fresh&&proValid;
   const direction=ready?'PRE-SURGE':(p!=null?'WATCH-VALIDATING':x.setupScore>=55?'WATCH':'NO-EDGE');
   const rankKey=ready?3:(p!=null&&proValid?2:(x.setupScore>=55?1:0));
   return {...x,predictiveConsensus,direction,rankKey,oosValid:proValid,proValid,probabilityStatus:ready?'signal-pro-validated':p!=null?'validated-but-below-pro-gate':'not-calibrated'};
 }
 function commodityHistory(insCode){if(!insCode)return null;const key=HISTORY_CACHE+'c_'+insCode;const cached=load(key);if(cached?.at&&Date.now()-cached.at<12*60*60*1000&&Array.isArray(cached.rows)&&cached.rows.length>=40)return cached.rows;const j=nativeJson(`${CDN}/ClosingPrice/GetClosingPriceDailyList/${encodeURIComponent(insCode)}/180`);const a=j?.closingPriceDaily||j?.data||[];if(!Array.isArray(a)||a.length<40)return null;const rows=a.map(r=>({close:num(r.pClosing??r.close),last:num(r.pDrCotVal??r.last),prev:num(r.priceYesterday??r.prev),low:num(r.priceMin??r.low),high:num(r.priceMax??r.high),vol:num(r.qTotTran5J??r.vol),value:num(r.qTotCap??r.value),date:num(r.dEven??r.date)})).filter(r=>r.close!=null&&r.close>0).sort((a,b)=>(a.date||0)-(b.date||0));if(rows.length>=40)save(key,{at:Date.now(),rows});return rows;}
 function ret(h,n){if(!h||h.length<=n)return null;const a=h[h.length-1].close,b=h[h.length-1-n].close;return a!=null&&b>0?(a-b)/b*100:null;}
 function commodityCatchup(h){if(!h||h.length<40)return null;const r20=ret(h,20),r60=ret(h,60),r120=ret(h,120),last=h[h.length-1].close;const h60=Math.max(...h.slice(-60).map(x=>x.high??x.close).filter(v=>v!=null)),h120=Math.max(...h.slice(-120).map(x=>x.high??x.close).filter(v=>v!=null));const dd60=h60>0?(last-h60)/h60*100:null,dd120=h120>0?(last-h120)/h120*100:null;const recent=h.slice(-5).map(x=>x.close).filter(v=>v!=null),prior=h.slice(-20,-5).map(x=>x.close).filter(v=>v!=null);const accel=recent.length>=2&&prior.length>=2?((recent[recent.length-1]/recent[0]-1)-(prior[prior.length-1]/prior[0]-1))*100:null;const lag=clamp(50-(r60??0)*2.2-(r120??0)*.8);const nearLow=clamp(50+(dd60??-10)*3);const accelScore=clamp(50+(accel??0)*8);const recovery=clamp(50+(r20??0)*3);return {r20,r60,r120,dd60,dd120,accel,lagScore:Math.round(lag),nearHighScore:Math.round(100+Math.min(0,dd60??-20)*3),accelScore:Math.round(accelScore),recoveryScore:Math.round(recovery),catchUpScore:Math.round(clamp(lag*.45+nearLow*.25+accelScore*.15+recovery*.15))};}
 function commodityOutcome(h,i){if(i>=h.length-5)return null;const entry=h[i].last??h[i].close;if(!(entry>0))return false;let hit=false,stop=false;for(let j=i+1;j<=Math.min(i+5,h.length-1);j++){const up=pct(h[j].high,entry),down=pct(h[j].low,entry);if(down!=null&&down<=-2){stop=true;break;}if(up!=null&&up>=3){hit=true;break;}}return hit&&!stop;}
 function commodityHistorical(h,current){if(!h||h.length<80)return null;const cur=commodityCatchup(h);if(!cur)return null;const matches=[];for(let i=50;i<h.length-5;i++){const c=commodityCatchup(h.slice(0,i+1));if(!c)continue;const d=Math.sqrt(((c.r20-cur.r20)/8)**2+((c.r60-cur.r60)/15)**2+((c.dd60-cur.dd60)/12)**2+((c.accel-cur.accel)/5)**2);matches.push({d,i});}matches.sort((a,b)=>a.d-b.d);const top=matches.slice(0,50);if(top.length<40)return null;const wins=top.filter(m=>commodityOutcome(h,m.i)).length,n=top.length,p=wins/n,z=1.96,den=1+z*z/n,center=(p+z*z/(2*n))/den,half=z*Math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den;return {probability:Math.round(p*100),lowerBound:Math.round((center-half)*100),samples:n,wins,targetPct:3,stopPct:2,horizon:5,method:'historical-catchup-pattern-wilson95'};}
 function scoreCommodity(x,ctx={}){const last=num(x.last),prev=num(x.prev),close=num(x.close),ch=num(x.change??pct(last,prev)),vol=num(x.vol),value=num(x.value),trades=num(x.trades),hist=x.history||null,components={},evidence={};const cu=commodityCatchup(hist);if(cu){components.catchup=cu.catchUpScore;components.trend=clamp(50+(cu.r60??0)*2.5);components.momentum=clamp(50+(cu.r20??0)*3+(cu.accel??0)*5);components.relative=clamp(50+(cu.dd60??-10)*-2.5);evidence.catchup=true;evidence.trend=true;}if(last!=null&&prev!=null){components.momentum=components.momentum??Math.round(clamp(50+(ch||0)*12));evidence.momentum=true;}if(hist?.length>=20){const vols=hist.slice(-20).map(r=>r.vol).filter(v=>v!=null&&v>0).sort((a,b)=>a-b);if(vols.length&&vol!=null){const med=vols[Math.floor(vols.length/2)],vr=vol/med;components.flow=Math.round(clamp(50+Math.log1p(Math.min(10,vr))*28));evidence.flow=true;}}if(!components.flow&&vol!=null&&value!=null&&trades!=null){components.flow=Math.round(clamp(50+Math.log10(Math.max(1,(value/Math.max(1,trades))))*3));evidence.flow=true;}if(value!=null&&trades!=null&&trades>0){components.liquidity=Math.round(clamp(50+Math.log10(Math.max(1,value/trades))*4));evidence.liquidity=true;}if(close!=null&&last!=null){components.relative=components.relative??Math.round(clamp(50+(last-close)/(Math.abs(close)||1)*250));evidence.relative=true;}if(x.peerLag!=null){components.peerLag=clamp(50+x.peerLag*3.5);evidence.peerLag=true;}const weights={catchup:30,peerLag:20,trend:14,momentum:14,flow:12,liquidity:6,relative:4};let ws=0,ww=0;for(const k of Object.keys(weights)){if(components[k]!=null){ws+=components[k]*weights[k];ww+=weights[k];}}const score=ww?Math.round(clamp(ws/ww)):0;const votes=Object.values(components).filter(v=>v!=null&&v>=65).length;const hp=commodityHistorical(hist,x);const predictiveConsensus=hp?Math.round(clamp(hp.probability*.45+(components.catchup??50)*.25+(components.momentum??50)*.15+(components.flow??50)*.15)):null;return {...x,predictiveConsensus,score,preSurgeScore:score,direction:score>=72&&votes>=3?'WATCH':'NO-EDGE',votes,totalEngines:7,engines:{catchup:components.catchup??null,peerLag:components.peerLag??null,trend:components.trend??null,momentum:components.momentum??null,flow:components.flow??null,liquidity:components.liquidity??null,relative:components.relative??null,macro:null,risk:score>=75?35:60},catchUp:cu,historicalProbability:hp?.probability??null,historicalLowerBound:hp?.lowerBound??null,historicalSamples:hp?.samples??0,dataQuality:quality(x),freshness:freshness(ctx.timestamp),evidence};}
 function enrichCommodity(rows,ctx){const prelim=rows.map(x=>scoreCommodity({...x},ctx)).sort((a,b)=>(b.score-a.score)||(b.value??0)-(a.value??0));const top=prelim.filter(x=>x.insCode).slice(0,80);for(const x of top){try{x.history=commodityHistory(x.insCode);}catch(_){}}const rs=top.map(x=>ret(x.history,60)).filter(v=>v!=null).sort((a,b)=>a-b);const med=rs.length?rs[Math.floor(rs.length/2)]:null;for(const x of top){const r60=ret(x.history,60);x.peerLag=med!=null&&r60!=null?med-r60:null;}const hm=new Map(top.map(x=>[x.insCode,x]));return prelim.map(x=>scoreCommodity({...x,...(hm.get(x.insCode)||{}),history:hm.get(x.insCode)?.history},ctx)).sort((a,b)=>((b.historicalLowerBound??-1)-(a.historicalLowerBound??-1))||((b.catchUp?.catchUpScore??-1)-(a.catchUp?.catchUpScore??-1))||(b.score-a.score));}
 function alertOnce(item,kind,notify){if(kind!=='stock')return;if(item.freshness.stale)return;if(item.direction!=='PRE-SURGE'||item.probabilityLowerBound<80||item.probabilitySamples<MIN_SAMPLES||!item.oosValid)return;const key=`stock:${item.symbol}:${item.probability}-${item.probabilityLowerBound}`;const old=load(ALERT)||{};if(old[key]&&Date.now()-old[key]<18*60*60*1000)return;old[key]=Date.now();save(ALERT,old);try{window.MJKNative?.radarAlert?.(JSON.stringify({kind:'stock',symbol:item.symbol,direction:item.direction,probability:item.probability,samples:item.probabilitySamples,lowerBound:item.probabilityLowerBound,score:item.setupScore,reason:`نرخ موفقیت تاریخی ${item.probability}% با حد پایین ${item.probabilityLowerBound}% در ${item.probabilitySamples} الگو · OOS Brier ${item.oosBrier?.toFixed?.(3)??'—'} · هدف ${TARGET}% در حداکثر ۲ روز`}));}catch(_){}if(notify)notify(item);}
 function analyze(kind,payload,notify){if(!payload?.rows?.length)return null;const ctx={...payload.meta,market:marketContext(payload.rows),news:kind==='stock'?marketNews():null};let rows=payload.rows.map(x=>kind==='stock'?scoreStock({...x},ctx):scoreCommodity({...x},ctx)).filter(x=>x.last!=null&&x.dataQuality>=48);if(kind==='stock'){rows.sort((a,b)=>b.setupScore-a.setupScore);validateCandidates(rows);rows=rows.map(finalizeStock).sort((a,b)=>(b.rankKey-a.rankKey)||(b.probabilityLowerBound??-1)-(a.probabilityLowerBound??-1)||(b.probabilitySamples??-1)-(a.probabilitySamples??-1)||(b.setupScore-a.setupScore));}else{rows=enrichCommodity(rows,ctx);}const result={meta:payload.meta,rows,top:rows[0]||null,checkedAt:Date.now()};if(rows.length)save(CACHE+'_'+kind,result);if(kind==='stock'&&rows[0])alertOnce(rows[0],kind,notify);return result;}
 function cached(kind){return load(CACHE+'_'+kind)}
 return {fetchRelay,analyze,cached,freshness,getRelay,save,load,enrichMarketBoard,marketNews,dailyHistory:historyRows};
})();
