/* MJK Opportunity Engine v2
 * Evidence-first multi-engine radar. No fabricated values.
 * Freshness, source health, depth, money-flow and data completeness are explicit.
 */
window.MJKOpportunity=(()=>{
 const CACHE='mjk_opportunity_cache_v2', ALERT='mjk_opportunity_alerts_v2';
 const num=v=>{const x=Number(String(v??'').replace(/,/g,''));return Number.isFinite(x)?x:null};
 const clamp=(x,a=0,b=100)=>Math.max(a,Math.min(b,x));
 const pct=(a,b)=>a==null||b==null||!b?null:(a-b)/Math.abs(b)*100;
 const ageMs=t=>{const x=Number(t);return Number.isFinite(x)?Math.max(0,Date.now()-(x<1e12?x*1000:x)):Infinity};
 function freshness(ts){const age=ageMs(ts);return {ageMs:age,ageSec:Number.isFinite(age)?Math.round(age/1000):null,live:age<=90000,stale:age>15*60*1000};}
 function save(key,data){try{localStorage.setItem(key,JSON.stringify(data));}catch(_){} }
 function load(key){try{return JSON.parse(localStorage.getItem(key)||'null')}catch(_){return null}}
 function getRelay(){return String(localStorage.getItem('mjk_relay_url')||'').trim().replace(/\/$/,'');}
 function getToken(){return String(localStorage.getItem('mjk_streamdata_token')||'').trim();}
 function nativeJson(url){try{const t=window.MJKNative?.fetchJson?.(url);if(!t||String(t).startsWith('MJK_NATIVE_ERROR:'))return null;return JSON.parse(t)}catch(_){return null}}
 function normalizePayload(j,market){
   if(!j)return null;
   const rows=j.items||j.rows||j.data?.items||j.data?.rows||j.data||[];
   if(!Array.isArray(rows)||!rows.length)return null;
   const meta={
     source:j.source||j.provider||market||'unknown',
     timestamp:j.timestamp||j.ts||j.updatedAt||Date.now(),
     marketStatus:j.marketStatus||j.status||'unknown',
     live:j.live===true,
     dataAgeSec:num(j.dataAgeSec),
     upstreamOk:j.upstreamOk!==false,
     news:j.news||[],macro:j.macro||{}
   };
   return {meta,rows};
 }
 function fetchRelay(kind){
   const base=getRelay(); if(!base)return null;
   const path=kind==='stock'?'/mjk/v1/radar/stocks':'/mjk/v1/radar/commodities';
   return normalizePayload(nativeJson(base+path),'MJK Relay');
 }
 function quality(x){
   const fields=['last','prev','vol','value','trades'];
   const have=fields.filter(k=>num(x[k])!=null).length;
   const extras=['avgVol','buyNaturalVol','sellNaturalVol','orderImbalance','eps','pe'].filter(k=>num(x[k])!=null).length;
   return Math.round(clamp(have*12+extras*5,0,100));
 }
 function scoreStock(x,ctx={}){
   const last=num(x.last??x.price??x.close), prev=num(x.prev??x.yesterday??x.previousClose), close=num(x.close??x.pClosing), vol=num(x.vol??x.volume), value=num(x.value??x.tradeValue), trades=num(x.trades??x.tradeCount);
   const ch=num(x.change??x.chg??pct(last,prev));
   let technical=0, flow=0, liquidity=0, fundamental=0, catalyst=0, risk=68, regime=0;
   if(last!=null&&close!=null){if(last>close)technical+=8;if(last<close)risk-=4;}
   if(ch!=null){if(ch>2)technical+=20;else if(ch>0.6)technical+=13;else if(ch>0)technical+=7;else if(ch<-2)risk-=18;else if(ch<0)risk-=7;}
   const av=num(x.avgVol); if(vol!=null&&av!=null&&av>0){const vr=vol/av;if(vr>=3){flow+=25;catalyst+=10}else if(vr>=2){flow+=20;catalyst+=7}else if(vr>=1.3){flow+=12;catalyst+=4};x.volumeRatio=vr;}
   const buy=num(x.buyNaturalVol??x.naturalBuy), sell=num(x.sellNaturalVol??x.naturalSell), legalBuy=num(x.legalBuy), legalSell=num(x.legalSell);
   const total=(buy||0)+(sell||0)+(legalBuy||0)+(legalSell||0);
   if(total>0){const im=((buy||0)+(legalBuy||0)-(sell||0)-(legalSell||0))/total;flow+=clamp(12+im*38,0,32);x.moneyFlowImbalance=im;}
   if(x.orderImbalance!=null){const oi=clamp(num(x.orderImbalance),-1,1);flow+=clamp(oi*18,0,18);x.orderPressure=oi;}
   if(x.bidDepth!=null&&x.askDepth!=null){const den=Math.max(1,num(x.bidDepth)+num(x.askDepth));x.depthImbalance=(num(x.bidDepth)-num(x.askDepth))/den;flow+=clamp(x.depthImbalance*18,0,18);}
   if(value!=null&&trades!=null&&trades>0){liquidity+=10;const avg=value/trades;if(avg>0)liquidity+=Math.min(10,Math.log10(avg)*1.2);}
   const eps=num(x.eps), pe=num(x.pe); if(eps!=null&&eps>0){fundamental+=12;if(pe!=null&&pe>0){if(pe<12)fundamental+=10;else if(pe<20)fundamental+=7;else if(pe>40){fundamental-=7;risk-=5;}}}
   if(x.newsImpact==='positive')catalyst+=12;if(x.newsImpact==='negative'){catalyst-=15;risk-=12;}
   if(x.industryTrend==='up')regime+=10;if(x.industryTrend==='down'){regime-=10;risk-=5;}
   if(x.trend20==='up')technical+=12;if(x.trend20==='down')risk-=8;
   if(x.breakout===true){technical+=12;catalyst+=5;} if(x.breakdown===true){technical-=15;risk-=12;}
   const dataQuality=quality(x);
   const fresh=freshness(ctx.timestamp);
   if(fresh.stale)risk-=10;
   const raw=technical+flow+liquidity+fundamental+catalyst+regime+risk*.30;
   const score=clamp(raw*(0.65+dataQuality/285));
   const engines={technical:Math.round(clamp(technical*3.4)),flow:Math.round(clamp(flow*2.8)),liquidity:Math.round(clamp(liquidity*7)),fundamental:Math.round(clamp(fundamental*4.2)),catalyst:Math.round(clamp(catalyst*4.5)),regime:Math.round(clamp(50+regime*3.8)),risk:Math.round(clamp(risk)),depth:Math.round(clamp(50+(num(x.depthImbalance)||0)*70))};
   const votes=[engines.technical>=60,engines.flow>=60,engines.liquidity>=55,engines.fundamental>=55,engines.catalyst>=55,engines.regime>=55,engines.depth>=60].filter(Boolean).length;
   const direction=score>=76&&votes>=4&&ch!=null&&ch>=0?'BUY-WATCH':score<=35?'RISK':'WATCH';
   return {...x,last,prev,close,ch,score:Math.round(score),engines,votes,direction,dataQuality,freshness:fresh};
 }
 function scoreCommodity(x,ctx={}){
   const last=num(x.last??x.price??x.close), prev=num(x.prev??x.previousClose), ch=num(x.change??x.chg??pct(last,prev)), vol=num(x.vol??x.volume), oi=num(x.openInterest), basis=num(x.basis);
   let trend=0,momentum=0,flow=0,relative=0,macro=0,risk=65;
   if(ch!=null){if(ch>1.5)momentum+=24;else if(ch>0.5)momentum+=16;else if(ch>0)momentum+=8;else if(ch<-2)risk-=18;}
   const av=num(x.avgVol);if(vol!=null&&av){const vr=vol/Math.max(1,av);if(vr>3)flow+=28;else if(vr>2)flow+=22;else if(vr>1.3)flow+=14;x.volumeRatio=vr;}
   if(oi!=null&&oi>0){flow+=10;if(ch!=null&&ch>0)trend+=12;}
   if(basis!=null){relative+=clamp(14-Math.abs(basis)*0.8,0,14);if(Math.abs(basis)>10)risk-=8;}
   if(x.globalTrend==='up')macro+=20;if(x.globalTrend==='down'){macro-=12;risk-=7;}
   trend+=ch!=null&&ch>0?20:0;
   const fresh=freshness(ctx.timestamp);if(fresh.stale)risk-=10;
   const dataQuality=quality(x);const raw=trend+momentum+flow+relative+macro+risk*.30;const score=clamp(raw*(0.68+dataQuality/310));
   const engines={trend:Math.round(clamp(trend*3.8)),momentum:Math.round(clamp(momentum*3.8)),flow:Math.round(clamp(flow*2.8)),relative:Math.round(clamp(relative*5)),macro:Math.round(clamp(50+macro*3)),risk:Math.round(clamp(risk))};
   const votes=[engines.trend>=60,engines.momentum>=60,engines.flow>=55,engines.relative>=55,engines.macro>=55].filter(Boolean).length;
   return {...x,last,prev,ch,score:Math.round(score),engines,votes,direction:score>=76&&votes>=4&&ch!=null&&ch>=0?'BUY-WATCH':score<=35?'RISK':'WATCH',dataQuality,freshness:fresh};
 }
 function alertOnce(item,kind,notify){
   if(item.score<82||item.votes<(kind==='stock'?4:4)||item.dataQuality<55||item.freshness.stale)return;
   const key=`${kind}:${item.symbol||item.name}:${Math.round(item.score/5)}`;const old=load(ALERT)||{};
   if(old[key]&&Date.now()-old[key]<3*60*60*1000)return;
   old[key]=Date.now();save(ALERT,old);
   try{window.MJKNative?.radarAlert?.(JSON.stringify({kind,symbol:item.symbol||item.name,score:item.score,direction:item.direction,reason:`${item.votes} موتور هم‌جهت · کیفیت داده ${item.dataQuality}%`}));}catch(_){}
   if(notify)notify(item);
 }
 function analyze(kind,payload,notify){
   if(!payload?.rows?.length)return null;
   const rows=payload.rows.map(x=>kind==='stock'?scoreStock({...x},payload.meta):scoreCommodity({...x},payload.meta)).filter(x=>x.last!=null&&x.dataQuality>=48).sort((a,b)=>b.score-a.score);
   const result={meta:payload.meta,rows,top:rows[0]||null,checkedAt:Date.now()};
   save(CACHE+'_'+kind,result);rows.slice(0,30).forEach(x=>alertOnce(x,kind,notify));return result;
 }
 function cached(kind='stock'){return load(CACHE+'_'+kind)}
 return {fetchRelay,analyze,cached,freshness,getRelay,getToken,save,load};
})();
