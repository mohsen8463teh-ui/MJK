window.MJKNative = window.MJKNative || {};
class App{
  constructor(){this.tab='dashboard';this.loading=false;this.bind();this.load();}
  bind(){
    document.querySelectorAll('.nav').forEach(b=>b.onclick=()=>this.go(b.dataset.tab));
    document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>this.go(b.dataset.go));
    const refresh=document.getElementById('refresh');if(refresh)refresh.onclick=()=>this.load();
    const notify=document.getElementById('notify');
    if(notify){notify.checked=localStorage.getItem('mjk_notify')!=='0';notify.onchange=e=>{localStorage.setItem('mjk_notify',e.target.checked?'1':'0');this.toast('تنظیمات اعلان ذخیره شد','ok');};}
    const clear=document.getElementById('clearHistory');
    if(clear)clear.onclick=()=>{if(confirm('تاریخچه پاک شود؟')){MJK.clearData();this.load();this.toast('تاریخچه پاک شد','ok');}};
  }
  go(tab){
    this.tab=tab;
    document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
    document.querySelectorAll('.tab').forEach(s=>s.classList.toggle('active',s.id===tab));
    // Navigation must never wait for network/native HTTP work.
    if(tab==='paper')window.dashboard?.renderHistory();
    if(tab==='backtest')window.backtest?.renderHistory();
    if(tab==='prices')window.prices?.activate?.();
    if(tab==='signals')window.signals?.activate?.();
    if(tab==='technical')window.technical?.activate?.();
    if(tab==='smartmoney')window.smartmoney?.activate?.();
  }
  async load(){
    if(this.loading)return;
    this.loading=true;
    // Only lightweight/local rendering is done at startup. Heavy native network
    // requests are started by each tab when it becomes visible, preventing a
    // queue of synchronous WebView requests from freezing navigation.
    setTimeout(()=>window.dashboard?.load(),0);
    setTimeout(()=>window.prices?.activate?.(),80);
    setTimeout(()=>{window.dashboard?.startPriceUpdates?.();window.dashboard?.renderHistory();window.backtest?.renderHistory();this.loading=false;},160);
  }
  toast(msg,type='ok'){const d=document.createElement('div');d.className='toast '+type;d.textContent=msg;const t=document.getElementById('toast');if(t)t.appendChild(d);setTimeout(()=>d.remove(),3500);}
}
window.addEventListener('visibilitychange',()=>{if(!document.hidden){const t=window.app?.tab;if(t==='dashboard')window.dashboard?.refreshPrice?.();if(t==='prices')window.prices?.activate?.();if(t==='signals')window.signals?.activate?.();if(t==='technical')window.technical?.activate?.();if(t==='smartmoney')window.smartmoney?.activate?.();}});
window.addEventListener('DOMContentLoaded',()=>{window.app=new App();});
