window.MJKNative = window.MJKNative || {};
class App{
  constructor(){this.tab='dashboard';this.loading=false;this.bind();this.load();}
  bind(){
    document.querySelectorAll('.nav').forEach(b=>b.onclick=()=>this.go(b.dataset.tab));
    document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>this.go(b.dataset.go));
    const refresh=document.getElementById('refresh');if(refresh)refresh.onclick=()=>this.load();
    const notify=document.getElementById('notify');
    if(notify){notify.checked=localStorage.getItem('mjk_notify')!=='0';notify.onchange=e=>{localStorage.setItem('mjk_notify',e.target.checked?'1':'0');this.toast('تنظیمات اعلان ذخیره شد','ok');};}
    const clear=document.getElementById('clearHistory');
    if(clear)clear.onclick=()=>{if(confirm('تاریخچه پاک شود؟')){MJK.clearData();this.load();this.toast('تاریخچه پاک شد','ok');}};
  }
  go(tab){
    this.tab=tab;
    document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
    document.querySelectorAll('.tab').forEach(s=>s.classList.toggle('active',s.id===tab));
    // Navigation is UI-only: never wait for network requests before showing the tab.
    if(tab==='paper')window.dashboard?.renderHistory();
    if(tab==='backtest')window.backtest?.renderHistory();
    if(tab==='prices')window.prices?.activate();
    if(tab==='signals')window.signals?.check?.(false);
    if(tab==='technical')window.technical?.activate?.();
    if(tab==='smartmoney')window.smartmoney?.activate?.();
  }
  async load(){
    if(this.loading)return;
    this.loading=true;
    // Start each page independently so one slow endpoint cannot block the others.
    setTimeout(()=>window.dashboard?.load(),0);
    setTimeout(()=>window.signals?.check?.(false),120);
    setTimeout(()=>window.prices?.load(),240);
    setTimeout(()=>window.dashboard?.startPriceUpdates?.(),360);
    setTimeout(()=>{window.dashboard?.renderHistory();window.backtest?.renderHistory();window.prices?.render();this.loading=false;},450);
  }
  toast(msg,type='ok'){const d=document.createElement('div');d.className='toast '+type;d.textContent=msg;const t=document.getElementById('toast');if(t)t.appendChild(d);setTimeout(()=>d.remove(),3500);}
}
window.addEventListener('DOMContentLoaded',()=>{window.app=new App();});
