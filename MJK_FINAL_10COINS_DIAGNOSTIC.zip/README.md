# MJK — Premium Android UI

نسخه بهینه‌شده MJK با رابط کاربری موبایل‌محور، تیره/طلایی، کارت‌های خوانا، لوگوی MJK، داشبورد فشرده و ناوبری مناسب صفحه کوچک.

- BTCUSDT / 15m
- Live Signal / Backtest / Open Trade Tracking
- Live crypto prices from public Binance API
- User-supplied MJK artwork used as app logo/icon
- No real order execution
