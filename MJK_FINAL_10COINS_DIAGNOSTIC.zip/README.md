# MJK V15 — live Iranian market data fix

This version keeps the working music system and changes the Iranian market radars to use TSETMC's legacy MarketWatch CSV endpoint as the first live source, with modern TSE/TSETMC endpoints as fallbacks.

- Iran stocks: `MarketWatchInit.aspx` over HTTP, parsed directly on Android; filters flows 1/2/4 and reads live price, close, last, volume, value, trades, EPS, limits and state. Also reads `ClientTypeAll.aspx` and uses daily history when available.
- Iran commodities: same live market feed, filtering flow 7 for commodity instruments, with official gateway futures/options as fallback.
- Android native HTTP access is enabled because the legacy TSETMC endpoint is HTTP-only.
- No fake fallback values are generated. If TSETMC is unreachable or the market is closed, the app explicitly reports no live data.
- Refresh cadence is 5 minutes while the section is visible.

Important: TSETMC data access is known to depend on Iranian IP/network conditions. The legacy endpoint is the first route specifically because the newer gateway may reject foreign/VPN IPs. If the user's network blocks TSETMC entirely, a provider/API key or an in-Iran relay is required; the app must not fabricate data.
