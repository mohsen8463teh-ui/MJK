/* MJK Data Relay v3
 * Run on an Iranian host (or another host with verified TSETMC access).
 * Keeps last-valid snapshots, enriches candidates with client-type, depth and history,
 * and never labels a closed-session snapshot as LIVE.
 */
const http=require('http');
const https=require('https');
const URLX=require('url');
const PORT=Number(process.env.PORT||8787);
const API_KEY=process.env.MJK_RELAY_KEY||'';
const TSE=process.env.TSE_BASE||'https://webgw.tse.ir';
const CDN=process.env.TSETMC_CDN||'https://cdn.tsetmc.com/api';
const CORS='*';
const cache={stocks:null,commodities:null};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function get(url,headers={}){return new Promise((resolve,reject)=>{const u=new URLX.URL(url);const lib=u.protocol==='http:'?http:https;const r=lib.get(u,{headers:{'User-Agent':'MJK-Relay/3.0','Accept':'application/json, text/plain, */*','Accept-Language':'fa-IR,fa;q=0.9,en;q=0.7','Referer':'https://www.tse.ir/',...headers}},res=>{let b='';res.setEncoding('utf8');res.on('data',x=>b+=x);res.on('end',()=>{if(res.statusCode<200||res.statusCode>=300)return reject(new Error('upstream '+res.statusCode));try{resolve(JSON.parse(b))}catch(e){reject(new Error('invalid-json '+e.message))}})});r.on('error',reject);r.setTimeout(15000,()=>r.destroy(new Error('timeout')))});}
function unwrap(x){if(!x||typeof x!=='object')return null;if(Array.isArray(x)){return x.length&&typeof x[0]==='object'?x:null}if(Array.isArray(x.Items))return x.Items;if(Array.isArray(x.items))return x.items;for(const k of Object.keys(x)){const v=x[k];if(v&&typeof v==='object'){const a=unwrap(v);if(a)return a}}return null;}
function collectArrays(x,out=[]){if(!x||typeof x!=='object')return out;if(Array.isArray(x)){if(x.length&&typeof x[0]==='object')out.push(x);for(const v of x.slice(0,8))collectArrays(v,out);return out}for(const v of Object.values(x))collectArrays(v,out);return out;}
function num(v){if(v&&typeof v==='object')v=v.value??v.Value??v.val??v.amount??v.Amount;const x=Number(String(v??'').replace(/,/g,''));return Number.isFinite(x)?x:null;}
function norm(x){return {symbol:x.lVal18AFC||x.lVal18||x.symbol||x.instrumentName||'',name:x.lVal30||x.companyName||x.companyNamePersian||x.instrumentName||'',last:x.pDrCotVal??x.lastPrice??x.pl,close:x.pClosing??x.closingPrice??x.pc,prev:x.priceYesterday??x.yesterdayPrice??x.py,change:x.changePercent??x.pct,vol:x.qTotTran5J??x.tradeVolume??x.volume,value:x.qTotCap??x.tradeValue??x.value,trades:x.zTotTran??x.tradeCount,eps:x.eps,pe:x.pe,flow:x.flow,isin:x.instrumentId||x.InstrumentId||x.cIsin||'',insCode:String(x.insCode||x.InsCode||''),state:x.stateName||x.state||'',hEven:x.hEven||x.lastTradeTime||x.time||null};}
function tehran(){const p=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Tehran',weekday:'short',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(new Date());const m={};for(const x of p)m[x.type]=x.value;const day=m.weekday,h=Number(m.hour),mi=Number(m.minute),mins=h*60+mi;return {day,mins};}
function stockSession(){const t=tehran();return ['Sat','Sun','Mon','Tue','Wed'].includes(t.day)&&t.mins>=9*60&&t.mins<=12*60+30;}
function commoditySession(){const t=tehran();return ['Sat','Sun','Mon','Tue','Wed'].includes(t.day)&&t.mins>=8*60+30&&t.mins<=17*60;}
function captured(rows){let latest=null;for(const x of rows){const h=String(x.hEven||'').replace(/\D/g,'');if(h.length>=6){const hh=Number(h.slice(0,2)),mm=Number(h.slice(2,4)),ss=Number(h.slice(4,6));if(hh<24&&mm<60&&ss<60){const d=new Date();d.setHours(hh,mm,ss,0);const ts=d.getTime();if(!latest||ts>latest)latest=ts;}}}return latest&&latest<=Date.now()+60000?latest:Date.now();}
function parseClient(x){return {naturalBuy:num(x.buy_I_Volume??x.buyNaturalVolume??x.naturalBuyVolume??x.buyNatural),legalBuy:num(x.buy_N_Volume??x.buyLegalVolume??x.legalBuyVolume??x.legalBuy),naturalSell:num(x.sell_I_Volume??x.sellNaturalVolume??x.naturalSellVolume??x.sellNatural),legalSell:num(x.sell_N_Volume??x.sellLegalVolume??x.legalSellVolume??x.legalSell)};}
function parseDepth(j){const a=unwrap(j)||[];let bid=0,ask=0,bidCount=0,askCount=0;for(const x of a){const d=num(x.qTitMeDem??x.bidVolume??x.qBid??x.qBuy),o=num(x.qTitMeOf??x.askVolume??x.qAsk??x.qSell);if(d!=null){bid+=d;bidCount+=num(x.zOrdMeDem??x.bidCount??x.buyOrderCount)??0}if(o!=null){ask+=o;askCount+=num(x.zOrdMeOf??x.askCount??x.sellOrderCount)??0}}return {bidDepth:bid||null,askDepth:ask||null,bidOrders:bidCount||null,askOrders:askCount||null,orderImbalance:(bid||ask)?(bid-ask)/Math.max(1,bid+ask):null};}
function parseHistory(j){const a=unwrap(j)||[];const rows=a.map(x=>({date:num(x.dEven??x.date),open:num(x.pFirst??x.priceFirst??x.open??x.first),last:num(x.pDrCotVal??x.lastPrice??x.last),close:num(x.pClosing??x.closingPrice??x.pc),prev:num(x.priceYesterday??x.yesterdayPrice??x.prev),low:num(x.pMin??x.priceMin??x.low),high:num(x.pMax??x.priceMax??x.high),vol:num(x.qTotTran5J??x.volume??x.qTotTran),value:num(x.qTotCap??x.value),trades:num(x.zTotTran??x.trades)})).filter(x=>x.last!=null&&x.prev!=null&&x.low!=null&&x.high!=null&&x.prev>0).sort((a,b)=>(a.date||0)-(b.date||0));if(!rows.length)return null;const vols=rows.map(x=>x.vol).filter(v=>v!=null);const avgVol=vols.length?vols.slice(-20).reduce((a,b)=>a+b,0)/Math.min(20,vols.length):null;const first=rows[Math.max(0,rows.length-20)].close,last=rows[rows.length-1].close;return {avgVol,trend20:first&&last?last>first?'up':last<first?'down':'flat':'flat',history:rows};}
async function enrichStocks(items){
 const byValue=items.filter(x=>x.insCode).sort((a,b)=>(num(b.value)||0)-(num(a.value)||0)).slice(0,120);
 const byMove=items.filter(x=>x.insCode).sort((a,b)=>Math.abs(num(b.change)||0)-Math.abs(num(a.change)||0)).slice(0,80);
 const candidates=Array.from(new Map([...byValue,...byMove].map(x=>[x.insCode,x])).values()).slice(0,180);
 let clientMap=new Map();
 try{const cj=await get(CDN+'/ClientType/GetClientTypeAll');for(const a of collectArrays(cj)){for(const x of a){const id=String(x.insCode??x.InsCode??x.ins_code??'');if(id)clientMap.set(id,parseClient(x));}}}catch(_){ }
 const out=items.map(x=>({...x,...(clientMap.get(x.insCode)||{})}));
 const map=new Map(out.map(x=>[x.insCode,x]));
 for(let i=0;i<candidates.length;i+=8){const batch=candidates.slice(i,i+8);await Promise.all(batch.map(async x=>{
   try{const d=parseDepth(await get(CDN+'/BestLimits/'+encodeURIComponent(x.insCode)));Object.assign(map.get(x.insCode),d);}catch(_){ }
   try{const h=parseHistory(await get(CDN+'/ClosingPrice/GetClosingPriceDailyList/'+encodeURIComponent(x.insCode)+'/200'));Object.assign(map.get(x.insCode),h||{});}catch(_){ }
 }));await sleep(80);}
 return out;
}
async function stocks(){
 try{const j=await get(TSE+'/InstrumentProvider/api/v1/MarketWatch/MarketWatchCash/fa');const a=unwrap(j)||[];const items=a.map(norm).filter(x=>x.symbol&&x.last!=null);if(!items.length)throw new Error('empty-marketwatch');const rows=await enrichStocks(items);const ts=captured(rows);const live=stockSession();const result={source:'TSETMC official gateway + CDN depth/history',timestamp:ts,capturedAt:Date.now(),marketStatus:live?'بازار باز':'بازار بسته',live,upstreamOk:true,dataAgeSec:Math.max(0,Math.round((Date.now()-ts)/1000)),items:rows};cache.stocks=result;return result;}
 catch(e){if(cache.stocks)return {...cache.stocks,live:false,upstreamOk:false,marketStatus:'منبع زنده موقتاً در دسترس نیست',dataAgeSec:Math.max(0,Math.round((Date.now()-cache.stocks.timestamp)/1000))};throw e;}
}
async function commodities(){
 try{const j=await get(TSE+'/InstrumentProvider/api/v1/MarketWatch/MarketWatchFuture/fa');const a=unwrap(j)||[];const items=a.map(norm).filter(x=>x.symbol&&x.last!=null);if(!items.length)throw new Error('empty-futures');const rows=items;const ts=captured(rows);const live=commoditySession();const result={source:'TSE commodity/futures via MJK Relay',timestamp:ts,capturedAt:Date.now(),marketStatus:live?'پنجره معاملات/داده باز':'بازار بسته',live,upstreamOk:true,dataAgeSec:Math.max(0,Math.round((Date.now()-ts)/1000)),items:rows};cache.commodities=result;return result;}
 catch(e){if(cache.commodities)return {...cache.commodities,live:false,upstreamOk:false,marketStatus:'منبع زنده موقتاً در دسترس نیست',dataAgeSec:Math.max(0,Math.round((Date.now()-cache.commodities.timestamp)/1000))};throw e;}
}
const routes={'/mjk/v1/radar/stocks':stocks,'/mjk/v1/radar/commodities':commodities};
const srv=http.createServer(async(req,res)=>{res.setHeader('Access-Control-Allow-Origin',CORS);res.setHeader('Access-Control-Allow-Headers','x-mjk-key,content-type');res.setHeader('Cache-Control','no-store');if(req.method==='OPTIONS'){res.writeHead(204);return res.end()}if(API_KEY&&req.headers['x-mjk-key']!==API_KEY){res.writeHead(401,{'Content-Type':'application/json'});return res.end(JSON.stringify({error:'unauthorized'}))}const fn=routes[req.url?.split('?')[0]];if(!fn){res.writeHead(404,{'Content-Type':'application/json'});return res.end(JSON.stringify({error:'not_found'}))}try{const out=await fn();res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(out))}catch(e){res.writeHead(502,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'upstream_unavailable',message:String(e.message||e)}))}});
srv.listen(PORT,()=>console.log('MJK relay v3 listening on '+PORT));
