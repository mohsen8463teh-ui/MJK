# MJK Data Relay v3

این Relay برای رادار حرفه‌ای MJK طراحی شده و باید روی سروری اجرا شود که واقعاً به TSETMC دسترسی دارد؛ برای `webgw.tse.ir` در عمل IP ایران لازم است.

## چه چیزی می‌دهد؟
- `/mjk/v1/radar/stocks`
  - دیده‌بان بازار
  - حقیقی/حقوقی
  - عمق ۵ سطحی برای کاندیداهای مهم
  - میانگین حجم/روند ۳۰ روزه برای کاندیداها
  - وضعیت باز/بسته بودن بازار
  - آخرین snapshot معتبر در صورت قطع موقت upstream
- `/mjk/v1/radar/commodities`
  - آتی کالا از TSE
  - آخرین snapshot معتبر
  - وضعیت پنجره بازار

## اجرا

`MJK_RELAY_KEY=یک-کلید-تصادفی node server.js`

سرویس را پشت HTTPS قرار دهید و URL آن را در MJK → تنظیمات → Data Relay وارد کنید.

**کلید Relay و هر API token منبع حرفه‌ای نباید داخل APK قرار بگیرد.**

## نکته مهم
Relay خودش «داده ساختگی» تولید نمی‌کند. اگر upstream قطع شود، فقط آخرین snapshot معتبر را با `live:false` برمی‌گرداند. بنابراین MJK آن را به‌عنوان Live نشان نمی‌دهد.

منابع رسمی/جامعه‌ای فعلی TSETMC شامل MarketWatch، BestLimits، ClientType و تاریخچه هستند؛ `webgw.tse.ir` برای MarketWatch و Order Book مناسب است و `cdn.tsetmc.com` برای BestLimits/ClientType/History استفاده می‌شود. Endpointهای جامعه‌ای مستند هستند و SLA رسمی ندارند.
