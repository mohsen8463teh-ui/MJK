import math, wave, struct, random, os
SR=44100
tracks=[
 ('dastan_aramesh',[293.66,311.13,349.23,392.00,440.00,466.16,523.25]),
 ('ney_sahar',[261.63,293.66,329.63,349.23,392.00,415.30,466.16]),
 ('setar_khaneh',[220.00,246.94,277.18,293.66,329.63,369.99,415.30]),
 ('santour_shab',[246.94,277.18,311.13,329.63,369.99,415.30,466.16]),
]
random.seed(42)
os.makedirs('/mnt/data/mjk_music/tmpwav',exist_ok=True)
for ti,(name,scale) in enumerate(tracks):
    dur=48
    frames=[]
    # gentle chord/drone roots
    root=scale[0]
    pattern=[0,1,2,4,2,1,3,4,5,4,2,1,0,2,4,3]
    bpm=54+ti*2
    beat=60/bpm
    for n in range(int(SR*dur)):
        t=n/SR
        # slow fade in/out
        env=min(1,t/3,(dur-t)/4)
        # soft drone
        y=0.045*math.sin(2*math.pi*root*t)+0.022*math.sin(2*math.pi*(root*2)*t)
        # plucked/santur-like phrases
        pos=t/(beat*0.5)
        idx=int(pos)%len(pattern)
        frac=pos-int(pos)
        note=scale[pattern[idx]%len(scale)]
        # occasional rest
        amp=0.0 if (idx%9==7) else 0.13
        decay=math.exp(-5.5*frac)
        y += amp*decay*(math.sin(2*math.pi*note*t)+0.32*math.sin(2*math.pi*2*note*t)+0.12*math.sin(2*math.pi*3*note*t))
        # airy upper note every 8 beats
        if idx%16 in (4,12):
            note2=scale[(pattern[idx]+2)%len(scale)]*2
            y += 0.045*math.exp(-4*frac)*math.sin(2*math.pi*note2*t)
        # subtle deterministic noise for breath texture
        y += 0.0015*math.sin(2*math.pi*(0.13+0.02*ti)*t)
        y=max(-0.85,min(0.85,y*env))
        frames.append(struct.pack('<h',int(y*32767)))
    path=f'/mnt/data/mjk_music/tmpwav/{name}.wav'
    with wave.open(path,'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes(b''.join(frames))
    print(path)
