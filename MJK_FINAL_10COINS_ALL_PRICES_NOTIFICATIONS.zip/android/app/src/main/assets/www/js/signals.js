class Signals{
  constructor(){this.symbols=[];this.busy=false;this.bind();this.timer=setInterval(()=>this.check(false),60000);}
  bind(){document.getElementById('checkSignal')?.addEventListener('click',()=>this.check(true));}
  async check(manual=false){
    if(this.busy)return;
    this.busy=true;
    try{
      this.symbols=await MJK.topSymbols();
      const results=await Promise.all(this.symbols.map(async symbol=>{
        try{
          const {analysis}=await MJK.latestClosed(symbol);
          const issued=MJK.issueIfEligible(analysis,symbol);
          const price=await MJK.ticker(symbol);
          const closed=MJK.checkActive(price,symbol);
          if(closed){window.app?.toast(`${symbol}: ${closed.outcome==='TP'?'حد سود':'حد ضرر'} | R=${Number(closed.r).toFixed(2)}`,closed.outcome==='TP'?'ok':'err');window.MJKNative?.tradeClosed?.(JSON.stringify(closed));}
          const active=MJK.getActive(symbol);
          if(issued){window.app?.toast(`سیگنال BUY جدید: ${symbol}`,'ok');window.MJKNative?.signalIssued?.(JSON.stringify(issued));return issued;}
          if(active)return active;
          if(analysis)return {...analysis,symbol};
        }catch(e){return {symbol,error:true};}
        return {symbol,error:true};
      }));
      this.render(results);
      const successes=results.filter(x=>x&&!x.error).length;
      if(successes)MJK.connectionSuccess();
      document.getElementById('liveStatus').textContent=`۱۰ ارز برتر بازار · ${this.symbols.length} نماد · KuCoin`;
    }catch(e){
      document.getElementById('liveStatus').textContent='داده قبلی حفظ شد · در حال تلاش مجدد';
      if(manual)window.app?.toast('دریافت داده بازار ناموفق بود','err');
    }finally{this.busy=false;}
  }
  render(items){const box=document.getElementById('signalBox');if(!box)return;const valid=items.filter(x=>x&&!x.error);if(!valid.length){box.innerHTML='<div class="empty">داده‌ای برای نمایش وجود ندارد.</div>';return;}box.innerHTML=valid.map(x=>{const active=x.entry_price!=null&&x.stop_loss!=null;const entry=active?x.entry_price:x.entry,sl=active?x.stop_loss:x.stopLoss,tp=active?x.take_profit_1:x.takeProfit;return `<div class="signal-card"><div class="signal-top"><b>${x.symbol||'—'}</b><span class="status-badge ${active?'live':''}">${active?'BUY فعال':'بدون سیگنال'}</span></div>${entry!=null?`<div class="metrics"><div class="metric"><small>Entry</small><b>$${Number(entry).toFixed(4)}</b></div><div class="metric"><small>SL</small><b>$${Number(sl).toFixed(4)}</b></div><div class="metric"><small>TP</small><b>$${Number(tp).toFixed(4)}</b></div></div>`:'<p class="muted">شرایط ورود کامل نشده است.</p>'}</div>`;}).join('');}
}
window.signals=new Signals();
