/* Live KuCoin spot prices. No API key is used. */
(() => {
  const state={rows:[],query:'',loading:false};
  const el=id=>document.getElementById(id);
  const fmt=n=>{const x=Number(n);if(!Number.isFinite(x))return '—';if(x>=1000)return x.toLocaleString('en-US',{maximumFractionDigits:2});if(x>=1)return x.toLocaleString('en-US',{maximumFractionDigits:4});if(x>=0.01)return x.toLocaleString('en-US',{maximumFractionDigits:6});return x.toLocaleString('en-US',{maximumSignificantDigits:7});};
  const pct=n=>`${Number(n)>=0?'+':''}${(Number(n)*100).toFixed(2)}%`;
  function filtered(){const q=state.query.trim().toUpperCase();let rows=state.rows.filter(r=>String(r.symbol||'').endsWith('-USDT'));if(q)rows=rows.filter(r=>String(r.symbol).includes(q));return rows.sort((a,b)=>Number(b.volValue||0)-Number(a.volValue||0));}
  function render(){const list=el('priceList');if(!list)return;const rows=filtered();if(!rows.length){list.innerHTML='<div class="empty">ارزی پیدا نشد.</div>';return;}list.innerHTML=rows.map(r=>{const ch=Number(r.changeRate||0),cls=ch>0?'up':ch<0?'down':'';return `<div class="price-row"><div><b>${r.symbol}</b><small>حجم ۲۴ساعته: ${Number(r.volValue||0).toLocaleString('en-US',{maximumFractionDigits:0})} USDT</small></div><strong>${fmt(r.last)}</strong><span class="${cls}">${pct(ch)}</span></div>`;}).join('');el('priceMore').innerHTML=`<small>${rows.length.toLocaleString('en-US')} جفت‌ارز USDT · بروزرسانی زنده</small>`;}
  async function load(){if(state.loading)return;state.loading=true;const status=el('pricesStatus');if(status)status.textContent='در حال بروزرسانی…';try{state.rows=await MJK.allPrices();render();if(status)status.textContent=`زنده · ${new Date().toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}`;}catch(e){MJK.connectionFailure();if(status)status.textContent='اتصال بازار ناموفق';if(!state.rows.length)el('priceList').innerHTML='<div class="empty">دریافت قیمت‌ها ناموفق بود. منبع بازار در دسترس نیست.</div>';}finally{state.loading=false;}}
  function init(){el('priceSearch')?.addEventListener('input',e=>{state.query=e.target.value;render();});el('priceQuote')?.remove();el('priceRefresh')?.addEventListener('click',load);window.prices={load,render};setInterval(load,30000);}
  document.addEventListener('DOMContentLoaded',()=>{init();load();});
})();
