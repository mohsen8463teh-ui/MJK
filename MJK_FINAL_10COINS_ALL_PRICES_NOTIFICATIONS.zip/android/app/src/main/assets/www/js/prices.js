/* MJK live crypto prices. Public Binance market data; no API key. */
(() => {
  const APIS = ['https://data-api.binance.vision/api/v3/ticker/24hr','https://api.binance.com/api/v3/ticker/24hr','https://api1.binance.com/api/v3/ticker/24hr'];
  const state = {rows: [], quote: 'ALL', query: '', visible: 100, loading: false};
  const el = id => document.getElementById(id);
  const fmt = (n) => {
    const x = Number(n);
    if (!Number.isFinite(x)) return '—';
    if (x >= 1000) return x.toLocaleString('en-US', {maximumFractionDigits: 2});
    if (x >= 1) return x.toLocaleString('en-US', {maximumFractionDigits: 4});
    if (x >= 0.01) return x.toLocaleString('en-US', {maximumFractionDigits: 6});
    return x.toLocaleString('en-US', {maximumSignificantDigits: 7});
  };
  const pct = n => `${Number(n) >= 0 ? '+' : ''}${Number(n).toFixed(2)}%`;
  async function apiJson(url){
    if(window.MJKNative && typeof window.MJKNative.fetchJson === 'function'){
      const text=window.MJKNative.fetchJson(url);
      if(typeof text==='string' && text.startsWith('MJK_NATIVE_ERROR:')) throw new Error(text);
      return JSON.parse(text);
    }
    const r=await fetch(url,{cache:'no-store'});
    if(!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  }
  function filtered() {
    const q = state.query.trim().toUpperCase();
    let rows = state.rows.filter(r => state.quote === 'ALL' || r.symbol.endsWith(state.quote));
    if (q) rows = rows.filter(r => r.symbol.includes(q));
    return rows.sort((a,b) => Number(b.quoteVolume||0) - Number(a.quoteVolume||0));
  }
  function render() {
    const list = el('priceList');
    if (!list) return;
    const rows = filtered();
    const shown = rows.slice(0, state.visible);
    if (!shown.length) { list.innerHTML = '<div class="empty">ارزی با این جستجو پیدا نشد.</div>'; el('priceMore').textContent=''; return; }
    list.innerHTML = shown.map(r => {
      const change = Number(r.priceChangePercent);
      const cls = change > 0 ? 'up' : change < 0 ? 'down' : '';
      return `<div class="price-row"><div><b>${r.symbol}</b><small>${Number(r.quoteVolume||0).toLocaleString('en-US',{maximumFractionDigits:0})} ${state.quote==='ALL'?'quote':''}</small></div><strong>${fmt(r.lastPrice)}</strong><span class="${cls}">${pct(change)}</span></div>`;
    }).join('');
    const more = el('priceMore');
    more.innerHTML = rows.length > state.visible ? `<button id="priceLoadMore" class="secondary full">نمایش ${Math.min(100, rows.length-state.visible)} ارز دیگر</button>` : `<small>${rows.length.toLocaleString('en-US')} جفت‌ارز نمایش داده شد</small>`;
    el('priceLoadMore')?.addEventListener('click', () => { state.visible += 100; render(); });
  }
  async function load() {
    if (state.loading) return;
    state.loading = true;
    const status = el('pricesStatus'); if (status) status.textContent = 'در حال بروزرسانی…';
    try {
      let data=null, last=null; for(const api of APIS){ try{ data=await apiJson(api); break; }catch(e){last=e;} } if(!data) throw last||new Error('Binance unavailable');
      state.rows = Array.isArray(data) ? data.filter(x => x.symbol && x.lastPrice) : [];
      state.visible = 100; render();
      if (status) status.textContent = `بروزرسانی: ${new Date().toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'})}`;
      document.getElementById('conn')?.classList.remove('bad'); document.getElementById('conn')?.classList.add('good');
    } catch (e) {
      if (status) status.textContent = 'خطا در دریافت از Binance';
      if (!state.rows.length) el('priceList').innerHTML = `<div class="empty">دریافت قیمت‌ها ناموفق بود. اتصال اینترنت را بررسی کنید.</div>`;
    } finally { state.loading = false; }
  }
  function init() {
    el('priceSearch')?.addEventListener('input', e => { state.query = e.target.value; state.visible = 100; render(); });
    el('priceQuote')?.addEventListener('change', e => { state.quote = e.target.value; state.visible = 100; render(); });
    el('priceRefresh')?.addEventListener('click', load);
    window.prices = {load, render};
  }
  document.addEventListener('DOMContentLoaded', () => { init(); load(); });
})();
