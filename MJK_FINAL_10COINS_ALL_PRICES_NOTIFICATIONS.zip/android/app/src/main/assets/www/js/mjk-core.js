/* MJK standalone trading engine. One strategy shared by live, backtest and paper tracking. */
window.MJK = (() => {
  const API_HOSTS = ['https://data-api.binance.vision/api/v3','https://api.binance.com/api/v3','https://api1.binance.com/api/v3'];
  const API = API_HOSTS[0] + '/klines';
  const TICKER = API_HOSTS[0] + '/ticker/price?symbol=BTCUSDT';
  const FALLBACK_TOP = ['BTCUSDT','ETHUSDT','XRPUSDT','BNBUSDT','SOLUSDT','DOGEUSDT','ADAUSDT','TRXUSDT','LINKUSDT','AVAXUSDT'];
  const STABLE = new Set(['USDT','USDC','USDE','DAI','FDUSD','USDS']);
  const TF = '15m';
  const FEE_RATE = 0.0025; // 0.25% per side
  const START_BALANCE = 1000;
  const RISK_AMOUNT = 10; // 1% of $1000 starting capital
  const KEY = 'mjk_state_v2';
  const settings = () => ({
    notifications: localStorage.getItem('mjk_notify') !== '0',
    riskAmount: RISK_AMOUNT
  });

  // Connection state is deliberately tolerant: one failed refresh must not
  // turn a working connection red. Only repeated complete failures do that.
  let connectionFailures = 0;
  const OFFLINE_AFTER = 3;
  function setConnection(ok){
    if(ok) connectionFailures = 0; else connectionFailures++;
    const online = connectionFailures < OFFLINE_AFTER;
    const dot=document.getElementById('conn'), text=document.getElementById('connText');
    if(dot) dot.className='dot '+(online?'good':'bad');
    if(text) text.textContent=online?'آنلاین':'آفلاین';
    return online;
  }
  function connectionSuccess(){ return setConnection(true); }
  function connectionFailure(){ return setConnection(false); }

  function isBinanceUrl(url){ return /(^|\.)binance\.com(\/|$)/i.test(String(url)) || /(^|\.)binance\.vision(\/|$)/i.test(String(url)); }
  async function apiJson(url){
    if(window.MJKNative && typeof window.MJKNative.fetchJson === 'function'){
      const text=window.MJKNative.fetchJson(url);
      if(typeof text==='string' && text.startsWith('MJK_NATIVE_ERROR:')) throw new Error(text);
      const data=JSON.parse(text);
      if(isBinanceUrl(url)) connectionSuccess();
      return data;
    }
    const r=await fetch(url,{cache:'no-store'});
    if(!r.ok) throw new Error(`HTTP ${r.status}`);
    const data=await r.json();
    if(isBinanceUrl(url)) connectionSuccess();
    return data;
  }

  function loadState(){ try { const s=JSON.parse(localStorage.getItem(KEY)) || {}; return {activeTrades:s.activeTrades||{}, history:s.history||[], backtests:s.backtests||[], active:s.active||null}; } catch(e){ return {activeTrades:{},history:[],backtests:[],active:null}; } }
  async function topSymbols(){
    try{ const a=await apiJson('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=20&page=1&sparkline=false'); const out=[]; for(const x of a){ const sym=String(x.symbol||'').toUpperCase(); if(STABLE.has(sym)) continue; const pair=sym+'USDT'; if(!out.includes(pair)) out.push(pair); if(out.length===10) break; } if(out.length>=10){ localStorage.setItem('mjk_top10',JSON.stringify({at:Date.now(),symbols:out})); return out; } }catch(e){}
    try{ const cached=JSON.parse(localStorage.getItem('mjk_top10')||'null'); if(cached?.symbols?.length>=10) return cached.symbols.slice(0,10); }catch(e){}
    return FALLBACK_TOP;
  }
  function saveState(s){ localStorage.setItem(KEY, JSON.stringify(s)); }
  function num(v){ return Number(v); }
  function ema(values, period){
    const out = new Array(values.length).fill(null); if(values.length < period) return out;
    let sum=0; for(let i=0;i<period;i++) sum += values[i];
    let prev=sum/period; out[period-1]=prev; const k=2/(period+1);
    for(let i=period;i<values.length;i++){ prev=(values[i]-prev)*k+prev; out[i]=prev; }
    return out;
  }
  function atr(candles, period=14){
    const tr=new Array(candles.length).fill(null); const out=new Array(candles.length).fill(null);
    for(let i=0;i<candles.length;i++){
      const h=num(candles[i][2]), l=num(candles[i][3]), pc=i?num(candles[i-1][4]):h;
      tr[i]=i?Math.max(h-l,Math.abs(h-pc),Math.abs(l-pc)):h-l;
    }
    if(candles.length<period) return out;
    let sum=0; for(let i=0;i<period;i++) sum+=tr[i];
    let prev=sum/period; out[period-1]=prev;
    for(let i=period;i<candles.length;i++){ prev=((prev*(period-1))+tr[i])/period; out[i]=prev; }
    return out;
  }
  function analyze(candles){
    if(!candles || candles.length<210) return null;
    const closes=candles.map(c=>num(c[4])); const opens=candles.map(c=>num(c[1]));
    const lows=candles.map(c=>num(c[3]));
    const e20=ema(closes,20), e200=ema(closes,200), a14=atr(candles,14);
    const i=candles.length-1;
    if(e20[i]==null||e200[i]==null||a14[i]==null) return null;
    const prevSignal = (()=>{
      for(let j=i-1;j>=0;j--){
        if(e20[j]!=null&&e200[j]!=null&&a14[j]!=null&&closes[j]>e200[j]&&e20[j]>e200[j]&&lows[j]<=e20[j]&&closes[j]>opens[j]&&closes[j]>e20[j]) return j;
      } return -99999;
    })();
    const conditions={trend:closes[i]>e200[i],cross:e20[i]>e200[i],touch:lows[i]<=e20[i],green:closes[i]>opens[i],closeAbove:closes[i]>e20[i],gap:true};
    const signal=Object.values(conditions).every(Boolean);
    const entry=closes[i], atr14=a14[i];
    return {signal, candle:candles[i], index:i, closeTimeMs:num(candles[i][6]), entry, stopLoss:entry-1.5*atr14, takeProfit:entry+3*atr14, atr:atr14, ema20:e20[i], ema200:e200[i], conditions, candles, closes, e20, e200, a14};
  }
  function toSignal(a,symbol='BTCUSDT'){
    return { id:`${symbol}-${a.closeTimeMs}`, symbol, direction:'BUY', timeframe:'15m', entry_price:a.entry, stop_loss:a.stopLoss, take_profit_1:a.takeProfit, atr:a.atr, ema20:a.ema20, ema200:a.ema200, rr:2, close_time_ms:a.closeTimeMs, created_at:new Date(a.closeTimeMs).toISOString(), reasons:['قیمت بالای EMA200 است','EMA20 بالاتر از EMA200 است','Low کندل EMA20 را لمس کرده','کندل سبز است','بسته‌شدن بالای EMA20 است','حداقل ۱۰ کندل از سیگنال قبلی گذشته است']};
  }
  async function fetchKlines({symbol='BTCUSDT',interval=TF,startTime,endTime,limit=1000}={}){
    const p=new URLSearchParams({symbol,interval,limit:String(limit)}); if(startTime!=null)p.set('startTime',String(startTime)); if(endTime!=null)p.set('endTime',String(endTime));
    let lastErr=null;
    for(const host of API_HOSTS){ try{ return await apiJson(`${host}/klines?${p.toString()}`); }catch(e){ lastErr=e; } }
    throw lastErr || new Error('Binance connection failed');
  }
  async function fetchRange(startMs,endMs,onProgress){
    let all=[], cursor=startMs;
    while(cursor<endMs){
      const batch=await fetchKlines({startTime:cursor,endTime:endMs,limit:1000}); if(!batch.length) break;
      all=all.concat(batch); const last=num(batch[batch.length-1][6]); cursor=last+1;
      if(onProgress) onProgress(Math.min(100,Math.round((cursor-startMs)/(endMs-startMs)*100)));
      if(batch.length<1000) break;
      await new Promise(r=>setTimeout(r,80));
    }
    const seen=new Set(); return all.filter(c=>{const k=String(c[0]); if(seen.has(k))return false;seen.add(k);return true;});
  }
  function isClosed(c){ return num(c[6]) < Date.now(); }
  async function latestClosed(symbol='BTCUSDT'){
    const rows=await fetchKlines({symbol,limit:220}); const closed=rows.filter(isClosed); return {rows:closed, analysis:analyze(closed)};
  }
  async function ticker(symbol='BTCUSDT'){ let lastErr=null; for(const host of API_HOSTS){ try{ const j=await apiJson(`${host}/ticker/price?symbol=${encodeURIComponent(symbol)}`); return num(j.price); }catch(e){ lastErr=e; } } throw lastErr || new Error('ticker'); }
  function issueIfEligible(a,symbol='BTCUSDT'){
    const s=loadState(); if(!a||!a.signal) return null;
    if(s.activeTrades[symbol]) return null;
    const sig=toSignal(a,symbol); if(s.history.some(x=>x.id===sig.id)) return null;
    const last=s.history.find(x=>x.direction==='BUY');
    if(last && a.closeTimeMs-last.close_time_ms < 10*15*60*1000) return null;
    s.activeTrades[symbol]={...sig,status:'OPEN',opened_at:new Date().toISOString(),entry_fee:sig.entry_price*FEE_RATE};
    s.history.unshift(s.activeTrades[symbol]); saveState(s); return s.activeTrades[symbol];
  }
  function checkActive(price,symbol='BTCUSDT'){
    const s=loadState(); const t=s.activeTrades[symbol]; if(!t) return null;
    let outcome=null;
    if(price<=t.stop_loss) outcome='SL'; else if(price>=t.take_profit_1) outcome='TP'; else return t;
    const grossR=outcome==='TP'?3:outcome==='SL'?-1:(price-t.entry_price)/(t.entry_price-t.stop_loss);
    const qty=RISK_AMOUNT/(t.entry_price-t.stop_loss);
    const grossPnl=qty*(outcome==='TP'?t.take_profit_1-t.entry_price:outcome==='SL'?t.stop_loss-t.entry_price:price-t.entry_price);
    const fees=(t.entry_price*qty+price*qty)*FEE_RATE;
    const netPnl=grossPnl-fees;
    t.status='CLOSED'; t.outcome=outcome; t.close_price=price; t.closed_at=new Date().toISOString(); t.r=grossR; t.net_pnl=netPnl; t.fees=fees;
    const idx=s.history.findIndex(x=>x.id===t.id); if(idx>=0)s.history[idx]=t; delete s.activeTrades[symbol]; saveState(s); return t;
  }
  function getHistory(){ return loadState().history; }
  function getActive(symbol='BTCUSDT'){ const s=loadState(); return s.activeTrades[symbol]||null; }
  function getActiveTrades(){ return loadState().activeTrades||{}; }
  function clearData(){ localStorage.removeItem(KEY); }
  function metrics(trades){
    let equity=START_BALANCE, peak=equity, maxDD=0, grossProfit=0, grossLoss=0, wins=0;
    const curve=[{time:Date.now(),balance:equity}];
    trades.forEach(t=>{equity+=num(t.net_pnl||0); if(t.net_pnl>0){wins++;grossProfit+=t.net_pnl}else grossLoss+=Math.abs(t.net_pnl||0); peak=Math.max(peak,equity); maxDD=Math.max(maxDD,(peak-equity)/peak*100); curve.push({time:new Date(t.closed_at||t.created_at).getTime(),balance:equity});});
    return {total_trades:trades.length,win_rate:trades.length?wins/trades.length*100:0,profit_factor:grossLoss?grossProfit/grossLoss:(grossProfit?Infinity:0),max_drawdown:maxDD,net_profit_pct:(equity/START_BALANCE-1)*100,equity,curve};
  }
  async function backtest(months,onProgress){
    const end=Date.now(), start=new Date(); start.setMonth(start.getMonth()-months); const startMs=start.getTime();
    const warmup=startMs-220*15*60*1000; const rows=await fetchRange(warmup,end,onProgress); const closed=rows.filter(c=>num(c[6])<Date.now());
    const e20=ema(closed.map(c=>num(c[4])),20), e200=ema(closed.map(c=>num(c[4])),200), a14=atr(closed,14);
    let active=null,lastSignal=-Infinity,trades=[]; const equityTrades=[];
    for(let i=200;i<closed.length;i++){
      const c=closed[i], close=num(c[4]), open=num(c[1]), low=num(c[3]), high=num(c[2]);
      if(active){
        let outcome=null, px=null;
        // Conservative if both are hit in one candle: SL is assumed first.
        if(low<=active.sl){outcome='SL';px=active.sl;} else if(high>=active.tp){outcome='TP';px=active.tp;}
        if(outcome){const qty=RISK_AMOUNT/(active.entry-active.sl); const gross=qty*(px-active.entry); const fees=(active.entry*qty+px*qty)*FEE_RATE; const net=gross-fees; const t={id:active.id,entry:active.entry,close_price:px,sl:active.sl,tp:active.tp,outcome, r:outcome==='TP'?3:-1,net_pnl:net,fees,created_at:new Date(active.time).toISOString(),closed_at:new Date(num(c[6])).toISOString()}; trades.push(t); active=null; }
      }
      if(!active && i-lastSignal>=10 && e20[i]!=null&&e200[i]!=null&&a14[i]!=null && close>e200[i]&&e20[i]>e200[i]&&low<=e20[i]&&close>open&&close>e20[i]){
        const entry=close, sl=entry-1.5*a14[i], tp=entry+3*a14[i]; active={id:`BT-${num(c[6])}`,entry,sl,tp,time:num(c[6])}; lastSignal=i;
      }
      if(onProgress && i%250===0) onProgress(Math.min(100,Math.round((i-200)/(closed.length-200)*100)));
    }
    const m=metrics(trades); const result={...m,symbol:'BTCUSDT',timeframe:'15m',period_start:new Date(startMs).toISOString(),period_end:new Date(end).toISOString(),months,fee_per_side:FEE_RATE,risk_per_trade:RISK_AMOUNT,open_trade_ignored:!!active};
    const s=loadState(); s.backtests.unshift(result); s.backtests=s.backtests.slice(0,10); saveState(s); return result;
  }
  function backtestHistory(){ return loadState().backtests||[]; }
  return {fetchKlines,fetchRange,latestClosed,ticker,topSymbols,analyze,toSignal,issueIfEligible,checkActive,getHistory,getActive,getActiveTrades,clearData,backtest,backtestHistory,metrics,settings,FEE_RATE,START_BALANCE,RISK_AMOUNT,connectionSuccess,connectionFailure};
})();
