package com.cryptopulse.app

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("mjk", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        // The UI is loaded from file://; allow it to call HTTPS public market-data APIs.
        web.settings.allowUniversalAccessFromFileURLs = true
        web.settings.allowFileAccessFromFileURLs = true
        web.settings.setSupportZoom(false)
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(MjkBridge(), "MJKNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/www/index.html")
        scheduleBackgroundCheck()
    }
    inner class MjkBridge {
        @JavascriptInterface fun signalIssued(json:String) { prefs.edit().putString("active_trade", json).apply() }
        @JavascriptInterface fun tradeClosed(json:String) { prefs.edit().remove("active_trade").putString("last_closed", json).apply() }
    }
    private fun requestNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
    }
    private fun scheduleBackgroundCheck() {
        val request = PeriodicWorkRequestBuilder<SignalCheckWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("mjk_signal_check", ExistingPeriodicWorkPolicy.UPDATE, request)
    }
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
