package com.cryptopulse.app

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.pm.PackageManager
import android.webkit.WebResourceRequest
import java.net.HttpURLConnection
import java.net.URL
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("mjk", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        // The UI is loaded from file://; allow it to call HTTPS public market-data APIs.
        web.settings.allowUniversalAccessFromFileURLs = true
        web.settings.allowFileAccessFromFileURLs = true
        web.settings.setSupportZoom(false)
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(MjkBridge(), "MJKNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/www/index.html")
        scheduleBackgroundCheck()
    }
    inner class MjkBridge {
        @JavascriptInterface
        fun fetchJson(url: String): String {
            return try {
                val u = URL(url)
                require(u.protocol == "https") { "Only HTTPS is allowed" }
                val c = (u.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 12000
                    readTimeout = 12000
                    useCaches = false
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "MJK-Android/1.0")
                }
                try {
                    val code = c.responseCode
                    if (code !in 200..299) throw Exception("HTTP $code")
                    BufferedReader(InputStreamReader(c.inputStream, Charsets.UTF_8)).use { it.readText() }
                } finally { c.disconnect() }
            } catch (e: Exception) {
                "MJK_NATIVE_ERROR:" + (e.message ?: "network error")
            }
        }

        @JavascriptInterface fun signalIssued(json:String) {
            try {
                val o = org.json.JSONObject(json)
                val symbol = o.optString("symbol")
                val id = o.optString("id")
                prefs.edit().putString("active_trade_$symbol", json).putString("last_signal_id_$symbol", id).apply()
            } catch (_: Exception) { }
        }
        @JavascriptInterface fun tradeClosed(json:String) {
            try {
                val o = org.json.JSONObject(json)
                val symbol = o.optString("symbol")
                prefs.edit().remove("active_trade_$symbol").putString("last_closed", json).apply()
            } catch (_: Exception) { }
        }
    }
    private fun requestNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
    }
    private fun scheduleBackgroundCheck() {
        val request = PeriodicWorkRequestBuilder<SignalCheckWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("mjk_signal_check", ExistingPeriodicWorkPolicy.UPDATE, request)
    }
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
