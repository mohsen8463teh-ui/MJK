# At the top of the file, replace:
# from app.integrations.data_fallback import data_manager
# with:
from app.integrations.data_fallback import DataFallbackManager
data_manager = DataFallbackManager()
