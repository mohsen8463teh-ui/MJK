class ChartManager {
    static createEquityChart(ctx, data) {
        return new Chart(ctx, {
            type: 'line',
            data: { labels: data.map(d => new Date(d.time).toLocaleTimeString('fa-IR')), datasets: [{ label: 'ارزش پرتفوی', data: data.map(d => d.balance), borderColor: '#8b5cf6', backgroundColor: 'rgba(99,102,241,0.1)', borderWidth: 2, fill: true, tension: 0.4 }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { labels: { color: '#f1f5f9' } } }, scales: { x: { ticks: { color: '#94a3b8', maxTicksLimit: 8 }, grid: { color: 'rgba(51,65,85,0.5)' } }, y: { ticks: { color: '#94a3b8', callback: v => '$' + v.toLocaleString() }, grid: { color: 'rgba(51,65,85,0.5)' } } } } });
    }
}
window.ChartManager = ChartManager;
