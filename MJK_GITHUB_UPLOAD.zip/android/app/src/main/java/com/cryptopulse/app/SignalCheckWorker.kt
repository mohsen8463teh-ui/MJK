package com.cryptopulse.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import kotlin.math.abs
import java.net.HttpURLConnection
import java.net.URL

class SignalCheckWorker(ctx: Context, params: WorkerParameters): CoroutineWorker(ctx,params){
    private val prefs=ctx.getSharedPreferences("mjk",Context.MODE_PRIVATE)
    override suspend fun doWork(): Result=withContext(Dispatchers.IO){try{
        val rows=getKlines(220); val closed=rows.filter{it.getLong(6)<System.currentTimeMillis()};
        if(closed.size<210)return@withContext Result.success()
        val c=closed[closed.lastIndex]; val closes=closed.map{it.getDouble(4)}; val e20=ema(closes,20); val e200=ema(closes,200); val atr=atr(closed,14); val i=closed.lastIndex
        val lastSignalTime=prefs.getLong("last_signal_close",0L); val gap=lastSignalTime==0L || c.getLong(6)-lastSignalTime >= 10L*15L*60L*1000L
        val signal=closes[i]>e200[i]&&e20[i]>e200[i]&&closed[i].getDouble(3)<=e20[i]&&closes[i]>closed[i].getDouble(1)&&closes[i]>e20[i]&&gap
        val active=prefs.getString("active_trade",null)
        val price=getPrice()
        if(active!=null){ val o=org.json.JSONObject(active); val sl=o.getDouble("stop_loss"); val tp=o.getDouble("take_profit_1"); if(price<=sl||price>=tp){val tpHit=price>=tp;prefs.edit().remove("active_trade").apply(); notify("MJK: BTCUSDT","معامله بسته شد",if(tpHit)"TP رسید | قیمت ${"%.2f".format(price)}" else "SL رسید | قیمت ${"%.2f".format(price)}")}}
        if(active==null && signal){ val entry=closes[i]; val sl=entry-1.5*atr[i]; val tp=entry+3*atr[i]; val id="BTCUSDT-${c.getLong(6)}"; val last=prefs.getString("last_signal_id",""); if(id!=last){prefs.edit().putString("last_signal_id",id).putLong("last_signal_close",c.getLong(6)).putString("active_trade",org.json.JSONObject().put("id",id).put("entry_price",entry).put("stop_loss",sl).put("take_profit_1",tp).toString()).apply(); notify("MJK: BTCUSDT","سیگنال BUY جدید","Entry ${"%.2f".format(entry)} | SL ${"%.2f".format(sl)} | TP ${"%.2f".format(tp)}")}}
        Result.success()
    }catch(_:Exception){Result.retry()}}
    private fun getPrice():Double{val c=open("https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT");return org.json.JSONObject(c).getDouble("price")}
    private fun getKlines(n:Int):List<JSONArray>{val s=open("https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=15m&limit=$n");val a=JSONArray(s);return List(a.length()){a.getJSONArray(it)}}
    private fun open(u:String):String{val c=URL(u).openConnection() as HttpURLConnection;c.connectTimeout=15000;c.readTimeout=15000;return c.inputStream.bufferedReader().use{it.readText()}}
    private fun ema(v:List<Double>,p:Int):DoubleArray{val o=DoubleArray(v.size);var sum=0.0;for(i in 0 until p)sum+=v[i];var prev=sum/p;o[p-1]=prev;val k=2.0/(p+1);for(i in p until v.size){prev=(v[i]-prev)*k+prev;o[i]=prev};return o}
    private fun atr(c:List<JSONArray>,p:Int):DoubleArray{val tr=DoubleArray(c.size);for(i in c.indices){val h=c[i].getDouble(2);val l=c[i].getDouble(3);val pc=if(i==0)h else c[i-1].getDouble(4);tr[i]=if(i==0) h-l else maxOf(h-l,abs(h-pc),abs(l-pc))};val o=DoubleArray(c.size);var s=0.0;for(i in 0 until p)s+=tr[i];var prev=s/p;o[p-1]=prev;for(i in p until c.size){prev=(prev*(p-1)+tr[i])/p;o[i]=prev};return o}
    private fun signalIndex(c:List<JSONArray>,e20:DoubleArray,e200:DoubleArray,start:Int):Int{for(i in start downTo 200){val close=c[i].getDouble(4);if(close>e200[i]&&e20[i]>e200[i]&&c[i].getDouble(3)<=e20[i]&&close>c[i].getDouble(1)&&close>e20[i])return i};return -99999}
    private fun notify(title:String,head:String,text:String){val nm=applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;val id="mjk";if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(id,"MJK",NotificationManager.IMPORTANCE_HIGH));val n=NotificationCompat.Builder(applicationContext,id).setSmallIcon(com.cryptopulse.app.R.drawable.mjk_notification).setContentTitle(title).setContentText("$head | $text").setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build();nm.notify((System.currentTimeMillis()%Int.MAX_VALUE).toInt(),n)}
}
